"""
Loading SLU .nemo checkpoints across NeMo versions.

Checkpoints saved with older NeMo (e.g. the NGC `slu_conformer_transformer_large_slurp`, NeMo 1.x) store the output
layer as a bare `MultiLayerPerceptron`. Current NeMo's sequence generator expects a `TokenClassifier`
(which wraps the same MLP as `.mlp`) and fails with
    AttributeError: 'MultiLayerPerceptron' object has no attribute 'mlp'
The weights are identical; only the wrapper and the state-dict prefix differ (`classifier.layer0.*` vs
`classifier.mlp.layer0.*`). This module rewrites the config, then loads the weights with the remapped keys
(strict, so nothing is silently left uninitialised).
"""
from __future__ import annotations

import os
import tarfile
import tempfile

import torch

TOKEN_CLASSIFIER = "nemo.collections.asr.parts.submodules.token_classifier.TokenClassifier"
_KEEP = ("hidden_size", "num_classes", "num_layers", "activation", "log_softmax", "dropout", "use_transformer_init")


def _read_weights(nemo_path: str):
    with tarfile.open(nemo_path, "r:*") as tar:
        member = next(m for m in tar.getmembers() if m.name.endswith("model_weights.ckpt"))
        with tempfile.TemporaryDirectory() as d:
            tar.extract(member, d)
            return torch.load(os.path.join(d, member.name), map_location="cpu", weights_only=False)


def restore_slu_model(nemo_path: str, log=print):
    from omegaconf import OmegaConf, open_dict
    from nemo.collections.asr.models import SLUIntentSlotBPEModel

    cfg = SLUIntentSlotBPEModel.restore_from(nemo_path, return_config=True, map_location="cpu")
    target = str(cfg.get("classifier", {}).get("_target_", ""))
    if target.endswith("TokenClassifier") or not target:
        return SLUIntentSlotBPEModel.restore_from(nemo_path, map_location="cpu")

    log(f"[compat] {os.path.basename(nemo_path)} has classifier `{target}` (older NeMo); "
        f"converting to TokenClassifier")
    with open_dict(cfg):
        old = OmegaConf.to_container(cfg.classifier, resolve=True)
        new = {k: v for k, v in old.items() if k in _KEEP}
        new["_target_"] = TOKEN_CLASSIFIER
        new.setdefault("log_softmax", True)
        new.setdefault("dropout", 0.0)
        cfg.classifier = new
    model = SLUIntentSlotBPEModel.restore_from(nemo_path, override_config_path=cfg, map_location="cpu",
                                               strict=False)
    sd = _read_weights(nemo_path)
    remapped = {}
    for k, v in sd.items():
        if k.startswith("classifier.") and not k.startswith("classifier.mlp."):
            k = "classifier.mlp." + k[len("classifier."):]
        remapped[k] = v
    model.load_state_dict(remapped, strict=True)  # fails loudly if anything does not line up
    log("[compat] weights loaded with remapped classifier keys (strict)")
    return model
