"""
Synthesise the ServiceRobot-SLU-CL dataset with Qwen3-TTS (local ModelScope folders)
and produce NeMo manifests for continual learning on
nvidia/slu_conformer_transformer_large_slurp.

Input : tts/tts_script.csv   (id, text, split, task, intent, output_wav)
Output (inside the dataset root):
  audio_raw/<task>/<id>__<speaker>.wav   raw TTS output (24 kHz)
  audio/<task>/<id>__<speaker>.wav       16 kHz mono PCM-16 (after finalize)
  manifests/...                          NeMo manifests rewritten with real durations
  tts_meta/metadata.csv                  file|id|text|tts_text|speaker|style|split|task|intent
  tts_meta/voices.json                   description of every designed voice
  tts_meta/voice_refs/                   reference clips of designed voices (with --base)
  tts_meta/speaker_splits.json           which speakers read train / dev / test

Speakers:
  1. Preset speakers - CustomVoice model (Ryan, Aiden, ...), each line read in a random style.
  2. Designed voices - random voice descriptions. With --base each voice is designed once
     into a reference clip, then cloned for every sentence (consistent speaker).

Speaker split (--speaker_split):
  disjoint (default) - a few speakers are held out: train speakers read only train
                       sentences, dev speakers only dev, test speakers only test.
                       This measures generalisation to unseen voices (and saves GPU time).
  all                - every speaker reads every sentence.

Example:
  export HF_HUB_OFFLINE=1
  python scripts/make_slu_dataset_qwen3.py --language English \
      --custom ./Qwen3-TTS-12Hz-1.7B-CustomVoice \
      --design ./Qwen3-TTS-12Hz-1.7B-VoiceDesign \
      --base   ./Qwen3-TTS-12Hz-1.7B-Base \
      --num_designed 20 --dev_speakers 2 --test_speakers 3 --batch_size 8 --finalize

Rerunning the same command resumes: finished files are skipped.
"""
import argparse
import csv
import json
import os
import random
import re
import subprocess
import sys
from pathlib import Path

import soundfile as sf
import torch
from qwen_tts import Qwen3TTSModel

ROOT = Path(__file__).resolve().parents[1]

# ---------------------------------------------------------------- settings ---
# Preset speakers. Leave empty to use every speaker the CustomVoice model reports.
PRESET_SPEAKERS = []  # e.g. ["Ryan", "Aiden"] for English-only

# Styles for preset-speaker lines ("" = neutral). Kept to tones a user would
# plausibly use with a service robot.
PRESET_STYLES = [
    "",
    "",
    "Speak in a warm, friendly conversational tone.",
    "Speak calmly and slowly.",
    "Speak politely, as if asking a favour.",
    "Speak quickly, as if in a hurry.",
    "Speak in a tired, low-energy voice.",
    "Speak a little impatiently, with mild frustration.",
    "Speak casually, as if talking to a helper at home.",
]
# Extra styles that only make sense for some intents (chosen 50% of the time).
INTENT_STYLES = {
    "healthcare_alert": ["Speak urgently and anxiously, as if in an emergency.",
                         "Speak in a weak, distressed voice."],
    "healthcare_assist": ["Speak in a slow, frail elderly voice."],
    "navigation_stop": ["Speak sharply and firmly, as an urgent command."],
}

# Attribute pools for random designed voices.
GENDERS = ["male", "female"]
AGES = ["teenage", "young adult", "adult in their thirties", "middle-aged", "elderly"]
PITCHES = ["low-pitched", "medium-pitched", "high-pitched"]
PACES = ["slow", "moderate", "fast"]
TIMBRES = ["warm", "bright", "husky", "smooth", "deep and resonant", "slightly nasal",
           "soft and breathy", "crisp and clear", "gravelly"]
ACCENTS = ["a neutral American accent", "a British accent", "an Australian accent",
           "an Indian English accent", "a Scottish accent", "a neutral accent"]
MOODS = ["calm", "friendly", "confident", "energetic", "gentle", "serious", "cheerful"]

REF_TEXT = ("Hello, it is nice to meet you. Today I will read a few sentences "
            "for you in my natural speaking voice.")

# Spoken-form label text -> nicer TTS input. Labels in the manifests stay unchanged.
TTS_REPLACE = [(r"\ba c\b", "A C"), (r"\btv\b", "TV"), (r"\bx ray\b", "X-ray"),
               (r"\bhr\b", "H R"), (r"\bi\b", "I"), (r"\bi'(m|ve|d|ll)\b", r"I'\1"),
               (r"\bmister\b", "Mister"), (r"\bmissus\b", "Missus")]
QUESTION_START = ("can ", "could ", "would ", "will ", "is ", "how ", "what ", "do ")
# ----------------------------------------------------------------------------


def tts_text(text):
    """'can you switch off the a c' -> 'Can you switch off the A C?'"""
    t = text
    for pat, rep in TTS_REPLACE:
        t = re.sub(pat, rep, t)
    end = "?" if text.startswith(QUESTION_START) else "."
    return t[0].upper() + t[1:] + end


def random_voice(rng):
    return (f"A {rng.choice(MOODS)} {rng.choice(AGES)} {rng.choice(GENDERS)} voice, "
            f"{rng.choice(PITCHES)} and {rng.choice(TIMBRES)}, speaking at a "
            f"{rng.choice(PACES)} pace with {rng.choice(ACCENTS)}.")


def load(path):
    return Qwen3TTSModel.from_pretrained(path, device_map="cuda:0", dtype=torch.bfloat16)


def chunks(items, n):
    for i in range(0, len(items), n):
        yield items[i:i + n]


def safe(name):
    return re.sub(r"[^A-Za-z0-9_-]+", "-", name)


class Writer:
    """Writes wavs into audio_raw/<task>/<id>__<speaker>.wav + metadata (resumable)."""

    def __init__(self, root, meta_dir):
        self.raw = root / "audio_raw"
        self.meta_path = meta_dir / "metadata.csv"
        self.done = set()
        new = not self.meta_path.exists()
        if not new:
            with open(self.meta_path, encoding="utf-8") as f:
                self.done = {row[0] for row in csv.reader(f, delimiter="|") if row}
        self.f = open(self.meta_path, "a", encoding="utf-8", newline="")
        self.w = csv.writer(self.f, delimiter="|")
        if new:
            self.w.writerow(["file", "id", "text", "tts_text", "speaker", "style",
                             "split", "task", "intent"])

    @staticmethod
    def name(row, speaker):
        return f"{row['task']}/{row['id']}__{safe(speaker)}.wav"

    def todo(self, speaker, rows):
        return [r for r in rows if self.name(r, speaker) not in self.done
                and not (self.raw / self.name(r, speaker)).exists()]

    def save(self, speaker, row, style, wav, sr):
        name = self.name(row, speaker)
        path = self.raw / name
        path.parent.mkdir(parents=True, exist_ok=True)
        sf.write(path, wav, sr)
        self.w.writerow([name, row["id"], row["text"], tts_text(row["text"]), speaker,
                         style, row["split"], row["task"], row["intent"]])
        self.f.flush()
        self.done.add(name)
        print("ok", name)


def run_batches(writer, speaker, jobs, batch_size, gen_fn):
    """jobs: list of (row, style). gen_fn(texts, styles) -> (wavs, sr)."""
    for batch in chunks(jobs, batch_size):
        rows, styles = zip(*batch)
        try:
            wavs, sr = gen_fn([tts_text(r["text"]) for r in rows], list(styles))
            for r, s, w in zip(rows, styles, wavs):
                writer.save(speaker, r, s, w, sr)
        except Exception as e:  # one bad batch shouldn't kill a long run
            print(f"FAILED {speaker} batch starting {rows[0]['id']}: {e}")
            torch.cuda.empty_cache()


def assign_splits(speakers, args, path, rng):
    """Map speaker -> list of splits it reads. Stored so resumes stay consistent."""
    if path.exists():
        saved = json.load(open(path))
        if set(saved) >= set(speakers):
            return {s: saved[s] for s in speakers}
    if args.speaker_split == "all":
        plan = {s: ["train", "dev", "test"] for s in speakers}
    else:
        n_hold = args.dev_speakers + args.test_speakers
        if n_hold >= len(speakers):
            sys.exit(f"Need more than {n_hold} speakers for a disjoint split "
                     f"(have {len(speakers)}); add --num_designed or use --speaker_split all")
        order = speakers[:]
        rng.shuffle(order)
        dev = order[:args.dev_speakers]
        test = order[args.dev_speakers:n_hold]
        plan = {s: (["dev"] if s in dev else ["test"] if s in test else ["train"])
                for s in speakers}
    json.dump(plan, open(path, "w"), indent=2)
    return plan


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(ROOT), help="dataset root (ServiceRobot-SLU-CL)")
    ap.add_argument("--tts_csv", default=None, help="default: <root>/tts/tts_script.csv")
    ap.add_argument("--language", default="English")
    ap.add_argument("--custom", help="path to Qwen3-TTS-12Hz-1.7B-CustomVoice")
    ap.add_argument("--design", help="path to Qwen3-TTS-12Hz-1.7B-VoiceDesign")
    ap.add_argument("--base", help="path to Qwen3-TTS-12Hz-1.7B-Base (consistent designed voices)")
    ap.add_argument("--num_designed", type=int, default=20)
    ap.add_argument("--speaker_split", choices=["disjoint", "all"], default="disjoint")
    ap.add_argument("--dev_speakers", type=int, default=2)
    ap.add_argument("--test_speakers", type=int, default=3)
    ap.add_argument("--tasks", nargs="*", default=None,
                    help="only these tasks, e.g. task_01_navigation (default: all)")
    ap.add_argument("--max_sentences", type=int, default=0, help="first N rows only (quick test)")
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--finalize", action="store_true",
                    help="afterwards resample to 16 kHz and rewrite the NeMo manifests")
    args = ap.parse_args()

    root = Path(args.root)
    meta_dir = root / "tts_meta"
    meta_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)
    torch.manual_seed(args.seed)

    with open(args.tts_csv or root / "tts/tts_script.csv", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if args.tasks:
        rows = [r for r in rows if r["task"] in args.tasks]
    if args.max_sentences:
        rows = rows[:args.max_sentences]
    print(f"{len(rows)} utterances")

    # ------------------------------------------------------- speaker list ---
    custom = load(args.custom) if args.custom else None
    presets = (PRESET_SPEAKERS or list(custom.get_supported_speakers())) if custom else []
    voices = {}
    if args.design:
        vp = meta_dir / "voices.json"
        voices = json.load(open(vp, encoding="utf-8")) if vp.exists() else {}
        for k in range(len(voices), args.num_designed):
            voices[f"designed_{k:03d}"] = random_voice(rng)
        json.dump(voices, open(vp, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    plan = assign_splits(presets + list(voices), args, meta_dir / "speaker_splits.json", rng)
    for sp in ("train", "dev", "test"):
        print(f"{sp:5s} speakers:", [s for s, v in plan.items() if sp in v])

    def rows_for(spk):
        return [r for r in rows if r["split"] in plan[spk]]

    def style_for(spk_rng, row):
        if row["intent"] in INTENT_STYLES and spk_rng.random() < 0.5:
            return spk_rng.choice(INTENT_STYLES[row["intent"]])
        return spk_rng.choice(PRESET_STYLES)

    writer = Writer(root, meta_dir)

    # ---------------------------------------------------- preset speakers ---
    if custom:
        print("preset speakers:", presets)
        for spk in presets:
            srng = random.Random(f"{args.seed}-{spk}")
            jobs = [(r, style_for(srng, r)) for r in writer.todo(spk, rows_for(spk))]

            def gen(texts, styles, spk=spk):
                return custom.generate_custom_voice(
                    text=texts, language=[args.language] * len(texts),
                    speaker=[spk] * len(texts), instruct=styles)

            run_batches(writer, spk, jobs, args.batch_size, gen)
        del custom
        torch.cuda.empty_cache()

    # ---------------------------------------------------- designed voices ---
    if args.design:
        design = load(args.design)
        names = list(voices)
        if args.base:
            ref_dir = meta_dir / "voice_refs"
            ref_dir.mkdir(exist_ok=True)
            missing = [n for n in names if not (ref_dir / f"{n}.wav").exists()]
            for batch in chunks(missing, args.batch_size):
                wavs, sr = design.generate_voice_design(
                    text=[REF_TEXT] * len(batch), language=[args.language] * len(batch),
                    instruct=[voices[n] for n in batch])
                for n, w in zip(batch, wavs):
                    sf.write(ref_dir / f"{n}.wav", w, sr)
                    print("designed", n, "-", voices[n])
            del design
            torch.cuda.empty_cache()

            base = load(args.base)
            for n in names:
                jobs = [(r, voices[n]) for r in writer.todo(n, rows_for(n))]
                if not jobs:
                    continue
                prompt = base.create_voice_clone_prompt(
                    ref_audio=str(ref_dir / f"{n}.wav"), ref_text=REF_TEXT)

                def gen(texts, styles, prompt=prompt):
                    return base.generate_voice_clone(
                        text=texts, language=[args.language] * len(texts),
                        voice_clone_prompt=prompt)

                run_batches(writer, n, jobs, args.batch_size, gen)
        else:
            for n, desc in voices.items():
                jobs = [(r, desc) for r in writer.todo(n, rows_for(n))]

                def gen(texts, styles):
                    return design.generate_voice_design(
                        text=texts, language=[args.language] * len(texts), instruct=styles)

                run_batches(writer, n, jobs, args.batch_size, gen)

    writer.f.close()
    print("TTS done ->", root / "audio_raw")

    if args.finalize:
        subprocess.run([sys.executable, str(root / "scripts/finalize_manifests.py"),
                        "--root", str(root), "--raw_dir", "audio_raw", "--out_dir", "audio",
                        "--absolute"], check=True)
    else:
        print("Next: python scripts/finalize_manifests.py --absolute")


if __name__ == "__main__":
    main()
