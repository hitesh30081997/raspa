# ServiceRobot-SLU-CL

A small spoken-language-understanding dataset for **continual learning (CL)** on
`nvidia/slu_conformer_transformer_large_slurp` (NeMo `SLUIntentSlotBPEModel`).

* 4 domains (= 4 CL tasks) × 5 actions × 20 utterances = **400 utterances**, 20 new intents
* Labels in the exact format the model was trained on: a flattened Python dict with
  `scenario`, `action`, `entities[{type, filler}]` in the manifest `text` field
* Text is written in **spoken form** (lowercase, numbers spelled out, no punctuation),
  like SLURP, so it can go straight into a TTS model

## Domains, actions and entities

| Task | Scenario | Actions | Entity types |
|---|---|---|---|
| 1 | `navigation` | goto, follow, stop, return, guide | location, direction, distance, speed, person, time |
| 2 | `manipulation` | pick, place, fetch, handover, open | object, location, person, color, quantity |
| 3 | `housekeeping` | vacuum, mop, wipe, tidy, dispose | location, surface, object, time, date |
| 4 | `healthcare` | remind, alert, measure, checkon, assist | medicine, vital_sign, person, location, time, date, quantity, object |

Intent = `scenario_action` (e.g. `healthcare_remind`), same convention as SLURP.
No scenario name overlaps SLURP's 18 scenarios, so the original model's
classes (task 0) are kept separate from the new ones. Shared entity types (`location`,
`person`, `time`, `date`, `object`) are reused on purpose so slot knowledge carries over
between tasks. Full definitions are in `ontology/ontology.json`.

Deliberately confusable pairs are included to make forgetting measurable:
fetch vs handover ("hand me the scissors"), guide vs goto ("bring me to the x ray room"),
navigation stop vs healthcare alert ("emergency stop" vs "press the emergency button"),
remind vs alert ("alert me when my next dose is due").

## Folder structure

```
ServiceRobot-SLU-CL/
├── source/utterances_annotated.tsv   ← single source of truth (edit / extend here)
├── ontology/ontology.json            ← domains, actions, intents, entity types, task order
├── annotations/all_utterances.jsonl  ← SLURP-style: id, split, intent, sentence,
│                                        sentence_annotation, entities + word spans, semantics
├── tts/tts_script.csv                ← id, text, split, task, intent, output_wav
├── manifests/
│   ├── task_01_navigation/{train,dev,test}.json     ← NeMo manifests, one task per domain
│   ├── task_02_manipulation/...
│   ├── task_03_housekeeping/...
│   ├── task_04_healthcare/...
│   ├── cumulative/test_upto_task_0K.json            ← all tasks seen so far (forgetting eval)
│   ├── cumulative/dev_upto_task_0K.json
│   └── joint/{train,dev,test}_all.json              ← joint-training upper bound
└── scripts/
    ├── build_dataset.py          ← regenerates everything from the TSV
    ├── finalize_manifests.py     ← after TTS: 16 kHz mono, durations, multi-voice expansion
    └── make_replay_manifest.py   ← new-task train + balanced replay of old tasks (+ SLURP)
```

Split per action: **14 train / 3 dev / 3 test** (fixed seed), i.e. per task 70/15/15.

Manifest line (NeMo format):
```json
{"audio_filepath": "audio/task_01_navigation/nav_goto_01.wav", "offset": 0.0, "duration": 1.42,
 "text": "{'scenario': 'navigation', 'action': 'goto', 'entities': [{'type': 'location', 'filler': 'kitchen'}]}"}
```
`duration` is `0.0` until you run `finalize_manifests.py`.

## Workflow

1. **Synthesise audio** from `tts/tts_script.csv`, saving to
   `audio_raw/<task>/<id>.wav`, or one file per voice as `audio_raw/<task>/<id>__<voice>.wav`.
   Any sample rate is fine.
2. **Finalize**
   ```bash
   pip install soundfile scipy numpy
   python scripts/finalize_manifests.py --raw_dir audio_raw --out_dir audio --train_only_variants --absolute
   ```
   This converts everything to 16 kHz mono PCM-16 and rewrites all manifests with real durations.
   Each voice variant becomes its own manifest line. `--train_only_variants` keeps one voice
   for dev/test.
3. **Build the training manifest for each task** (optional replay):
   ```bash
   python scripts/make_replay_manifest.py --task 2 --per_intent 2 \
       --slurp_manifest /data/slurp/train_slu.json --slurp_samples 1000 \
       --out manifests/replay/train_task_02_replay.json
   ```

### TTS recommendations
* 70 training utterances per task is small. Use **4–8 different TTS voices** (accents,
  gender, speaking rate) for train, plus speed perturbation (0.9/1.0/1.1) and
  background noise (robot motors, hospital, kitchen, babble).
* Give dev/test **voices that never appear in train**, so you measure generalisation and
  not voice memorisation.
* TTS-only test sets overestimate accuracy. If you can, record a small real test set
  (same ids, `__real` suffix).

## Suggested continual-learning protocol

Sequence: **T0 (SLURP, pre-trained) → T1 navigation → T2 manipulation → T3 housekeeping → T4 healthcare**

For task k: initialise from the checkpoint of task k-1, train on `task_0k/train.json`
(or the replay manifest), validate on `cumulative/dev_upto_task_0k.json`. Then evaluate on
**every** task's test set plus the **SLURP test set** (task 0), and fill the accuracy matrix
R[i, j] = score on task j after training task i.

Report intent accuracy and SLU-F1 per task, then:
* Average accuracy after T4 = mean_j R[4, j]
* Backward transfer / forgetting = mean_j (R[4, j] − R[j, j]), j < 4, including SLURP
* Baselines: sequential fine-tuning (lower bound), `joint/train_all.json` + SLURP (upper bound)

Typical methods to compare: experience replay (script included), EWC / L2 regularisation,
freezing the encoder and training only the decoder, adapters / LoRA per task,
knowledge distillation from the previous checkpoint.

### NeMo notes
* Load the model with
  `nemo_asr.models.SLUIntentSlotBPEModel.from_pretrained("slu_conformer_transformer_large_slurp")`
  and fine-tune with the NeMo speech-intent-slot (SLURP) example training script and config,
  overriding `model.train_ds.manifest_filepath` and `model.validation_ds.manifest_filepath`.
* **Keep the pre-trained SentencePiece tokenizer.** New scenario, action and entity names are
  built from existing sub-word pieces. Retraining the tokenizer would invalidate the
  decoder's output layer and wipe out SLURP knowledge.
* Use a lower LR than training from scratch (e.g. 1e-4 to 2e-4, short warm-up) and few epochs
  per task. The dataset is tiny, so over-fitting and forgetting happen quickly.

## Extending to more domains
Append rows to `source/utterances_annotated.tsv` (`scenario<TAB>action<TAB>annotated sentence`),
add the scenario to `TASK_ORDER`, `PREFIX` and the description dicts in `build_dataset.py`,
then rerun `python scripts/build_dataset.py`. The builder checks for lowercase, spelled-out
numbers, duplicate sentences, fillers that match the sentence exactly, and 20 utterances per action.

Annotation syntax (SLURP style): `remind me to take my [medicine : pills] at [time : eight am]`
