#!/usr/bin/env python3
"""
Build the Service-Robot SLU continual-learning dataset from
source/utterances_annotated.tsv.

Outputs (relative to the dataset root):
  ontology/ontology.json            domains, actions, intents, entity types, task order
  annotations/all_utterances.jsonl  SLURP-style rich annotations (one line per utterance)
  tts/tts_script.csv                text to synthesise + target wav path
  manifests/task_XX_<domain>/{train,dev,test}.json   NeMo SLU manifests (one task per domain)
  manifests/cumulative/test_upto_task_XX.json        seen-so-far test sets (forgetting eval)
  manifests/cumulative/dev_upto_task_XX.json
  manifests/joint/{train,dev,test}_all.json          joint-training upper bound

The NeMo "text" field is the flattened semantics dict used by
nvidia/slu_conformer_transformer_large_slurp:
  "{'scenario': 'navigation', 'action': 'goto', 'entities': [{'type': 'location', 'filler': 'kitchen'}]}"

Durations are 0.0 placeholders until you run scripts/finalize_manifests.py after TTS.

Usage:  python scripts/build_dataset.py [--root .] [--seed 13] [--split 14 3 3]
"""
import argparse, csv, json, random, re
from collections import OrderedDict, defaultdict
from pathlib import Path

TASK_ORDER = ["navigation", "manipulation", "housekeeping", "healthcare"]
PREFIX = {"navigation": "nav", "manipulation": "man", "housekeeping": "hk", "healthcare": "hc"}
DOMAIN_DESC = {
    "navigation": "Moving the robot base: go to places, follow, stop, return to dock, guide people.",
    "manipulation": "Arm / gripper tasks: pick, place, fetch to user, hand over to a person, open things.",
    "housekeeping": "Cleaning tasks: vacuum, mop, wipe surfaces, tidy up, dispose of waste.",
    "healthcare": "Care assistance: medication reminders, emergency alerts, vital-sign measurement, checking on people, mobility assistance.",
}
ACTION_DESC = {
    ("navigation", "goto"): "Drive the base to a location or by a relative motion.",
    ("navigation", "follow"): "Follow / accompany the speaker or another person.",
    ("navigation", "stop"): "Halt current motion.",
    ("navigation", "return"): "Return to dock, base, charger or start point.",
    ("navigation", "guide"): "Lead / escort a person to a destination.",
    ("manipulation", "pick"): "Grasp and lift an object.",
    ("manipulation", "place"): "Put a held object at a location.",
    ("manipulation", "fetch"): "Bring an object to the speaker.",
    ("manipulation", "handover"): "Give / deliver an object to a third person or place.",
    ("manipulation", "open"): "Open a door, drawer, container or appliance.",
    ("housekeeping", "vacuum"): "Vacuum floors, carpets, rugs.",
    ("housekeeping", "mop"): "Wet-clean / mop floors and spills.",
    ("housekeeping", "wipe"): "Wipe, dust, polish or disinfect surfaces.",
    ("housekeeping", "tidy"): "Organise, declutter, put things away.",
    ("housekeeping", "dispose"): "Empty bins, take out trash, discard waste.",
    ("healthcare", "remind"): "Medication and routine health reminders.",
    ("healthcare", "alert"): "Emergency help / notify caregivers.",
    ("healthcare", "measure"): "Measure or report vital signs.",
    ("healthcare", "checkon"): "Check on / monitor a person.",
    ("healthcare", "assist"): "Physical mobility assistance.",
}
ANN_RE = re.compile(r"\[\s*([a-z_]+)\s*:\s*([^\]]+?)\s*\]")


def parse(annot):
    """'go to the [location : kitchen]' -> sentence, entities with word spans."""
    words, entities, pos = [], [], 0
    for m in ANN_RE.finditer(annot):
        words += annot[pos:m.start()].split()
        etype, filler = m.group(1), m.group(2).strip()
        fw = filler.split()
        entities.append({"type": etype, "filler": filler,
                         "span": list(range(len(words), len(words) + len(fw)))})
        words += fw
        pos = m.end()
    words += annot[pos:].split()
    return " ".join(words), entities


def semantics(scenario, action, entities):
    d = {"scenario": scenario, "action": action,
         "entities": [{"type": e["type"], "filler": e["filler"]} for e in entities]}
    return str(d)  # Python-dict string, exactly as the NeMo SLURP recipe expects


def validate(scenario, action, annot, sentence, entities):
    assert annot == annot.lower(), f"use lowercase: {annot}"
    assert not re.search(r"\d", sentence), f"spell numbers out for TTS/SLURP style: {sentence}"
    assert "[" not in sentence and "]" not in sentence, f"broken bracket: {annot}"
    for e in entities:
        assert "'" not in e["filler"], f"apostrophe in filler breaks dict string: {annot}"
        toks = sentence.split()
        assert " ".join(toks[i] for i in e["span"]) == e["filler"], annot


def write_manifest(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps({"audio_filepath": r["audio_filepath"], "offset": 0.0,
                                "duration": r["duration"], "text": r["semantics"]}) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--split", type=int, nargs=3, default=[14, 3, 3], metavar=("TRAIN", "DEV", "TEST"))
    args = ap.parse_args()
    root = Path(args.root)

    groups = OrderedDict()
    with open(root / "source/utterances_annotated.tsv") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            groups.setdefault((row["scenario"], row["action"]), []).append(row["sentence_annotation"].strip())

    rng = random.Random(args.seed)
    records, ontology_entities = [], defaultdict(set)
    seen_sent = set()
    for (scen, act), annots in groups.items():
        n_tr, n_dv, n_te = args.split
        assert len(annots) == n_tr + n_dv + n_te, f"{scen}/{act} has {len(annots)} utterances"
        order = list(range(len(annots)))
        rng.shuffle(order)
        split_of = {}
        for k, i in enumerate(order):
            split_of[i] = "train" if k < n_tr else ("dev" if k < n_tr + n_dv else "test")
        task_idx = TASK_ORDER.index(scen) + 1
        task_dir = f"task_{task_idx:02d}_{scen}"
        for i, annot in enumerate(annots):
            sent, ents = parse(annot)
            validate(scen, act, annot, sent, ents)
            assert sent not in seen_sent, f"duplicate sentence: {sent}"
            seen_sent.add(sent)
            for e in ents:
                ontology_entities[scen].add(e["type"])
            uid = f"{PREFIX[scen]}_{act}_{i + 1:02d}"
            records.append({
                "id": uid, "task_id": task_idx, "task": task_dir, "split": split_of[i],
                "scenario": scen, "action": act, "intent": f"{scen}_{act}",
                "sentence": sent, "sentence_annotation": annot,
                "entities": ents, "semantics": semantics(scen, act, ents),
                "audio_filepath": f"audio/{task_dir}/{uid}.wav", "duration": 0.0,
            })

    # ---- ontology
    onto = {
        "name": "ServiceRobot-SLU-CL", "version": "1.0",
        "base_model": "nvidia/slu_conformer_transformer_large_slurp",
        "audio": {"sample_rate": 16000, "channels": 1, "format": "wav (PCM 16-bit)"},
        "task_0": "SLURP (the pre-trained model's original 18 scenarios; use for replay / backward-transfer eval)",
        "task_order": [f"task_{i + 1:02d}_{d}" for i, d in enumerate(TASK_ORDER)],
        "split_per_action": dict(zip(["train", "dev", "test"], args.split)),
        "domains": {},
    }
    for d in TASK_ORDER:
        acts = [a for (s, a) in groups if s == d]
        onto["domains"][d] = {
            "task_id": TASK_ORDER.index(d) + 1, "description": DOMAIN_DESC[d],
            "actions": {a: ACTION_DESC[(d, a)] for a in acts},
            "intents": [f"{d}_{a}" for a in acts],
            "entity_types": sorted(ontology_entities[d]),
        }
    onto["all_entity_types"] = sorted(set().union(*ontology_entities.values()))
    (root / "ontology").mkdir(exist_ok=True)
    json.dump(onto, open(root / "ontology/ontology.json", "w"), indent=2)

    # ---- rich annotations
    (root / "annotations").mkdir(exist_ok=True)
    with open(root / "annotations/all_utterances.jsonl", "w") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")

    # ---- TTS script
    (root / "tts").mkdir(exist_ok=True)
    with open(root / "tts/tts_script.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "text", "split", "task", "intent", "output_wav"])
        for r in records:
            w.writerow([r["id"], r["sentence"], r["split"], r["task"], r["intent"], r["audio_filepath"]])

    # ---- manifests
    man = root / "manifests"
    by = lambda task=None, split=None, max_task=None: [
        r for r in records
        if (task is None or r["task"] == task) and (split is None or r["split"] == split)
        and (max_task is None or r["task_id"] <= max_task)]
    for i, d in enumerate(TASK_ORDER, 1):
        td = f"task_{i:02d}_{d}"
        for sp in ("train", "dev", "test"):
            write_manifest(man / td / f"{sp}.json", by(task=td, split=sp))
        write_manifest(man / "cumulative" / f"test_upto_task_{i:02d}.json", by(split="test", max_task=i))
        write_manifest(man / "cumulative" / f"dev_upto_task_{i:02d}.json", by(split="dev", max_task=i))
    for sp in ("train", "dev", "test"):
        write_manifest(man / "joint" / f"{sp}_all.json", by(split=sp))

    # ---- summary
    cnt = defaultdict(int)
    for r in records:
        cnt[(r["task"], r["split"])] += 1
    print(f"{len(records)} utterances, {len(groups)} intents, "
          f"{len(onto['all_entity_types'])} entity types")
    for t in onto["task_order"]:
        print(f"  {t:26s} train={cnt[(t,'train')]:3d} dev={cnt[(t,'dev')]:3d} test={cnt[(t,'test')]:3d}")


if __name__ == "__main__":
    main()
