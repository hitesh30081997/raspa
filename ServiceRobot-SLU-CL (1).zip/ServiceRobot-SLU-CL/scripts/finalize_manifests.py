#!/usr/bin/env python3
"""
Run AFTER TTS. Converts every synthesised wav to 16 kHz mono PCM-16 (what the
NeMo SLURP model expects), measures durations, and rewrites all manifests.

Multi-speaker augmentation is supported: for an utterance with id `nav_goto_01`
you may put any of these in audio_raw/<task>/ :
    nav_goto_01.wav                      (single voice)
    nav_goto_01__<voice>.wav             (one file per TTS voice, e.g. __v1, __female_us)
Every variant found becomes its own manifest line (same label), for train, dev and test.
Use --train_only_variants to keep only the first voice for dev/test.

Usage:
  python scripts/finalize_manifests.py --raw_dir audio_raw --out_dir audio [--absolute]
Requires: pip install soundfile scipy numpy
"""
import argparse, json, glob
from math import gcd
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

TARGET_SR = 16000


def to_16k_mono(src, dst):
    wav, sr = sf.read(src, dtype="float32", always_2d=True)
    wav = wav.mean(axis=1)
    if sr != TARGET_SR:
        g = gcd(sr, TARGET_SR)
        wav = resample_poly(wav, TARGET_SR // g, sr // g)
    peak = np.abs(wav).max() or 1.0
    if peak > 0.99:
        wav = wav / peak * 0.95
    dst.parent.mkdir(parents=True, exist_ok=True)
    sf.write(dst, wav, TARGET_SR, subtype="PCM_16")
    return len(wav) / TARGET_SR


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--raw_dir", default="audio_raw", help="TTS output, same <task>/<id>[__voice].wav layout")
    ap.add_argument("--out_dir", default="audio")
    ap.add_argument("--absolute", action="store_true", help="write absolute audio paths in manifests")
    ap.add_argument("--train_only_variants", action="store_true")
    args = ap.parse_args()
    root = Path(args.root)
    raw, out = root / args.raw_dir, root / args.out_dir

    recs = [json.loads(l) for l in open(root / "annotations/all_utterances.jsonl")]
    lines, missing = {}, []
    for r in recs:
        cands = sorted(glob.glob(str(raw / r["task"] / f"{r['id']}.wav")) +
                       glob.glob(str(raw / r["task"] / f"{r['id']}__*.wav")))
        if not cands:
            missing.append(r["id"]); continue
        if args.train_only_variants and r["split"] != "train":
            cands = cands[:1]
        entries = []
        for c in cands:
            dst = out / r["task"] / Path(c).name
            dur = to_16k_mono(c, dst)
            p = str(dst.resolve()) if args.absolute else str(dst.relative_to(root))
            entries.append({"audio_filepath": p, "offset": 0.0, "duration": round(dur, 3), "text": r["semantics"]})
        lines[r["id"]] = entries

    # rewrite every manifest by mapping its placeholder lines to the real ones
    n_files = 0
    for mf in sorted((root / "manifests").rglob("*.json")):
        new = []
        for l in open(mf):
            uid = Path(json.loads(l)["audio_filepath"]).stem
            new += lines.get(uid, [])
        with open(mf, "w") as f:
            for e in new:
                f.write(json.dumps(e) + "\n")
        n_files += 1
        print(f"{str(mf.relative_to(root)):55s} {len(new):5d} lines  {sum(e['duration'] for e in new)/60:6.1f} min")
    if missing:
        print(f"WARNING: {len(missing)} utterances have no audio yet (left out of manifests), e.g. {missing[:5]}")
    print(f"Rewrote {n_files} manifests.")


if __name__ == "__main__":
    main()
