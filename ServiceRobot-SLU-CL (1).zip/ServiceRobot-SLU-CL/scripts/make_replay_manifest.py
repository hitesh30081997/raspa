#!/usr/bin/env python3
"""
Build the training manifest for continual-learning task k with experience replay:
    new task k train  +  a small, intent-balanced sample from every earlier task
    (task 0 = original SLURP train manifest produced by NeMo's SLURP prep scripts).

Example (task 3 = housekeeping, keep 2 utterances per old intent, 1500 SLURP lines):
  python scripts/make_replay_manifest.py --task 3 --per_intent 2 \
      --slurp_manifest /data/slurp/train_slu.json --slurp_samples 1500 \
      --out manifests/replay/train_task_03_replay.json

Set --per_intent 0 and --slurp_samples 0 for the plain fine-tuning (no replay) baseline.
"""
import argparse, ast, json, random
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def intent_of(line):
    s = ast.literal_eval(json.loads(line)["text"])
    return f"{s['scenario']}_{s['action']}"


def balanced_sample(lines, per_intent, rng):
    byi = defaultdict(list)
    for l in lines:
        byi[intent_of(l)].append(l)
    out = []
    for k in sorted(byi):
        rng.shuffle(byi[k])
        out += byi[k][:per_intent]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", type=int, required=True, help="current task id (1..4)")
    ap.add_argument("--per_intent", type=int, default=2, help="replay utterances per old intent (tasks 1..k-1)")
    ap.add_argument("--slurp_manifest", default=None, help="NeMo-format SLURP train manifest for task 0 replay")
    ap.add_argument("--slurp_samples", type=int, default=0)
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    onto = json.load(open(ROOT / "ontology/ontology.json"))
    tasks = onto["task_order"]

    cur = open(ROOT / "manifests" / tasks[a.task - 1] / "train.json").read().splitlines()
    replay = []
    for t in tasks[: a.task - 1]:
        old = open(ROOT / "manifests" / t / "train.json").read().splitlines()
        replay += balanced_sample(old, a.per_intent, rng)
    if a.slurp_manifest and a.slurp_samples:
        sl = open(a.slurp_manifest).read().splitlines()
        rng.shuffle(sl)
        replay += sl[: a.slurp_samples]

    allx = cur + replay
    rng.shuffle(allx)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text("\n".join(allx) + "\n")
    print(f"task {a.task}: {len(cur)} new + {len(replay)} replay = {len(allx)} lines -> {a.out}")


if __name__ == "__main__":
    main()
