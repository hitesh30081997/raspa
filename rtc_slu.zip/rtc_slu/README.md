# RTC-SLU: Noise-aware tensor decomposition of the NeMo Conformer SLURP model

This repo implements the "Robust Tucker-Conformer" plan for `slu_conformer_transformer_large_slurp`:

1. **Semantic core.** The encoder's dense layers are factorized, starting from the pretrained weights, with Tensor-Train, Tucker or SVD.
2. **Healing.** The factorized core is fine-tuned on clean SLURP, distilled from the uncompressed teacher.
3. **Noise residual.** The core is frozen and small parallel noise adapters are trained on noisy SLURP.

Evaluation uses the official SLURP metrics, with significance testing and a detailed error analysis.

## What was verified (and what was not)

| Check | Status |
|---|---|
| SLURP metrics equal the official `pswietojanski/slurp` scorer (scenario/action/intent, span-F1, word/char-distance F1, SLU-F1, micro and macro) | ✅ `tests/test_metrics.py`, 3,000 random utterances, difference < 1e-9 |
| Full-rank TT / Tucker / SVD / Tucker-2 reproduce the dense layers exactly, in both execution modes | ✅ `tests/test_tensor_layers.py` |
| Surgery on the **real NeMo classes**: the regexes hit every intended module; full-rank decomposition of the whole encoder gives identical output; adapters start as an exact identity; gradients reach only adapters; checkpoints round-trip | ✅ `tests/test_surgery.py` |
| Every experiment config runs end to end (train → decode → analysis → comparison) | ✅ `tests/smoke/run_smoke.sh`, on a tiny model with the same architecture and synthetic audio, CPU |
| Parameter accounting on the full-size architecture (127.8M, same as the NGC model) | ✅ numbers below |
| Accuracy on real (noisy) SLURP | ❌ Not run here: needs your data and a GPU |

## Facts about the brief you should know before writing the paper

These come from measuring the code. They are not opinions.

1. **The feed-forward modules are ~66% of each Conformer block.** If you decompose only the conv modules and MHSA, as the brief suggests, the encoder shrinks by at most ~30%. The "~70% reduction" requires factorizing the FFNs too, and that is what the default config does.
2. **Measured parameter counts with the default config** (`configs/base.yaml`), on the full architecture:

   | | Total | Encoder | Decoder |
   |---|---|---|---|
   | Original | 127.8M | 115.1M | 12.7M |
   | Compressed (TT FFN 0.15, Tucker attention 0.3, …) | 36.1M (**3.5×**) | 23.4M (**4.9×**) | 12.7M |
   | + rank-8 noise adapters (170 of them) | 38.4M (3.3×) | | |

   The uncompressed decoder is a floor. "6× smaller" overall needs an encoder of about 8.6M (≈13×). Use the sweep (`RTC_tt_sweep.yaml`) and report the Pareto curve rather than a single headline.
3. **Fewer parameters does not mean fewer FLOPs.** At these ranks, sequential TT contraction costs *more* multiply-accumulates (MACs) than the dense GEMM. The efficiency report therefore counts the cheaper of the two paths per layer. With the default config, encoder linear MACs per frame fall only from 107M to 92M. Claim **storage/memory** savings; claim latency only from the measured RTF in `summary.json`.
4. **The adapters cannot be merged** into the weights afterwards, because of the ReLU. Their cost is included in the parameter and MAC numbers.
5. **"Outperforms Conformer-Large in noise" is a hypothesis, not a given.** The comparisons that test it are:
   - **B1**: full multi-condition fine-tuning, uncompressed.
   - **B2**: adapters without compression.
   - **C3**: the compressed model trained on the same noisy data, without the core/residual split.

   If RTC_tt does not beat C3, the split is not what helps. `significance.md` shows paired tests for every pair.
6. **Healing is needed.** Freezing the core immediately after the SVD-based initialisation (the brief's original plan, kept as `RTC_tt_noheal`) starts from a degraded core. C0 shows how much the compression alone costs.

## Setup

```bash
pip install -r requirements.txt   # pins nemo_toolkit 2.7.3; newer NeMo dropped SLUIntentSlotBPEModel
```

NeMo 2.7.3 has two bugs in its SLU code: its greedy decoder and its Transformer decoder now return tuples. Its own `training_step` breaks on the second. This repo works around both by running its own teacher-forced forward pass (`rtc/train.py`) and its own prediction (`rtc/evaluate.py`), which follow NeMo's logic.

## Data

The code reads NeMo SLU manifests, the format NeMo's SLURP recipe produces (`text` = the semantics dict as a string). If your noisy copies sit in folders, build every manifest with:

```bash
python scripts/prepare_manifests.py \
  --slurp_dir /data/slurp/dataset/slurp --clean_audio /data/slurp/audio \
  --noisy_pattern "/data/slurp_noisy/{split}/{cond}/{stem}.wav" \
  --conditions "snr_20:20,snr_10:10,snr_5:5,snr_0:0" [--noise_types babble,music,ambient] \
  --out data/manifests
```

`--noisy_pattern` accepts `{split} {cond} {snr} {noise} {stem} {real}`, so most folder layouts work. The output includes:

- clean train/dev/test manifests
- pooled `train_noisy_slu.json` and `devel_noisy_slu.json`
- one `test_snrX_slu.json` per condition

Each line is tagged with `snr`, `noise_type` and `recording`. If you already have manifests, point `data.*` in `configs/base.yaml` at them.

Model selection uses the **dev** sets only (the noisy dev set for noisy stages). The test sets are never used for selection.

## Running

```bash
bash scripts/run_all.sh data.root=data/manifests device=cuda:0      # full matrix + comparison
# or one system:
python scripts/run_experiment.py --config configs/experiments/RTC_tt.yaml data.root=data/manifests
```

| Config | Role |
|---|---|
| `B0_pretrained` | Reference: the NGC model, zero-shot |
| `B1_full_ft_noisy` | Upper bound: uncompressed, all 127M parameters fine-tuned on clean+noisy |
| `B2_adapters_uncompressed` | Adapter effect without compression |
| `C0_tt_raw` | Decomposition only, no training |
| `C1_tt_heal` | Compressed core healed on clean data with KD; its checkpoint seeds C2 and RTC_tt |
| `C2_tt_heal_fullft_noisy` | **Ablation 1**: full fine-tuning instead of adapters |
| `C3_tt_multicondition` | Strong baseline: compressed, multi-condition training, no core/residual split |
| `RTC_tt` | **Proposed** |
| `RTC_tt_noheal` | The brief's original recipe |
| `RTC_tucker`, `RTC_svd` | **Ablation 2**: decomposition family at an equal per-group budget (SVD is the matrix baseline reviewers will ask for) |
| `RTC_tt_sweep` | **Ablation 3**: compression sweep for the Pareto plot |

The decoding defaults to NeMo's published setting (beam 32, temperature 1.25), which gave 90.14 intent accuracy / 82.27 SLU-F1. **Run B0 on your clean test set first and check you get close to those numbers before anything else.** For quick sweeps, use `evaluation.test_decoding="{type: greedy}"`.

Several `--config` files are merged left to right, and `key=value` overrides can follow them (e.g. `device=cuda:1 evaluation.bootstrap=2000`). A `stages` list is replaced as a whole, not merged. Use `--eval_only` to re-score and re-analyse cached predictions without decoding again.

## Outputs

Each system writes `exp/<name>/results/`:

- `report.md` and `summary.json`, containing:
  1. the standard SLURP table per condition (scenario, action and intent accuracy; intent macro-F1; span P/R/F1; word- and char-distance F1; SLU P/R/F1; rate of unparsable outputs)
  2. 95% bootstrap CIs
  3. robustness vs. clean (absolute drop, retention %, mean over noisy conditions)
  4. the slot types that degrade most under noise
  5. intent errors split into scenario-only, action-only, both, and invalid output
  6. a slot error taxonomy: wrong value (acoustic), wrong slot type (NLU), missed, spurious
  7. breakdowns by microphone (headset vs far-field), number of slots, duration, noise type and SNR tag
  8. the top intent confusions
- `figures/`: robustness curve with CI bands, slot-error taxonomy, per-scenario and per-slot-type heatmaps
- `tables/*.csv`: the same numbers in tabular form
- `predictions/<cond>.jsonl`, plus `<cond>.official.jsonl` for the official scorer: `python slurp/scripts/evaluation/evaluate.py -g test.jsonl -p <cond>.official.jsonl`
- `summary.json → efficiency`: parameter counts, fp32/fp16/int8 storage, encoder MACs per frame, measured encoder RTF in dense and factorized mode
- `decomposition_report.json`: per-layer rank, parameter count and reconstruction error. This is useful for a "which layers compress well" figure.

`scripts/compare_systems.py` writes `exp/_comparison/`:

- `master_table.md/.csv/.tex`: params, trained params, compression, and IA / SLU-F1 per condition
- `significance.md`: the proposed system vs every other, with paired bootstrap on SLU-F1 (CI of the difference) and exact McNemar on intent
- `snr_curves.png` and `pareto_<cond>.png`

## Layout

```
rtc/tensor_layers.py   TTLinear (TT-SVD), TuckerLinear (HOSVD+HOOI, per-head layout), LowRankLinear, Tucker2Conv2d
rtc/decompose.py       module targeting, surgery, trainability policies, BatchNorm freezing, checkpoint rebuild
rtc/adapters.py        ParallelNoiseAdapter (zero-initialised up-projection)
rtc/train.py           staged training, KD (token KL + encoder-feature MSE), dev-based selection, early stopping
rtc/slurp_metrics.py   official-equivalent SLURP metrics, kept per utterance
rtc/analysis.py        breakdowns, bootstrap CIs, paired tests, figures, report
rtc/evaluate.py        decoding and scoring;  rtc/efficiency.py: params, MACs, latency
```

Tests: `pytest tests/` runs the surgery tests (after `python tests/make_tiny_fixture.py /tmp/rtc_fixture <NeMo conformer_transformer_large_bpe.yaml>`), the metric tests (needs a clone of the official SLURP repo; set `SLURP_EVAL_DIR`) and the layer tests. `tests/smoke/run_smoke.sh` runs the full pipeline on a tiny model.
