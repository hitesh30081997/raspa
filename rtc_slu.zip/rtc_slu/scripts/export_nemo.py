#!/usr/bin/env python
"""Write a .nemo file from a checkpoint of an UNCOMPRESSED, adapter-free system (e.g. B1_full_ft_noisy).
Compressed / adapter models are not representable in NeMo's config; keep using their .pt checkpoints.

  python scripts/export_nemo.py --base_nemo base.nemo --ckpt exp/B1_full_ft_noisy/checkpoints/final.pt --out b1.nemo
"""
import argparse

import torch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_nemo", help="the .nemo the experiment started from (default: NGC model)")
    ap.add_argument("--pretrained_name", default="slu_conformer_transformer_large_slurp")
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    from nemo.collections.asr.models import SLUIntentSlotBPEModel
    m = (SLUIntentSlotBPEModel.restore_from(a.base_nemo, map_location="cpu") if a.base_nemo
         else SLUIntentSlotBPEModel.from_pretrained(a.pretrained_name, map_location="cpu"))
    ck = torch.load(a.ckpt, map_location="cpu", weights_only=False)
    s = ck.get("surgery") or {}
    if s.get("specs") or s.get("adapters"):
        raise SystemExit("checkpoint contains factorized layers/adapters; cannot export to .nemo")
    m.load_state_dict(ck["state_dict"], strict=True)
    m.save_to(a.out)
    print("saved", a.out)


if __name__ == "__main__":
    main()
