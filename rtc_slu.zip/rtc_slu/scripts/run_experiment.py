#!/usr/bin/env python
"""
Run one system end to end:  load -> (decompose) -> (adapters) -> stages -> test on every condition -> analysis.

  python scripts/run_experiment.py --config configs/experiments/rtc_tt.yaml
  python scripts/run_experiment.py --config configs/experiments/rtc_tt.yaml data.root=/data/slurp_noisy device=cuda:0
  python scripts/run_experiment.py --config ... --eval_only          # re-score/re-analyse cached predictions
"""
import argparse
import json
import os
import random
import sys
import time

import numpy as np
import torch
from omegaconf import OmegaConf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from rtc.analysis import analyze_system  # noqa: E402
from rtc.decompose import apply_adapters, decompose_model, restore_surgery, surgery_state  # noqa: E402
from rtc.efficiency import efficiency_report  # noqa: E402
from rtc.evaluate import evaluate_sets  # noqa: E402
from rtc.train import train_stage  # noqa: E402


def load_cfg(paths, overrides):
    """base.yaml <- each --config file in order <- CLI dotlist (lists such as `stages` are replaced, not merged)."""
    layers = [OmegaConf.load(os.path.join(ROOT, "configs", "base.yaml"))] + [OmegaConf.load(p) for p in paths]
    cfg = OmegaConf.merge(*layers, OmegaConf.from_dotlist(overrides))
    OmegaConf.resolve(cfg)
    return OmegaConf.to_container(cfg, resolve=True)


class Logger:
    def __init__(self, path):
        self.f = open(path, "a")

    def __call__(self, msg):
        line = f"{time.strftime('%H:%M:%S')} {msg}"
        print(line, flush=True)
        self.f.write(line + "\n")
        self.f.flush()


def load_base_model(cfg, log):
    from nemo.collections.asr.models import SLUIntentSlotBPEModel
    p = cfg["pretrained"]
    if p.get("nemo_path"):
        log(f"[model] restoring {p['nemo_path']}")
        m = SLUIntentSlotBPEModel.restore_from(p["nemo_path"], map_location="cpu")
    else:
        log(f"[model] downloading pretrained {p['name']}")
        m = SLUIntentSlotBPEModel.from_pretrained(p["name"], map_location="cpu")
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, nargs="+", help="experiment yaml(s), merged left to right")
    ap.add_argument("--eval_only", action="store_true", help="skip training; load out_dir/checkpoints/final.pt")
    ap.add_argument("--no_latency", action="store_true")
    ap.add_argument("overrides", nargs="*")
    a = ap.parse_args()
    overrides = list(a.overrides) + [c for c in a.config if "=" in c]  # key=value pairs may follow --config files
    cfg = load_cfg([c for c in a.config if "=" not in c], overrides)
    out = cfg["output_dir"]
    os.makedirs(os.path.join(out, "checkpoints"), exist_ok=True)
    log = Logger(os.path.join(out, "log.txt"))
    with open(os.path.join(out, "config.resolved.yaml"), "w") as f:
        f.write(OmegaConf.to_yaml(OmegaConf.create(cfg)))
    random.seed(cfg["seed"])
    np.random.seed(cfg["seed"])
    torch.manual_seed(cfg["seed"])
    device = cfg["device"] if (torch.cuda.is_available() or not cfg["device"].startswith("cuda")) else "cpu"
    cfg["device"] = device
    log(f"===== {cfg['name']} on {device} =====")

    model = load_base_model(cfg, log)
    needs_teacher = any((s.get("kd") or {}).get("enabled") for s in cfg.get("stages") or []) and not a.eval_only
    # NeMo models cannot be deep-copied; load a second, untouched copy as the distillation teacher
    teacher = load_base_model(cfg, log).to(device).eval() if needs_teacher else None
    if teacher is not None:
        for p in teacher.parameters():
            p.requires_grad_(False)

    final_ckpt = os.path.join(out, "checkpoints", "final.pt")
    if a.eval_only:
        init_ckpt = final_ckpt if os.path.exists(final_ckpt) else None
    else:
        init_ckpt = cfg.get("init_checkpoint")
    reports = {}
    if init_ckpt:
        log(f"[model] initialising from {init_ckpt}")
        ck = torch.load(init_ckpt, map_location="cpu", weights_only=False)
        restore_surgery(model, ck["surgery"], cfg["compression"].get("forward_mode", "dense"), log)
        model.load_state_dict(ck["state_dict"], strict=True)
        reports["decomposition"] = ck.get("decomposition_report")
        surgery_adapters = (ck["surgery"] or {}).get("adapters")
    else:
        surgery_adapters = None
        if cfg["compression"]["enabled"]:
            reports["decomposition"] = decompose_model(model, cfg["compression"], log)
    adapter_cfg = surgery_adapters
    if cfg["adapters"]["enabled"] and not surgery_adapters:
        reports["adapters"] = apply_adapters(model, cfg["adapters"], log)
        adapter_cfg = cfg["adapters"]
    model.to(device)
    if reports.get("decomposition"):
        with open(os.path.join(out, "decomposition_report.json"), "w") as f:
            json.dump(reports["decomposition"], f, indent=1)

    def save(path, stage):
        torch.save({"state_dict": model.state_dict(), "surgery": surgery_state(model, adapter_cfg), "stage": stage,
                    "decomposition_report": reports.get("decomposition"), "config": cfg}, path)

    histories = []
    if not a.eval_only:
        for stage in cfg.get("stages") or []:
            h = train_stage(model, stage, cfg, out, teacher=teacher, log=log)
            histories.append(h)
            save(os.path.join(out, "checkpoints", f"{stage['name']}.pt"), stage["name"])
        save(final_ckpt, "final")
        with open(os.path.join(out, "train_history.json"), "w") as f:
            json.dump(histories, f, indent=1)
    del teacher

    # ---- test -------------------------------------------------------------------------------------------------
    test_sets = {k: v for k, v in cfg["data"]["test"].items() if v}
    by_cond = evaluate_sets(model, test_sets, os.path.join(out, "results"), cfg, cfg["evaluation"]["test_decoding"],
                            log=log, reuse=cfg["evaluation"].get("reuse_predictions", True))
    summary = analyze_system(by_cond, os.path.join(out, "results"), cfg["evaluation"].get("reference_condition", "clean"),
                             cfg["evaluation"].get("bootstrap", 1000), cfg["name"])
    eff = efficiency_report(model, device, measure=not a.no_latency)
    hist_path = os.path.join(out, "train_history.json")
    if os.path.exists(hist_path):
        with open(hist_path) as f:
            hs = [h for h in json.load(f) if h]
        summary["trainable_last_stage_M"] = hs[-1]["trainable_params"] / 1e6 if hs else 0.0
        summary["training"] = [{k: h.get(k) for k in ("stage", "trainable_params", "total_steps", "best_dev")} for h in hs]
    else:
        summary["trainable_last_stage_M"] = 0.0
    summary["efficiency"] = eff
    if reports.get("decomposition"):
        dec = reports["decomposition"]
        summary["decomposition"] = {
            "n_modules": len(dec), "dense_params": sum(r["dense_params"] for r in dec),
            "factor_params": sum(r["factor_params"] for r in dec),
            "mean_rel_error_by_group": {g: float(np.mean([r["rel_error"] for r in dec if r["group"] == g]))
                                        for g in sorted({r["group"] for r in dec})}}
    with open(os.path.join(out, "results", "summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    p = eff["params"]
    log(f"[done] params total={p['total'] / 1e6:.2f}M encoder={p['encoder'] / 1e6:.2f}M "
        f"adapters={p['adapters'] / 1e6:.3f}M | report: {os.path.join(out, 'results', 'report.md')}")


if __name__ == "__main__":
    main()
