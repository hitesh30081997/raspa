#!/usr/bin/env bash
# Full experiment matrix. Pass common overrides once, e.g.:
#   bash scripts/run_all.sh data.root=/data/slurp_manifests device=cuda:0
# Systems are independent except: C2 and RTC_tt start from C1's checkpoint.
set -euo pipefail
cd "$(dirname "$0")/.."
X=("$@")
run() { python scripts/run_experiment.py --config "configs/experiments/$1.yaml" "${X[@]}" "${@:2}"; }

run B0_pretrained                 # reference: uncompressed, zero-shot
run C0_tt_raw                     # compression only
run C1_tt_heal                    # compressed core healed on clean (+KD)   -> checkpoint reused below
run RTC_tt                        # PROPOSED: frozen core + noise adapters
run C2_tt_heal_fullft_noisy       # ablation 1: full fine-tuning instead of adapters
run C3_tt_multicondition          # strong baseline: compressed, multi-condition training, no split
run RTC_tt_noheal                 # the brief's original recipe (no healing)
run B1_full_ft_noisy              # upper bound: uncompressed, fully fine-tuned on noisy
run B2_adapters_uncompressed      # adapters without compression
run RTC_tucker                    # ablation 2: decomposition family
run RTC_svd                       #             (matrix SVD baseline at equal budget)

# ablation 3: compression sweep for the Pareto plot (FFN dominates the parameter count)
for r in 0.30 0.08 0.04; do
  run RTC_tt_sweep name=RTC_tt_ffn${r} compression.groups.ffn.ratio=${r}
done

python scripts/compare_systems.py --exp_root exp --reference B0_pretrained --proposed RTC_tt --pareto_condition snr_0
