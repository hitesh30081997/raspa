#!/usr/bin/env python
"""
Build NeMo SLU manifests (clean + noisy) for this project.

Inputs
  --slurp_dir   folder with the SLURP release annotations: train.jsonl, train_synthetic.jsonl, devel.jsonl, test.jsonl
  --clean_audio folder containing slurp_real/ and slurp_synth/ (flac or wav; extension auto-detected)
  --noisy_pattern  where your noise-augmented copies live, with placeholders
                     {split}  train | train_synthetic | devel | test
                     {cond}   a condition name from --conditions (e.g. snr_5)
                     {noise}  a noise type from --noise_types (optional)
                     {stem}   recording name without extension, e.g. audio-1490191220-headset
                     {real}   slurp_real | slurp_synth
                   e.g.  /data/slurp_noisy/{split}/{cond}/{stem}.wav
                         /data/slurp_noisy/{noise}/snr{snr}/{real}/{stem}.flac   (with {snr} from --conditions)
  --conditions  name:snr pairs, e.g. "snr_20:20,snr_10:10,snr_5:5,snr_0:0"
  --noise_types optional list, e.g. "babble,music,ambient"

Outputs (in --out)
  train_slu.json train_synthetic_slu.json devel_slu.json test_slu.json        clean (same as NeMo's recipe)
  train_noisy_slu.json devel_noisy_slu.json                                    all conditions pooled
  test_<cond>_slu.json  (e.g. test_snr5_slu.json)                              one test set per condition
Each line has audio_filepath, duration, text (semantics dict as a string), transcript, slurp_id, recording,
and for noisy sets snr / noise_type, so the analysis can break results down by them.
"""
import argparse
import json
import os
import sys

SPLITS = ["train", "train_synthetic", "devel", "test"]


def semantics(obj):
    """Exactly as NeMo scripts/dataset_processing/process_slurp_data.py (fillers/types lower-cased)."""
    ann = obj["sentence_annotation"]
    ents = []
    for k in range(ann.count("[")):
        seg = ann.split("[")[k + 1].split("]")[0]
        t, fl = seg.split(":")[0].strip(), seg.split(":")[1].strip()
        ents.append({"type": t.lower(), "filler": fl.lower()})
    return str({"scenario": obj["scenario"], "action": obj["action"], "entities": ents})


def find_audio(base_wo_ext):
    for ext in (".flac", ".wav"):
        if os.path.exists(base_wo_ext + ext):
            return base_wo_ext + ext
    return None


def duration(path):
    import soundfile as sf
    return float(sf.info(path).duration)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--slurp_dir", required=True)
    ap.add_argument("--clean_audio", required=True)
    ap.add_argument("--noisy_pattern", default=None)
    ap.add_argument("--conditions", default="snr_20:20,snr_10:10,snr_5:5,snr_0:0")
    ap.add_argument("--noise_types", default="")
    ap.add_argument("--noisy_splits", default="train,train_synthetic,devel,test",
                    help="splits that have noisy copies (synthetic speech is often not augmented)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--relative", action="store_true", help="write paths relative to --out")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    conds = [tuple(c.split(":")) for c in a.conditions.split(",") if c]
    noises = [n for n in a.noise_types.split(",") if n] or [None]
    noisy_splits = set(a.noisy_splits.split(","))

    def rel(p):
        return os.path.relpath(p, a.out) if a.relative else os.path.abspath(p)

    stats = {}
    noisy_pool = {"train": [], "devel": []}
    for split in SPLITS:
        src = os.path.join(a.slurp_dir, f"{split}.jsonl")
        if not os.path.exists(src):
            print(f"skip {split}: {src} not found")
            continue
        real = "slurp_synth" if "synthetic" in split else "slurp_real"
        clean, noisy_by_cond, missing = [], {c[0]: [] for c in conds}, 0
        with open(src) as f:
            for line in f:
                if not line.strip():
                    continue
                obj = json.loads(line)
                sem = semantics(obj)
                for rec in obj["recordings"]:
                    stem = os.path.splitext(rec["file"])[0]
                    base = {"text": sem, "transcript": obj["sentence"], "slurp_id": str(obj["slurp_id"]),
                            "recording": rec["file"]}
                    p = find_audio(os.path.join(a.clean_audio, real, stem))
                    if p is None:
                        missing += 1
                    else:
                        clean.append({"audio_filepath": rel(p), "duration": duration(p), **base})
                    if not a.noisy_pattern or split not in noisy_splits:
                        continue
                    for cname, snr in conds:
                        for nt in noises:
                            pat = a.noisy_pattern.format(split=split, cond=cname, snr=snr, noise=nt or "",
                                                         stem=stem, real=real)
                            q = pat if os.path.exists(pat) else find_audio(os.path.splitext(pat)[0])
                            if q is None:
                                missing += 1
                                continue
                            it = {"audio_filepath": rel(q), "duration": duration(q), **base, "snr": float(snr)}
                            if nt:
                                it["noise_type"] = nt
                            noisy_by_cond[cname].append(it)

        def write(name, items):
            with open(os.path.join(a.out, name), "w") as g:
                for it in items:
                    g.write(json.dumps(it) + "\n")
            stats[name] = len(items)

        write(f"{split}_slu.json", clean)
        if split == "test":
            for cname, items in noisy_by_cond.items():
                if items:
                    write(f"test_{cname.replace('_', '')}_slu.json", items)
        elif split in ("train", "train_synthetic"):
            noisy_pool["train"] += [it for v in noisy_by_cond.values() for it in v]
        elif split == "devel":
            noisy_pool["devel"] += [it for v in noisy_by_cond.values() for it in v]
        if missing:
            print(f"WARNING {split}: {missing} audio files not found", file=sys.stderr)
    if noisy_pool["train"]:
        with open(os.path.join(a.out, "train_noisy_slu.json"), "w") as g:
            for it in noisy_pool["train"]:
                g.write(json.dumps(it) + "\n")
        stats["train_noisy_slu.json"] = len(noisy_pool["train"])
    if noisy_pool["devel"]:
        with open(os.path.join(a.out, "devel_noisy_slu.json"), "w") as g:
            for it in noisy_pool["devel"]:
                g.write(json.dumps(it) + "\n")
        stats["devel_noisy_slu.json"] = len(noisy_pool["devel"])
    for k, v in stats.items():
        print(f"{k:32s} {v:8d} utterances")
    print("Set data.test in configs/base.yaml to the test_*_slu.json files above.")


if __name__ == "__main__":
    main()
