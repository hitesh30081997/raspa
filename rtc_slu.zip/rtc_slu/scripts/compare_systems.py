#!/usr/bin/env python
"""
Cross-system comparison for the paper.

  python scripts/compare_systems.py --exp_root exp --reference B0_pretrained --proposed RTC_tt --pareto_condition snr_0

Writes to --out (default exp/_comparison):
  master_table.md / .csv / .tex   params, compression, trainable params, Intent Acc & SLU-F1 per condition
  significance.md / .json         proposed vs every system: paired bootstrap on SLU-F1, exact McNemar on intent
  pareto_<cond>.png               model size vs SLU-F1 (Ablation 3)
  snr_curves.png                  all systems across conditions
"""
import argparse
import csv
import glob
import json
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from rtc.analysis import INK, INK2, SERIES, SURFACE, _snr_sort_key, _style, paired_comparison  # noqa: E402
from rtc.slurp_metrics import aggregate, score_utterance  # noqa: E402

META_KEYS = ("condition", "snr", "noise_type", "mic", "duration", "slurp_id", "recording")


def load_system(d):
    summ = os.path.join(d, "results", "summary.json")
    if not os.path.exists(summ):
        return None
    with open(summ) as f:
        summary = json.load(f)
    by_cond = {}
    for p in sorted(glob.glob(os.path.join(d, "results", "predictions", "*.jsonl"))):
        if p.endswith(".official.jsonl"):
            continue
        cond = os.path.basename(p)[:-6]
        scores = []
        with open(p) as f:
            for line in f:
                r = json.loads(line)
                meta = {k: r[k] for k in META_KEYS if k in r}
                scores.append(score_utterance(r["recording"], r["text"], r["pred_text"], meta))
        by_cond[cond] = scores
    return {"summary": summary, "scores": by_cond}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp_root", default="exp")
    ap.add_argument("--systems", nargs="*", help="subset / order of experiment names (default: all found)")
    ap.add_argument("--reference", default="B0_pretrained", help="uncompressed model: defines compression ratio")
    ap.add_argument("--proposed", default="RTC_tt")
    ap.add_argument("--pareto_condition", default="snr_0")
    ap.add_argument("--n_boot", type=int, default=1000)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    out = a.out or os.path.join(a.exp_root, "_comparison")
    os.makedirs(out, exist_ok=True)

    names = a.systems or sorted(os.path.basename(d) for d in glob.glob(os.path.join(a.exp_root, "*"))
                                if os.path.isdir(d) and not os.path.basename(d).startswith("_"))
    systems = {n: s for n in names if (s := load_system(os.path.join(a.exp_root, n)))}
    if not systems:
        raise SystemExit("no finished experiments found")
    conds = sorted({c for s in systems.values() for c in s["scores"]}, key=_snr_sort_key)
    ref_total = systems[a.reference]["summary"]["efficiency"]["params"]["total"] if a.reference in systems else None

    # ---------------- master table ----------------
    rows = []
    for n, s in systems.items():
        eff = s["summary"].get("efficiency", {}).get("params", {})
        res = {c: aggregate(s["scores"][c]) for c in conds if c in s["scores"]}
        noisy = [c for c in res if c != "clean"]
        row = {"system": n, "params_M": eff.get("total", 0) / 1e6, "encoder_M": eff.get("encoder", 0) / 1e6,
               "trainable_M": s["summary"].get("trainable_last_stage_M"),
               "compression_x": (ref_total / eff["total"]) if ref_total and eff.get("total") else None}
        for c in conds:
            row[f"{c}|intent"] = res[c]["intent_acc"] if c in res else None
            row[f"{c}|slu_f1"] = res[c]["slu_f1"] if c in res else None
        row["noisy_mean|intent"] = float(np.mean([res[c]["intent_acc"] for c in noisy])) if noisy else None
        row["noisy_mean|slu_f1"] = float(np.mean([res[c]["slu_f1"] for c in noisy])) if noisy else None
        rows.append(row)
    cols = ["system", "params_M", "encoder_M", "trainable_M", "compression_x"] + [f"{c}|{m}" for c in conds + ["noisy_mean"]
                                                                   for m in ("intent", "slu_f1")]
    with open(os.path.join(out, "master_table.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

    def f(v, d=2):
        return "-" if v is None else f"{v:.{d}f}"

    md = ["| System | Params (M) | Enc (M) | Trained (M) | Compr. | " + " | ".join(f"{c} IA / SLU-F1" for c in conds + ["noisy mean"]) + " |",
          "|" + "---|" * (5 + len(conds) + 1)]
    for r in rows:
        md.append(f"| {r['system']} | {f(r['params_M'], 1)} | {f(r['encoder_M'], 1)} | {f(r['trainable_M'], 3)} | "
                  f"{f(r['compression_x'], 2) + 'x' if r['compression_x'] else '-'} | "
                  + " | ".join(f"{f(r[f'{c}|intent'])} / {f(r[f'{c}|slu_f1'])}" for c in conds + ["noisy_mean"]) + " |")
    with open(os.path.join(out, "master_table.md"), "w") as fh:
        fh.write("Intent accuracy (IA) and SLU-F1 (%), official SLURP definitions.\n\n" + "\n".join(md) + "\n")
    tex = ["\\begin{tabular}{l r r " + "c " * (len(conds) + 1) + "}", "\\toprule",
           "System & Params & Compr. & " + " & ".join(c.replace("_", "\\_") for c in conds + ["noisy mean"]) + " \\\\",
           "\\midrule"]
    times = "$\\times$"
    for r in rows:
        sysname = r["system"].replace("_", "\\_")
        comp = f(r["compression_x"], 1) + times if r["compression_x"] else "-"
        tex.append(f"{sysname} & {f(r['params_M'], 1)}M & {comp} & "
                   + " & ".join(f"{f(r[f'{c}|intent'], 1)} / {f(r[f'{c}|slu_f1'], 1)}" for c in conds + ["noisy_mean"])
                   + " \\\\")
    tex += ["\\bottomrule", "\\end{tabular}"]
    with open(os.path.join(out, "master_table.tex"), "w") as fh:
        fh.write("\n".join(tex) + "\n")

    # ---------------- significance ----------------
    sig = {}
    if a.proposed in systems:
        P = systems[a.proposed]["scores"]
        lines = [f"Paired tests: **{a.proposed}** minus each system, same utterances. SLU-F1: paired bootstrap "
                 f"({a.n_boot} resamples, 95% CI of the difference). Intent: exact McNemar.", "",
                 "| vs system | condition | dSLU-F1 | 95% CI | p (bootstrap) | dIntent Acc | p (McNemar) |",
                 "|---|---|---|---|---|---|---|"]
        for n, s in systems.items():
            if n == a.proposed:
                continue
            sig[n] = {}
            for c in conds:
                if c in P and c in s["scores"]:
                    r = paired_comparison(P[c], s["scores"][c], n_boot=a.n_boot)
                    sig[n][c] = r
                    if r["n"]:
                        lines.append(f"| {n} | {c} | {r['delta_slu_f1']:+.2f} | [{r['slu_f1_delta_ci'][0]:+.2f}, "
                                     f"{r['slu_f1_delta_ci'][1]:+.2f}] | {r['p_slu_f1_bootstrap']:.4f} | "
                                     f"{r['delta_intent_acc']:+.2f} | {r['mcnemar_intent']['p']:.4f} |")
        with open(os.path.join(out, "significance.md"), "w") as fh:
            fh.write("\n".join(lines) + "\n")
        with open(os.path.join(out, "significance.json"), "w") as fh:
            json.dump(sig, fh, indent=1)

    # ---------------- figures ----------------
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib missing: skipped figures")
        return
    plotted = list(systems)[: len(SERIES)]  # fixed categorical order; never cycle hues
    if len(systems) > len(SERIES):
        print(f"[plots] >{len(SERIES)} systems: curves show the first {len(SERIES)} (use --systems to choose)")
    color = {n: SERIES[i] for i, n in enumerate(plotted)}

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), facecolor=SURFACE)
    x = np.arange(len(conds))
    for ax, (m, title) in zip(axes, (("intent", "Intent accuracy (%)"), ("slu_f1", "SLU-F1 (%)"))):
        _style(ax)
        for n in plotted:
            r = next(rr for rr in rows if rr["system"] == n)
            y = [r[f"{c}|{m}"] if r[f"{c}|{m}"] is not None else np.nan for c in conds]
            ax.plot(x, y, color=color[n], linewidth=2, marker="o", markersize=8, markeredgecolor=SURFACE,
                    markeredgewidth=2, label=n)
        ax.set_xticks(x, conds)
        ax.set_title(title, fontsize=10, color=INK, loc="left")
    axes[1].legend(frameon=False, fontsize=7.5, loc="center left", bbox_to_anchor=(1.01, 0.5), labelcolor=INK2)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "snr_curves.png"), dpi=200, facecolor=SURFACE)
    plt.close(fig)

    cond = a.pareto_condition
    pts = [(r["params_M"], r[f"{cond}|slu_f1"], r["system"]) for r in rows if r.get(f"{cond}|slu_f1") is not None]
    if pts:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=SURFACE)
        _style(ax)
        for p, v, n in pts:
            ax.scatter([p], [v], s=70, color=color.get(n, INK2), edgecolor=SURFACE, linewidth=2, zorder=3)
            ax.annotate(n, (p, v), textcoords="offset points", xytext=(6, 4), fontsize=7.5, color=INK)
        # Pareto frontier: no other system is both smaller and better
        front = sorted(pts)
        best, fr = -1e9, []
        for p, v, n in front:
            if v > best:
                fr.append((p, v))
                best = v
        ax.plot([p for p, _ in fr], [v for _, v in fr], color=INK2, linewidth=1, linestyle="--", zorder=2)
        ax.set_xlabel("total parameters (M)", color=INK2, fontsize=9)
        ax.set_ylabel(f"SLU-F1 on {cond} (%)", color=INK2, fontsize=9)
        fig.tight_layout()
        fig.savefig(os.path.join(out, f"pareto_{cond}.png"), dpi=200, facecolor=SURFACE)
        plt.close(fig)
    print(f"comparison written to {out}")


if __name__ == "__main__":
    main()
