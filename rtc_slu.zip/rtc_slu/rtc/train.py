"""
Staged training.

A stage = (data, which parameters train, optimiser schedule, optional distillation, model selection).
Typical RTC pipeline:
  heal  : clean SLURP, train the factorized cores (+ norms), distil from the uncompressed teacher
  adapt : noisy SLURP, freeze everything except the parallel noise adapters (BatchNorm stats frozen too)
"""
from __future__ import annotations

import contextlib
import math
import os
import time
from typing import Dict, Optional

import torch
import torch.nn.functional as F

from .data import dev_sets, resolve_stage_manifests, train_loader
from .decompose import freeze_frozen_batchnorm_stats, set_trainable
from .evaluate import evaluate_sets
from .slurp_metrics import aggregate


def seq2seq_forward(model, processed, processed_len, sem, sem_len):
    """Teacher-forced forward pass, identical to SLUIntentSlotBPEModel.forward minus preprocessing/SpecAugment."""
    from nemo.collections.asr.parts.utils.slu_utils import get_seq_mask
    encoded, encoded_len = model.encoder(audio_signal=processed, length=processed_len)
    encoded = encoded.transpose(1, 2)
    enc_mask = get_seq_mask(encoded, encoded_len)
    bos = sem[:, :-1]
    emb = model.embedding(input_ids=bos)
    dmask = get_seq_mask(emb, sem_len - 1)
    dec = model.decoder(encoder_states=encoded, encoder_mask=enc_mask, decoder_states=emb, decoder_mask=dmask)
    if isinstance(dec, (tuple, list)):  # newer NeMo TransformerDecoder returns (hidden_states, mems)
        dec = dec[0]
    return model.classifier(hidden_states=dec), encoded, encoded_len


def _lr_lambda(warmup: int, total: int, min_ratio: float):
    def f(step):
        if step < warmup:
            return (step + 1) / max(1, warmup)
        prog = min(1.0, (step - warmup) / max(1, total - warmup))
        return min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * prog))
    return f


def _seq_mask(lengths, maxlen):
    return (torch.arange(maxlen, device=lengths.device)[None, :] < lengths[:, None]).float()


def _snapshot(model, names):
    sd = model.state_dict()
    keep = set(names) | {n for n, _ in model.named_buffers()}
    return {k: v.detach().cpu().clone() for k, v in sd.items() if k in keep}


def _selection_score(by_cond, metric):
    vals = []
    for scores in by_cond.values():
        r = aggregate(scores)
        vals.append((r["intent_acc"] + r["slu_f1"]) / 2 if metric == "mean" else r[metric])
    return sum(vals) / len(vals)


def train_stage(model, stage: dict, cfg: dict, out_dir: str, teacher=None, log=print) -> dict:
    device = cfg["device"]
    st = dict(stage)
    name = st["name"]
    set_trainable(model, st.get("trainable", "all"), log)
    params = [p for p in model.parameters() if p.requires_grad]
    trainable_names = [n for n, p in model.named_parameters() if p.requires_grad]
    if not params:
        log(f"[{name}] nothing to train, skipping")
        return {}

    manifests = resolve_stage_manifests(cfg["data"], st.get("data", "clean"))
    log(f"[{name}] training on {manifests}")
    dl = train_loader(model, manifests, cfg["data"], st.get("batch_size", 16), shuffle=True)
    accum = st.get("grad_accum", 1)
    steps_per_epoch = max(1, len(dl) // accum)
    total = st.get("max_steps") or st.get("epochs", 1) * steps_per_epoch
    warmup = st.get("warmup_steps", int(0.05 * total))
    opt = torch.optim.AdamW(params, lr=st.get("lr", 1e-4), betas=(0.9, 0.98),
                            weight_decay=st.get("weight_decay", 1e-3))
    sched = torch.optim.lr_scheduler.LambdaLR(opt, _lr_lambda(warmup, total, st.get("min_lr_ratio", 0.05)))
    precision = cfg.get("precision", "bf16")
    use_amp = device.startswith("cuda") and precision in ("bf16", "fp16")
    amp_dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp and precision == "fp16")
    amp = (lambda: torch.autocast("cuda", dtype=amp_dtype)) if use_amp else contextlib.nullcontext

    kd = st.get("kd") or {}
    use_kd = bool(kd.get("enabled")) and teacher is not None
    if kd.get("enabled") and teacher is None:
        log(f"[{name}] WARNING: kd.enabled but no teacher available -> plain CE")
    if use_kd:
        teacher.eval()

    select_on = st.get("select_on", "dev_clean")
    sel_sets = {k: v for k, v in dev_sets(cfg["data"]).items() if k in select_on.split("+")}
    eval_every = st.get("eval_every_steps") or steps_per_epoch
    patience = st.get("patience", 0)
    metric = st.get("select_metric", "mean")
    dev_dec = cfg["evaluation"].get("dev_decoding", {"type": "greedy"})

    def run_dev():
        if not sel_sets:
            return None
        by = evaluate_sets(model, sel_sets, out_dir, cfg, dev_dec, log=log,
                           max_utts=cfg["evaluation"].get("dev_max_utts"), reuse=False, write=False)
        return _selection_score(by, metric)

    history = {"stage": name, "steps": [], "dev": [], "trainable_params": sum(p.numel() for p in params),
               "data": manifests, "total_steps": total}
    best_score, best_state, bad = -1e9, None, 0
    if st.get("eval_before", True) and sel_sets:
        best_score = run_dev()
        best_state = _snapshot(model, trainable_names)
        history["dev"].append({"step": 0, "score": best_score})
        log(f"[{name}] dev ({select_on}, {metric}) before training: {best_score:.2f}")

    step, micro, t0 = 0, 0, time.time()
    clip = st.get("grad_clip", 1.0)
    log_every = st.get("log_every", 50)
    done = False
    opt.zero_grad(set_to_none=True)
    while not done:
        for batch in dl:
            model.train()
            freeze_frozen_batchnorm_stats(model)
            sig, sig_len, sem, sem_len = [b.to(device) for b in batch[:4]]
            with torch.no_grad() if not any(p.requires_grad for p in model.preprocessor.parameters()) else contextlib.nullcontext():
                proc, plen = model.preprocessor(input_signal=sig, length=sig_len)
            if st.get("spec_augment", True) and model.spec_augmentation is not None:
                proc = model.spec_augmentation(input_spec=proc, length=plen)
            labels, lab_len = sem[:, 1:], sem_len - 1
            with amp():
                lp, enc, enc_len = seq2seq_forward(model, proc, plen, sem, sem_len)
                ce = model.loss(log_probs=lp, labels=labels, lengths=lab_len)
                loss, logs = ce, {"ce": float(ce)}
                if use_kd:
                    with torch.no_grad():
                        tlp, tenc, _ = seq2seq_forward(teacher, proc, plen, sem, sem_len)
                    T, a = kd.get("temperature", 2.0), kd.get("alpha", 0.5)
                    mask = _seq_mask(lab_len, lp.shape[1])
                    s_log = F.log_softmax(lp.float() / T, -1)
                    t_log = F.log_softmax(tlp.float() / T, -1)
                    kl = ((t_log.exp() * (t_log - s_log)).sum(-1) * mask).sum() / mask.sum() * T * T
                    loss = (1 - a) * ce + a * kl
                    logs["kd"] = float(kl)
                    fw = kd.get("feat_weight", 0.0)
                    if fw > 0:
                        fm = _seq_mask(enc_len, enc.shape[1])
                        mse = (((enc.float() - tenc.float()) ** 2).mean(-1) * fm).sum() / fm.sum()
                        loss = loss + fw * mse
                        logs["feat"] = float(mse)
            scaler.scale(loss / accum).backward()
            micro += 1
            if micro % accum:
                continue
            scaler.unscale_(opt)
            gn = torch.nn.utils.clip_grad_norm_(params, clip)
            scaler.step(opt)
            scaler.update()
            opt.zero_grad(set_to_none=True)
            sched.step()
            step += 1
            if step % log_every == 0 or step == 1:
                el = time.time() - t0
                log(f"[{name}] step {step}/{total} loss={float(loss):.4f} "
                    + " ".join(f"{k}={v:.4f}" for k, v in logs.items())
                    + f" gnorm={float(gn):.2f} lr={sched.get_last_lr()[0]:.2e} ({el / step:.2f}s/step)")
                history["steps"].append({"step": step, "loss": float(loss), **logs})
            if step % eval_every == 0 or step == total:
                score = run_dev()
                if score is not None:
                    history["dev"].append({"step": step, "score": score})
                    improved = score > best_score
                    log(f"[{name}] dev ({select_on}, {metric}) @ {step}: {score:.2f}"
                        + ("  *best*" if improved else ""))
                    if improved:
                        best_score, best_state, bad = score, _snapshot(model, trainable_names), 0
                    else:
                        bad += 1
                        if patience and bad >= patience:
                            log(f"[{name}] early stopping")
                            done = True
            if step >= total:
                done = True
            if done:
                break
    if best_state is not None:
        missing = model.load_state_dict(best_state, strict=False)
        log(f"[{name}] restored best dev checkpoint (score {best_score:.2f}); "
            f"{len(missing.unexpected_keys)} unexpected keys")
    history["best_dev"] = best_score
    return history
