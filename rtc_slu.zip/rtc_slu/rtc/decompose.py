"""
Model surgery on the NeMo SLUIntentSlotBPEModel (Conformer encoder + Transformer decoder).

Parameter budget of the encoder of slu_conformer_transformer_large_slurp (d_model=512, 17 layers, ff x4):
    per layer: 2 x FFN (512->2048->512)  ~ 4.19 M   (~66 %)
               MHSA q,k,v,out,pos         ~ 1.31 M   (~21 %)
               conv pointwise 1 & 2       ~ 0.79 M   (~12 %)
               depthwise conv (k=31)      ~ 0.016 M  (left dense: it is tiny)
    pre-encode: Conv2d 512->512 3x3 (2.4 M) + Linear 10240->512 (5.2 M)
=> A ~70 % encoder reduction is impossible without factorising the FFNs; this module covers all of them.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional

import torch
import torch.nn as nn

from .adapters import ParallelNoiseAdapter, inject_adapters
from .tensor_layers import (FactorizedLinear, LowRankLinear, PointwiseConv1d, TTLinear, Tucker2Conv2d,
                            TuckerLinear, build_empty_from_spec, factorize_dim)

GROUP_PATTERNS: Dict[str, str] = {
    "ffn": r"^encoder\.layers\.\d+\.feed_forward[12]\.linear[12]$",
    "attn_qkv": r"^encoder\.layers\.\d+\.self_attn\.linear_[qkv]$",
    "attn_out": r"^encoder\.layers\.\d+\.self_attn\.linear_out$",
    "attn_pos": r"^encoder\.layers\.\d+\.self_attn\.linear_pos$",
    "conv_pw": r"^encoder\.layers\.\d+\.conv\.pointwise_conv[12]$",
    "subsampling_conv": r"^encoder\.pre_encode\.conv\.\d+$",
    "subsampling_out": r"^encoder\.pre_encode\.out$",
}

_LAYER_RX = re.compile(r"encoder\.layers\.(\d+)\.")


def layer_index(name: str) -> Optional[int]:
    m = _LAYER_RX.search(name)
    return int(m.group(1)) if m else None


def _set_module(model: nn.Module, name: str, new: nn.Module):
    parent_name, _, child = name.rpartition(".")
    setattr(model.get_submodule(parent_name) if parent_name else model, child, new)


def _n_heads(model: nn.Module, name: str) -> Optional[int]:
    parent = model.get_submodule(name.rpartition(".")[0])
    return getattr(parent, "h", None)


def _linear_weight(mod: nn.Module):
    if isinstance(mod, nn.Linear):
        return mod.weight, mod.bias, False
    if isinstance(mod, nn.Conv1d):
        if mod.kernel_size != (1,) or mod.groups != 1:
            raise TypeError("only pointwise Conv1d can be treated as a linear layer")
        return mod.weight[:, :, 0], mod.bias, True
    raise TypeError(type(mod))


def factorize_module(model: nn.Module, name: str, mod: nn.Module, gcfg: dict, forward_mode: str,
                     hooi_iters: int) -> nn.Module:
    method = gcfg["method"]
    rank, ratio = gcfg.get("rank"), gcfg.get("ratio")
    if isinstance(mod, nn.Conv2d):
        if method not in ("tucker", "tucker2"):
            raise ValueError(f"{name}: Conv2d supports only tucker(2), got {method}")
        if mod.groups != 1 or mod.in_channels == 1:
            return None  # depthwise / single-input-channel convs: nothing to gain
        ranks = tuple(rank) if isinstance(rank, (list, tuple)) else ((rank, rank) if rank else None)
        return Tucker2Conv2d.from_conv(mod, ranks=ranks, ratio=ratio, n_iter=hooi_iters)

    w, b, is_conv1d = _linear_weight(mod)
    out_f, in_f = w.shape
    if method == "tt":
        new = TTLinear.from_weight(w, b, num_cores=gcfg.get("num_cores", 3), rank=rank, ratio=ratio,
                                   forward_mode=forward_mode, in_modes=gcfg.get("in_modes"),
                                   out_modes=gcfg.get("out_modes"))
    elif method == "tucker":
        layout = gcfg.get("layout", "auto")
        h = _n_heads(model, name)
        fixed = None
        if layout == "heads" and h:
            if name.endswith("linear_out"):  # [d_model | heads, head_dim]
                out_modes, in_modes = [out_f], [h, in_f // h]
                fixed = [None, gcfg.get("head_rank"), None]
            else:  # q / k / v / pos : [heads, head_dim | d_model]
                out_modes, in_modes = [h, out_f // h], [in_f]
                fixed = [gcfg.get("head_rank"), None, None]
        else:
            k = gcfg.get("num_modes_per_side", 2)
            out_modes, in_modes = factorize_dim(out_f, k), factorize_dim(in_f, k)
        ranks = rank if isinstance(rank, (list, tuple)) else None
        new = TuckerLinear.from_weight(w, b, out_modes, in_modes, ranks=ranks, ratio=None if ranks else ratio,
                                       fixed_ranks=fixed, n_iter=hooi_iters, forward_mode=forward_mode)
    elif method == "svd":
        new = LowRankLinear.from_weight(w, b, rank=rank, ratio=ratio,
                                        forward_mode="factorized" if forward_mode == "auto" else forward_mode)
    else:
        raise ValueError(f"unknown method {method}")
    return PointwiseConv1d(new) if is_conv1d else new


def _factor_core(mod: nn.Module):
    return mod.linear if isinstance(mod, PointwiseConv1d) else mod


def decompose_model(model: nn.Module, comp_cfg: dict, log=print) -> List[dict]:
    """Replace targeted dense layers by factorized layers initialised from the pretrained weights."""
    forward_mode = comp_cfg.get("forward_mode", "dense")
    hooi_iters = comp_cfg.get("tucker_hooi_iters", 10)
    skip_layers = set(comp_cfg.get("skip_layers", []) or [])
    patterns = dict(GROUP_PATTERNS)
    patterns.update(comp_cfg.get("extra_patterns", {}) or {})
    report, specs = [], {}
    targets = []
    for gname, gcfg in (comp_cfg.get("groups") or {}).items():
        if gcfg is None or gcfg.get("method", "none") == "none":
            continue
        rx = re.compile(patterns[gname])
        for name, mod in model.named_modules():
            if rx.search(name) and layer_index(name) not in skip_layers and isinstance(mod, (nn.Linear, nn.Conv1d, nn.Conv2d)):
                targets.append((gname, gcfg, name, mod))
    for gname, gcfg, name, mod in targets:
        dense = sum(p.numel() for n, p in mod.named_parameters() if n == "weight")
        new = factorize_module(model, name, mod, dict(gcfg), forward_mode, hooi_iters)
        if new is None:
            continue
        new.to(device=next(mod.parameters()).device)
        core = _factor_core(new)
        n_fac = core.num_factor_params()
        spec = core.spec()
        report.append({"module": name, "group": gname, "layer": layer_index(name), "method": spec["method"],
                       "dense_params": dense, "factor_params": n_fac, "ratio": n_fac / dense,
                       "rel_error": core.init_rel_error, "spec": spec})
        specs[name] = spec
        _set_module(model, name, new)
    model._rtc_specs = specs
    tot_d = sum(r["dense_params"] for r in report)
    tot_f = sum(r["factor_params"] for r in report)
    log(f"[decompose] replaced {len(report)} modules: {tot_d / 1e6:.2f}M -> {tot_f / 1e6:.2f}M weights "
        f"({tot_d / max(tot_f, 1):.2f}x on the targeted layers)")
    return report


def rebuild_from_specs(model: nn.Module, specs: Dict[str, dict], forward_mode: str = "dense"):
    """Re-create factorized modules with the right shapes, e.g. before loading a checkpoint."""
    for name, spec in specs.items():
        ref = model.get_submodule(name)
        mode = forward_mode if spec["method"] != "svd" else "factorized"
        _set_module(model, name, build_empty_from_spec(spec, ref, mode).to(next(ref.parameters()).device))
    model._rtc_specs = dict(specs)


def set_forward_mode(model: nn.Module, mode: str):
    for m in model.modules():
        if isinstance(m, FactorizedLinear):
            m.forward_mode = mode


# ---------------------------------------------------------------------------------------------------------------
# trainability
# ---------------------------------------------------------------------------------------------------------------

_NORM_TYPES = (nn.LayerNorm, nn.BatchNorm1d, nn.BatchNorm2d, nn.GroupNorm, nn.InstanceNorm1d)


def set_trainable(model: nn.Module, policy: str, log=print) -> Dict[str, int]:
    """
    policy: '+'-joined subset of {all, none, factors, adapters, encoder, decoder, norms, biases}
      factors  : all parameters of factorized layers (cores/factors and their bias)
      adapters : parallel noise adapters
      encoder  : the whole encoder (dense + factorized, excluding adapters unless 'adapters' also given)
      decoder  : transformer decoder + token embedding + classifier
      norms    : LayerNorm / BatchNorm affine params inside the encoder
      biases   : every bias inside the encoder
    """
    parts = set(policy.split("+"))
    for p in model.parameters():
        p.requires_grad_(False)
    if "none" in parts:
        return trainable_summary(model, log)
    if "all" in parts:
        for p in model.parameters():
            p.requires_grad_(True)
        return trainable_summary(model, log)

    def enable(mod):
        for p in mod.parameters():
            p.requires_grad_(True)

    for name, mod in model.named_modules():
        if "factors" in parts and isinstance(mod, (FactorizedLinear, Tucker2Conv2d)):
            enable(mod)
        if "norms" in parts and name.startswith("encoder") and isinstance(mod, _NORM_TYPES):
            enable(mod)
    for n, p in model.named_parameters():
        is_adapter = ".noise_adapter" in n
        if "adapters" in parts and is_adapter:
            p.requires_grad_(True)
        if "encoder" in parts and n.startswith("encoder") and not is_adapter:
            p.requires_grad_(True)
        if "decoder" in parts and n.split(".")[0] in ("decoder", "embedding", "classifier"):
            p.requires_grad_(True)
        if "biases" in parts and n.startswith("encoder") and n.endswith("bias") and not is_adapter:
            p.requires_grad_(True)
    return trainable_summary(model, log)


def freeze_frozen_batchnorm_stats(model: nn.Module):
    """Call after model.train(): BatchNorms whose affine params are frozen keep their running statistics."""
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d)) and not any(p.requires_grad for p in m.parameters()):
            m.eval()


def trainable_summary(model: nn.Module, log=print) -> Dict[str, int]:
    total = sum(p.numel() for p in model.parameters())
    train = sum(p.numel() for p in model.parameters() if p.requires_grad)
    log(f"[trainable] {train / 1e6:.3f}M / {total / 1e6:.2f}M parameters ({100 * train / max(total, 1):.2f}%)")
    return {"trainable": train, "total": total}


# ---------------------------------------------------------------------------------------------------------------
# checkpoint helpers
# ---------------------------------------------------------------------------------------------------------------


def surgery_state(model: nn.Module, adapter_cfg: Optional[dict]) -> dict:
    return {"specs": getattr(model, "_rtc_specs", {}), "adapters": adapter_cfg,
            "adapter_modules": getattr(model, "_rtc_adapter_modules", [])}


def apply_adapters(model: nn.Module, acfg: dict, log=print) -> List[dict]:
    patterns = dict(GROUP_PATTERNS)
    patterns.update(acfg.get("extra_patterns", {}) or {})
    rep = inject_adapters(model, patterns, list(acfg["targets"]), rank=acfg.get("rank", 8),
                          activation=acfg.get("activation", "relu"), dropout=acfg.get("dropout", 0.0),
                          scale=acfg.get("scale", 1.0), learnable_scale=acfg.get("learnable_scale", False))
    model._rtc_adapter_modules = [r["module"] for r in rep]
    n = sum(r["params"] for r in rep)
    log(f"[adapters] inserted {len(rep)} parallel noise adapters (rank {acfg.get('rank', 8)}), {n / 1e6:.3f}M params")
    return rep


def restore_surgery(model: nn.Module, state: dict, forward_mode: str = "dense", log=print):
    if state.get("specs"):
        rebuild_from_specs(model, state["specs"], forward_mode)
    if state.get("adapters"):
        apply_adapters(model, state["adapters"], log)
