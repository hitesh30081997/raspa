"""
Data handling.

Expected input: NeMo SLU manifests (one JSON object per line), exactly what NeMo's
`scripts/dataset_processing/process_slurp_data.py --text_key=semantics` produces, e.g.

  {"audio_filepath": "wavs/slurp_real/audio-1490.wav", "duration": 2.3,
   "text": "{'scenario': 'alarm', 'action': 'set', 'entities': [{'type': 'time', 'filler': 'five am'}]}",
   "slurp_id": "4130", "snr": 5, "noise_type": "babble"}

`snr`, `noise_type` (names configurable) are optional per-utterance condition tags. When absent they can be
parsed from the audio path with regexes (data.meta_regex), and otherwise the test-set name is used.
scripts/prepare_manifests.py builds such manifests from the SLURP jsonl release + clean/noisy audio folders.
"""
from __future__ import annotations

import json
import os
import re
from typing import Dict, List, Optional, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset


def read_manifest(path: str) -> List[dict]:
    items, base = [], os.path.dirname(os.path.abspath(path))
    with open(path) as f:
        for ln, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            it = json.loads(line)
            a = it["audio_filepath"]
            if not os.path.isabs(a) and not os.path.exists(a):
                cand = os.path.join(base, a)  # NeMo resolves relative paths against the manifest's folder
                if os.path.exists(cand):
                    a = cand
            it["_audio"] = a
            it["_line"] = ln
            items.append(it)
    return items


def utterance_meta(item: dict, condition: str, dcfg: dict) -> dict:
    """Condition tags used for the analysis breakdowns."""
    m = {"condition": condition}
    fields = dcfg.get("meta_fields", {}) or {}
    rx = dcfg.get("meta_regex", {}) or {}
    for tag in ("snr", "noise_type"):
        key = fields.get(tag, tag)
        val = item.get(key)
        if val is None and tag in rx:
            mt = re.search(rx[tag], item["audio_filepath"])
            val = mt.group(1) if mt else None
        if val is not None:
            m[tag] = str(val)
    base = os.path.basename(item["audio_filepath"])
    m["mic"] = "headset" if "-headset" in base else "far-field"  # SLURP naming convention
    m["duration"] = float(item.get("duration", 0.0) or 0.0)
    m["slurp_id"] = str(item.get("slurp_id", ""))
    m["recording"] = recording_key(item, dcfg)
    return m


def recording_key(item: dict, dcfg: dict) -> str:
    """Name of the original SLURP recording (used for the official-format export and for pairing systems)."""
    if item.get("recording"):
        return item["recording"]
    stem = os.path.splitext(os.path.basename(item["audio_filepath"]))[0]
    strip = dcfg.get("noisy_suffix_regex")  # e.g. "_snr-?\\d+.*$" if noisy files are audio-123_snr5_babble.wav
    if strip:
        stem = re.sub(strip, "", stem)
    return stem + ".flac"


# --------------------------------------------------------------------------------------------------------------
# evaluation loader (independent of the tokenizer; keeps manifest order via indices)
# --------------------------------------------------------------------------------------------------------------


def load_audio(path: str, sr: int) -> np.ndarray:
    import soundfile as sf
    wav, fs = sf.read(path, dtype="float32", always_2d=True)
    wav = wav.mean(axis=1)
    if fs != sr:
        import torchaudio.functional as AF
        wav = AF.resample(torch.from_numpy(wav), fs, sr).numpy()
    return wav


class EvalAudioDataset(Dataset):
    def __init__(self, items: List[dict], sample_rate: int):
        self.items, self.sr = items, sample_rate

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        return i, torch.from_numpy(load_audio(self.items[i]["_audio"], self.sr))


def _collate(batch):
    idx, wavs = zip(*batch)
    lens = torch.tensor([w.numel() for w in wavs], dtype=torch.long)
    out = torch.zeros(len(wavs), int(lens.max()))
    for k, w in enumerate(wavs):
        out[k, : w.numel()] = w
    return torch.tensor(idx), out, lens


class _LengthSortedSampler(torch.utils.data.Sampler):
    def __init__(self, items, batch_size):
        order = np.argsort([-float(it.get("duration", 0) or 0) for it in items], kind="stable")
        self.batches = [order[i:i + batch_size].tolist() for i in range(0, len(order), batch_size)]

    def __iter__(self):
        return iter(self.batches)

    def __len__(self):
        return len(self.batches)


def eval_loader(items: List[dict], sample_rate: int, batch_size: int, num_workers: int) -> DataLoader:
    return DataLoader(EvalAudioDataset(items, sample_rate), batch_sampler=_LengthSortedSampler(items, batch_size),
                      collate_fn=_collate, num_workers=num_workers)


# --------------------------------------------------------------------------------------------------------------
# training loader (NeMo's own AudioToBPEDataset -> identical tokenisation with BOS/EOS as the original recipe)
# --------------------------------------------------------------------------------------------------------------


def train_loader(model, manifests: Sequence[str], dcfg: dict, batch_size: int, shuffle: bool = True,
                 max_duration: Optional[float] = None):
    from omegaconf import DictConfig
    for m in manifests:
        if not os.path.exists(m):
            raise FileNotFoundError(m)
    cfg = {
        "manifest_filepath": ",".join(manifests),
        "sample_rate": dcfg.get("sample_rate", 16000),
        "batch_size": batch_size,
        "shuffle": shuffle,
        "num_workers": dcfg.get("num_workers", 4),
        "pin_memory": True,
        "use_start_end_token": True,
        "trim_silence": False,
        "max_duration": max_duration if max_duration is not None else dcfg.get("max_duration", 11.0),
        "min_duration": dcfg.get("min_duration", None),
        "drop_last": False,
    }
    return model._setup_dataloader_from_config(config=DictConfig(cfg))


def resolve_stage_manifests(dcfg: dict, which: str) -> List[str]:
    """which: clean | noisy | both | explicit comma list of manifest paths."""
    def as_list(v):
        if v is None:
            return []
        return [v] if isinstance(v, str) else list(v)

    if which == "clean":
        return as_list(dcfg["train_clean"])
    if which == "noisy":
        return as_list(dcfg["train_noisy"])
    if which == "both":
        return as_list(dcfg["train_clean"]) + as_list(dcfg["train_noisy"])
    return [p.strip() for p in which.split(",") if p.strip()]


def dev_sets(dcfg: dict) -> Dict[str, str]:
    out = {}
    for k in ("dev_clean", "dev_noisy"):
        if dcfg.get(k):
            out[k] = dcfg[k]
    return out
