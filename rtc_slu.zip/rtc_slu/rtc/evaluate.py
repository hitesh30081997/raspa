"""Decoding + scoring of SLURP manifests."""
from __future__ import annotations

import contextlib
import json
import os
import time
from typing import Dict, List, Optional

import torch

from .data import eval_loader, read_manifest, utterance_meta
from .slurp_metrics import UttScore, aggregate, score_utterance


def _amp(device: str, precision: str):
    if precision in ("bf16", "fp16") and device.startswith("cuda"):
        return torch.autocast("cuda", dtype=torch.bfloat16 if precision == "bf16" else torch.float16)
    return contextlib.nullcontext()


def predict_semantics(model, wav, lens) -> List[str]:
    """Same as SLUIntentSlotBPEModel.predict, but robust to NeMo versions whose greedy generator returns a tuple."""
    from nemo.collections.asr.parts.utils.slu_utils import get_seq_mask
    proc, plen = model.preprocessor(input_signal=wav, length=lens)
    enc, elen = model.encoder(audio_signal=proc, length=plen)
    enc = enc.transpose(1, 2)
    tokens = model.sequence_generator(enc, get_seq_mask(enc, elen))
    if isinstance(tokens, (tuple, list)):
        tokens = tokens[0]
    return model.sequence_generator.decode_semantics_from_tokens(tokens)


@torch.no_grad()
def decode_items(model, items: List[dict], decoding: dict, batch_size: int = 32, num_workers: int = 4,
                 device: str = "cuda", precision: str = "fp32", sample_rate: int = 16000, log=print) -> List[str]:
    from nemo.collections.asr.parts.utils.slu_utils import SequenceGeneratorConfig
    was_training = model.training
    model.eval()
    from omegaconf import OmegaConf
    # NeMo expects a DictConfig here (it calls cfg.get)
    model.set_decoding_strategy(OmegaConf.structured(SequenceGeneratorConfig(**dict(decoding))))
    preds: List[Optional[str]] = [None] * len(items)
    t0, done = time.time(), 0
    for idx, wav, lens in eval_loader(items, sample_rate, batch_size, num_workers):
        with _amp(device, precision):
            out = predict_semantics(model, wav.to(device), lens.to(device))
        for i, p in zip(idx.tolist(), out):
            preds[i] = p
        done += len(out)
        if done % (batch_size * 50) < batch_size:
            log(f"  decoded {done}/{len(items)} ({done / max(time.time() - t0, 1e-6):.1f} utt/s)")
    model.train(was_training)
    return preds


def score_items(items: List[dict], preds: List[str], condition: str, dcfg: dict) -> List[UttScore]:
    out = []
    for it, p in zip(items, preds):
        meta = utterance_meta(it, condition, dcfg)
        out.append(score_utterance(meta["recording"], it["text"], p, meta))
    return out


def write_predictions(path: str, items: List[dict], preds: List[str], scores: List[UttScore]):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for it, p, s in zip(items, preds, scores):
            f.write(json.dumps({"audio_filepath": it["audio_filepath"], "recording": s.key, "text": it["text"],
                                "pred_text": p, "invalid": s.invalid, "intent_ok": s.intent_ok, **s.meta}) + "\n")


def export_official(path: str, scores: List[UttScore]):
    """Prediction file for the official `slurp/scripts/evaluation/evaluate.py -g test.jsonl -p <this>`."""
    with open(path, "w") as f:
        for s in scores:
            f.write(json.dumps({"file": s.key, "scenario": s.pred["scenario"], "action": s.pred["action"],
                                "entities": s.pred["entities"]}) + "\n")


def load_predictions(path: str) -> Dict[str, str]:
    out = {}
    with open(path) as f:
        for line in f:
            d = json.loads(line)
            out[d["audio_filepath"]] = d["pred_text"]
    return out


def evaluate_sets(model, sets: Dict[str, str], out_dir: str, cfg: dict, decoding: dict, log=print,
                  max_utts: Optional[int] = None, reuse: bool = True, write: bool = True) -> Dict[str, List[UttScore]]:
    """Decode (or reuse cached predictions for) every manifest in `sets`; returns per-condition scores."""
    dcfg, ecfg = cfg["data"], cfg["evaluation"]
    by_cond = {}
    for cond, manifest in sets.items():
        items = read_manifest(manifest)
        if max_utts:
            items = items[:max_utts]
        pred_path = os.path.join(out_dir, "predictions", f"{cond}.jsonl")
        preds = None
        if reuse and os.path.exists(pred_path):
            cached = load_predictions(pred_path)
            if all(it["audio_filepath"] in cached for it in items):
                preds = [cached[it["audio_filepath"]] for it in items]
                log(f"[eval] {cond}: reusing {pred_path}")
        if preds is None:
            log(f"[eval] {cond}: decoding {len(items)} utterances from {manifest} with {dict(decoding)}")
            preds = decode_items(model, items, decoding, ecfg.get("batch_size", 32), dcfg.get("num_workers", 4),
                                 cfg["device"], ecfg.get("precision", "fp32"), dcfg.get("sample_rate", 16000), log)
        scores = score_items(items, preds, cond, dcfg)
        if write:
            write_predictions(pred_path, items, preds, scores)
            export_official(os.path.join(out_dir, "predictions", f"{cond}.official.jsonl"), scores)
        r = aggregate(scores)
        log(f"[eval] {cond}: intent_acc={r['intent_acc']:.2f}  slu_f1={r['slu_f1']:.2f}  span_f1={r['span_f1']:.2f}"
            f"  invalid={r['invalid_rate']:.2f}%")
        by_cond[cond] = scores
    return by_cond
