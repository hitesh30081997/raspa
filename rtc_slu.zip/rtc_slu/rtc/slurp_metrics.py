"""
SLURP evaluation metrics (Bastianelli et al., EMNLP 2020), re-implemented per utterance.

The arithmetic is identical to the official scripts
(github.com/pswietojanski/slurp/scripts/evaluation/metrics, also vendored by NeMo's SLURP example):
  * scenario / action / intent : FMeasure  -> micro precision == accuracy
  * entity span F1             : exact (type, filler) match
  * word / char distance F1    : type match; TP += 1, FP += d, FN += d with d = WER (word) or normalised
                                 Levenshtein (char) to the closest same-type gold filler
  * SLU-F1                     : sum of the word- and char-distance confusion counts, then P / R / F1
Keeping the counts per utterance means a corpus score is just a sum, which makes bootstrap CIs, paired tests
and arbitrary breakdowns (SNR, noise type, mic, #entities, ...) exact and cheap.
tests/test_metrics.py checks equality with the official code on random predictions.
"""
from __future__ import annotations

import ast
from collections import defaultdict
from copy import copy
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Sequence, Tuple, Union

NONE_SEM = {"scenario": "none", "action": "none", "entities": []}


# --------------------------------------------------------------------------------------------------------------
# parsing (same behaviour as NeMo eval_utils.evaluator.parse_semantics_str2dict)
# --------------------------------------------------------------------------------------------------------------


def parse_semantics(sem: Union[str, dict, list]) -> Tuple[dict, bool]:
    invalid = False
    if isinstance(sem, dict):
        d = dict(sem)
    else:
        if isinstance(sem, list):
            sem = " ".join(sem)
        try:
            if "|" in sem:
                sem = sem.replace("|", ",")
            d = ast.literal_eval(sem)
            if not isinstance(d, dict):
                d, invalid = dict(NONE_SEM, entities=[]), True
        except Exception:
            d, invalid = dict(NONE_SEM, entities=[]), True
    if not isinstance(d.get("scenario"), str):
        d["scenario"], invalid = "none", True
    if not isinstance(d.get("action"), str):
        d["action"], invalid = "none", True
    if "entities" not in d or not isinstance(d["entities"], list):
        d["entities"], invalid = [], True
    ents = []
    for e in d["entities"]:
        if not isinstance(e, dict):
            e, invalid = {"type": "none", "filler": "none"}, True
        e = dict(e)
        for k in ("type", "filler"):
            if not isinstance(e.get(k), str):
                e[k], invalid = "none", True
        ents.append({"type": e["type"], "filler": e["filler"]})
    d["entities"] = ents
    return d, invalid


# --------------------------------------------------------------------------------------------------------------
# distances (identical to jiwer.wer / textdistance.levenshtein.normalized_distance as used by SLURP)
# --------------------------------------------------------------------------------------------------------------


def _levenshtein(a: Sequence, b: Sequence) -> int:
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def word_distance(truth: str, hyp: str) -> float:
    """WER of hyp w.r.t. truth (can exceed 1, exactly like jiwer)."""
    t, h = truth.split(), hyp.split()
    if not t:
        return 0.0 if not h else float(len(h))
    return _levenshtein(t, h) / len(t)


def char_distance(truth: str, hyp: str) -> float:
    m = max(len(truth), len(hyp))
    return 0.0 if m == 0 else _levenshtein(truth, hyp) / m


DISTANCES = {"word": word_distance, "char": char_distance}


# --------------------------------------------------------------------------------------------------------------
# per-utterance scoring
# --------------------------------------------------------------------------------------------------------------

Counts = Dict[str, List[float]]  # label -> [tp, fp, fn]


def _add(c: Counts, label: str, tp=0.0, fp=0.0, fn=0.0):
    v = c.setdefault(label, [0.0, 0.0, 0.0])
    v[0] += tp
    v[1] += fp
    v[2] += fn


def span_counts(gold: List[dict], pred: List[dict]) -> Counts:
    c: Counts = {}
    gold = copy(gold)
    for e in pred:
        if e in gold:
            _add(c, e["type"], tp=1)
            gold.remove(e)
        else:
            _add(c, e["type"], fp=1)
    for e in gold:
        _add(c, e["type"], fn=1)
    return c


def distance_counts(gold: List[dict], pred: List[dict], distance: str) -> Counts:
    dist = DISTANCES[distance]
    c: Counts = {}
    g_lab = [g["type"] for g in gold]
    g_fil = [g["filler"] for g in gold]
    for e in pred:
        lab = e["type"]
        if lab in g_lab:
            idx, best = 0, float("inf")
            for j, gl in enumerate(g_lab):
                if gl == lab:
                    d = dist(g_fil[j], e["filler"])
                    if d < best:
                        idx, best = j, d
            _add(c, lab, tp=1, fp=best, fn=best)
            g_lab.pop(idx)
            g_fil.pop(idx)
        else:
            _add(c, lab, fp=1)
    for gl in g_lab:
        _add(c, gl, fn=1)
    return c


def entity_error_taxonomy(gold: List[dict], pred: List[dict]) -> Dict[str, int]:
    """Diagnostic breakdown (not an official metric): correct / filler_error / type_confusion / missed / spurious."""
    out = defaultdict(int)
    g = list(gold)
    p = list(pred)
    for e in list(p):  # exact matches
        if e in g:
            out["correct"] += 1
            g.remove(e)
            p.remove(e)
    for e in list(p):  # right slot type, wrong value (ASR-like error)
        j = next((i for i, x in enumerate(g) if x["type"] == e["type"]), None)
        if j is not None:
            out["filler_error"] += 1
            g.pop(j)
            p.remove(e)
    for e in list(p):  # right value, wrong slot type (NLU-like error)
        j = next((i for i, x in enumerate(g) if x["filler"] == e["filler"]), None)
        if j is not None:
            out["type_confusion"] += 1
            g.pop(j)
            p.remove(e)
    out["missed"] += len(g)
    out["spurious"] += len(p)
    return dict(out)


@dataclass
class UttScore:
    key: str
    gold: dict
    pred: dict
    invalid: bool
    scenario_ok: bool
    action_ok: bool
    intent_ok: bool
    span: Counts
    word: Counts
    char: Counts
    taxonomy: Dict[str, int]
    meta: dict = field(default_factory=dict)

    @property
    def gold_intent(self):
        return f"{self.gold['scenario']}_{self.gold['action']}"

    @property
    def pred_intent(self):
        return f"{self.pred['scenario']}_{self.pred['action']}"

    def slu_totals(self) -> Tuple[float, float, float]:
        tp = fp = fn = 0.0
        for c in (self.word, self.char):
            for v in c.values():
                tp, fp, fn = tp + v[0], fp + v[1], fn + v[2]
        return tp, fp, fn

    def span_totals(self) -> Tuple[float, float, float]:
        tp = fp = fn = 0.0
        for v in self.span.values():
            tp, fp, fn = tp + v[0], fp + v[1], fn + v[2]
        return tp, fp, fn


def score_utterance(key: str, gold_sem, pred_sem, meta: dict = None) -> UttScore:
    gold, _ = parse_semantics(gold_sem)
    pred, invalid = parse_semantics(pred_sem)
    return UttScore(
        key=key, gold=gold, pred=pred, invalid=invalid,
        scenario_ok=gold["scenario"] == pred["scenario"],
        action_ok=gold["action"] == pred["action"],
        intent_ok=(gold["scenario"], gold["action"]) == (pred["scenario"], pred["action"]),
        span=span_counts(gold["entities"], pred["entities"]),
        word=distance_counts(gold["entities"], pred["entities"], "word"),
        char=distance_counts(gold["entities"], pred["entities"], "char"),
        taxonomy=entity_error_taxonomy(gold["entities"], pred["entities"]),
        meta=meta or {},
    )


# --------------------------------------------------------------------------------------------------------------
# aggregation
# --------------------------------------------------------------------------------------------------------------


def prf(tp: float, fp: float, fn: float) -> Tuple[float, float, float]:
    p = 0.0 if tp == 0 and fp == 0 else tp / (tp + fp)
    r = 0.0 if tp == 0 and fn == 0 else tp / (tp + fn)
    f = 0.0 if p == 0 and r == 0 else 2 * p * r / (p + r)
    return p, r, f


def merge_counts(items: Iterable[Counts]) -> Counts:
    out: Counts = {}
    for c in items:
        for k, v in c.items():
            _add(out, k, *v)
    return out


def _overall(c: Counts, average: str) -> Tuple[float, float, float]:
    if average == "macro":
        if not c:
            return 0.0, 0.0, 0.0
        ps, rs, fs = zip(*(prf(*v) for v in c.values()))
        n = len(c)
        return sum(ps) / n, sum(rs) / n, sum(fs) / n
    return prf(sum(v[0] for v in c.values()), sum(v[1] for v in c.values()), sum(v[2] for v in c.values()))


def _label_f1(gold: List[str], pred: List[str], average: str) -> Tuple[float, float, float]:
    c: Counts = {}
    for g, p in zip(gold, pred):
        if g == p:
            _add(c, p, tp=1)
        else:
            _add(c, p, fp=1)
            _add(c, g, fn=1)
    return _overall(c, average)


def aggregate(scores: Sequence[UttScore], average: str = "micro") -> dict:
    """Corpus-level SLURP metrics (percentages)."""
    n = len(scores)
    if n == 0:
        return {"n": 0}
    span = merge_counts(s.span for s in scores)
    word = merge_counts(s.word for s in scores)
    char = merge_counts(s.char for s in scores)
    slu = merge_counts([word, char])
    res = {"n": n}
    res["scenario_acc"] = 100 * sum(s.scenario_ok for s in scores) / n
    res["action_acc"] = 100 * sum(s.action_ok for s in scores) / n
    res["intent_acc"] = 100 * sum(s.intent_ok for s in scores) / n
    if average == "macro":  # official tool reports macro P/R/F over intent labels in this mode
        p, r, f = _label_f1([s.gold_intent for s in scores], [s.pred_intent for s in scores], "macro")
        res.update(intent_macro_p=100 * p, intent_macro_r=100 * r, intent_macro_f1=100 * f)
    for tag, c in (("span", span), ("word_dist", word), ("char_dist", char), ("slu", slu)):
        p, r, f = _overall(c, average)
        res[f"{tag}_p"], res[f"{tag}_r"], res[f"{tag}_f1"] = 100 * p, 100 * r, 100 * f
    res["invalid_rate"] = 100 * sum(s.invalid for s in scores) / n
    return res


def per_label(scores: Sequence[UttScore], which: str = "slu") -> Dict[str, dict]:
    if which == "slu":
        c = merge_counts([merge_counts(s.word for s in scores), merge_counts(s.char for s in scores)])
    else:
        c = merge_counts(getattr(s, which) for s in scores)
    out = {}
    for lab, (tp, fp, fn) in c.items():
        p, r, f = prf(tp, fp, fn)
        out[lab] = {"p": 100 * p, "r": 100 * r, "f1": 100 * f, "tp": tp, "fp": fp, "fn": fn,
                    "support": None}
    support = defaultdict(int)
    for s in scores:
        for e in s.gold["entities"]:
            support[e["type"]] += 1
    for lab in out:
        out[lab]["support"] = support.get(lab, 0)
    return out
