"""
Parallel Noise Adapters ("noise residual" branch).

    y = Core(x) + s * Up( act( Down( dropout(x) ) ) )

Up is zero-initialised, so at insertion the network is exactly the (compressed) core network.
Because of the non-linearity the adapter can NOT be merged into the core weights after training
(unlike LoRA); its cost (rank * (in + out) MACs per token) is reported by rtc.efficiency.
"""
from __future__ import annotations

import math
import re
from typing import Dict, List

import torch
import torch.nn as nn

_ACTS = {"relu": nn.ReLU, "gelu": nn.GELU, "silu": nn.SiLU, "identity": nn.Identity}


class ParallelNoiseAdapter(nn.Module):
    def __init__(self, base: nn.Module, in_features: int, out_features: int, rank: int = 8,
                 activation: str = "relu", dropout: float = 0.0, scale: float = 1.0,
                 learnable_scale: bool = False, channels_first: bool = False):
        super().__init__()
        self.base = base
        self.channels_first = channels_first  # True when wrapping a [B, C, T] pointwise conv
        self.noise_adapter = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(in_features, rank, bias=True),
            _ACTS[activation](),
            nn.Linear(rank, out_features, bias=False),
        )
        nn.init.kaiming_uniform_(self.noise_adapter[1].weight, a=math.sqrt(5))
        nn.init.zeros_(self.noise_adapter[1].bias)
        nn.init.zeros_(self.noise_adapter[3].weight)
        if learnable_scale:
            self.noise_adapter_scale = nn.Parameter(torch.tensor(float(scale)))
        else:
            self.register_buffer("noise_adapter_scale", torch.tensor(float(scale)), persistent=False)
        self.rank, self.in_features, self.out_features = rank, in_features, out_features

    def forward(self, x):
        y = self.base(x)
        if self.channels_first:
            d = self.noise_adapter(x.transpose(1, 2)).transpose(1, 2)
        else:
            d = self.noise_adapter(x)
        return y + self.noise_adapter_scale.to(y.dtype) * d

    def adapter_macs_per_token(self) -> int:
        return self.rank * (self.in_features + self.out_features)

    # keep attribute look-ups (e.g. `.weight`, `.stride`) working for code that inspects the wrapped layer
    def __getattr__(self, name):
        try:
            return super().__getattr__(name)
        except AttributeError:
            mods = self.__dict__.get("_modules", {})
            if "base" in mods:
                return getattr(mods["base"], name)
            raise


def _io_dims(mod: nn.Module):
    if isinstance(mod, nn.Linear):
        return mod.in_features, mod.out_features, False
    if isinstance(mod, nn.Conv1d):
        assert mod.kernel_size == (1,) and mod.groups == 1, "adapters only for pointwise conv1d"
        return mod.in_channels, mod.out_channels, True
    lin = getattr(mod, "linear", None)  # PointwiseConv1d
    if lin is not None:
        return lin.in_features, lin.out_features, True
    if hasattr(mod, "in_features"):
        return mod.in_features, mod.out_features, False
    raise TypeError(f"cannot attach adapter to {type(mod)}")


def inject_adapters(model: nn.Module, group_patterns: Dict[str, str], targets: List[str], rank: int = 8,
                    activation: str = "relu", dropout: float = 0.0, scale: float = 1.0,
                    learnable_scale: bool = False) -> List[dict]:
    """Wrap every module whose qualified name matches one of the target groups' regexes."""
    report = []
    regexes = {g: re.compile(group_patterns[g]) for g in targets}
    for name, mod in list(model.named_modules()):
        group = next((g for g, rx in regexes.items() if rx.search(name)), None)
        if group is None or isinstance(mod, ParallelNoiseAdapter):
            continue
        in_f, out_f, ch_first = _io_dims(mod)
        wrapped = ParallelNoiseAdapter(mod, in_f, out_f, rank, activation, dropout, scale, learnable_scale, ch_first)
        wrapped.to(next(mod.parameters()).device)
        parent_name, _, child = name.rpartition(".")
        setattr(model.get_submodule(parent_name) if parent_name else model, child, wrapped)
        report.append({"module": name, "group": group, "in": in_f, "out": out_f, "rank": rank,
                       "params": sum(p.numel() for p in wrapped.noise_adapter.parameters())})
    if not report:
        raise RuntimeError(f"No modules matched adapter targets {targets}")
    return report


def adapter_parameters(model: nn.Module):
    for n, p in model.named_parameters():
        if ".noise_adapter" in n:
            yield n, p
