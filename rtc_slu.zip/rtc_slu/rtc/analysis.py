"""
Deep analysis of SLURP predictions for one system across test conditions, plus paired system comparisons.

Produced per system (results/):
  summary.json             every number below, machine readable
  report.md                human readable tables
  tables/*.csv             table view of every figure
  figures/*.png            robustness curve, entity-error taxonomy, scenario heatmap, slot-type heatmap
"""
from __future__ import annotations

import csv
import json
import math
import os
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .slurp_metrics import UttScore, aggregate, per_label, prf

# reference palette (dataviz skill, light mode): categorical order is fixed, never cycled
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
BLUE_RAMP = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#2a78d6", "#1c5cab", "#104281", "#0d366b"]


# --------------------------------------------------------------------------------------------------------------
# statistics
# --------------------------------------------------------------------------------------------------------------


def _arrays(scores: Sequence[UttScore]):
    intent = np.array([s.intent_ok for s in scores], dtype=float)
    slu = np.array([s.slu_totals() for s in scores], dtype=float).reshape(-1, 3)
    span = np.array([s.span_totals() for s in scores], dtype=float).reshape(-1, 3)
    return intent, slu, span


def _f1_from(c: np.ndarray) -> np.ndarray:  # c[..., 3] -> F1 (%)
    tp, fp, fn = c[..., 0], c[..., 1], c[..., 2]
    p = np.divide(tp, tp + fp, out=np.zeros_like(tp), where=(tp + fp) > 0)
    r = np.divide(tp, tp + fn, out=np.zeros_like(tp), where=(tp + fn) > 0)
    return 100 * np.divide(2 * p * r, p + r, out=np.zeros_like(p), where=(p + r) > 0)


def bootstrap_ci(scores: Sequence[UttScore], n_boot: int = 1000, alpha: float = 0.05, seed: int = 0) -> dict:
    """Percentile bootstrap over utterances for intent accuracy, SLU-F1 and span-F1."""
    if n_boot <= 0 or not scores:
        return {}
    intent, slu, span = _arrays(scores)
    rng = np.random.default_rng(seed)
    n = len(scores)
    ia, sf, pf = np.empty(n_boot), np.empty(n_boot), np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, n)
        ia[b] = 100 * intent[idx].mean()
        sf[b] = _f1_from(slu[idx].sum(0))
        pf[b] = _f1_from(span[idx].sum(0))
    lo, hi = 100 * alpha / 2, 100 * (1 - alpha / 2)
    return {k: [float(np.percentile(v, lo)), float(np.percentile(v, hi))]
            for k, v in (("intent_acc", ia), ("slu_f1", sf), ("span_f1", pf))}


def mcnemar_exact(a_ok: np.ndarray, b_ok: np.ndarray) -> dict:
    """Exact (binomial) McNemar test on paired per-utterance correctness."""
    b = int(np.sum(a_ok & ~b_ok))
    c = int(np.sum(~a_ok & b_ok))
    n = b + c
    if n == 0:
        return {"a_only": b, "b_only": c, "p": 1.0}
    k = min(b, c)
    # two-sided exact p = 2 * P(X <= k), X ~ Bin(n, .5); computed in log space for large n
    logs = [math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1) - n * math.log(2) for i in range(k + 1)]
    m = max(logs)
    p = 2 * math.exp(m) * sum(math.exp(x - m) for x in logs)
    return {"a_only": b, "b_only": c, "p": min(1.0, p)}


def paired_comparison(a: Sequence[UttScore], b: Sequence[UttScore], n_boot: int = 1000, seed: int = 0) -> dict:
    """System A vs B on the same utterances (paired by recording + condition)."""
    ka = {(s.meta.get("condition"), s.key): s for s in a}
    kb = {(s.meta.get("condition"), s.key): s for s in b}
    keys = sorted(set(ka) & set(kb))
    if not keys:
        return {"n": 0}
    A = [ka[k] for k in keys]
    B = [kb[k] for k in keys]
    ia, sa, _ = _arrays(A)
    ib, sb, _ = _arrays(B)
    d_int = 100 * (ia.mean() - ib.mean())
    d_slu = float(_f1_from(sa.sum(0)) - _f1_from(sb.sum(0)))
    rng = np.random.default_rng(seed)
    n = len(keys)
    deltas = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        deltas[i] = _f1_from(sa[idx].sum(0)) - _f1_from(sb[idx].sum(0))
    # two-sided paired-bootstrap p-value for the SLU-F1 difference (shift method)
    p_slu = float(np.mean(np.abs(deltas - d_slu) >= abs(d_slu)))
    return {"n": n, "delta_intent_acc": float(d_int), "delta_slu_f1": d_slu,
            "slu_f1_delta_ci": [float(np.percentile(deltas, 2.5)), float(np.percentile(deltas, 97.5))],
            "p_slu_f1_bootstrap": p_slu, "mcnemar_intent": mcnemar_exact(ia.astype(bool), ib.astype(bool))}


# --------------------------------------------------------------------------------------------------------------
# breakdowns
# --------------------------------------------------------------------------------------------------------------


def _bucket_entities(s: UttScore) -> str:
    k = len(s.gold["entities"])
    return str(k) if k < 3 else "3+"


def _bucket_duration(s: UttScore) -> str:
    d = s.meta.get("duration", 0.0)
    return "<2s" if d < 2 else "2-4s" if d < 4 else "4-6s" if d < 6 else ">=6s"


def breakdown(scores: Sequence[UttScore], key_fn) -> Dict[str, dict]:
    groups = defaultdict(list)
    for s in scores:
        k = key_fn(s)
        if k is not None:
            groups[k].append(s)
    return {k: {**{m: aggregate(v)[m] for m in ("n", "intent_acc", "slu_f1", "span_f1")}} for k, v in groups.items()}


def intent_error_decomposition(scores: Sequence[UttScore]) -> dict:
    n = len(scores)
    c = Counter()
    for s in scores:
        if s.intent_ok:
            continue
        if s.invalid and s.pred["scenario"] == "none":
            c["invalid_output"] += 1
        elif not s.scenario_ok and not s.action_ok:
            c["scenario+action_wrong"] += 1
        elif not s.scenario_ok:
            c["scenario_wrong_only"] += 1
        else:
            c["action_wrong_only"] += 1
    return {k: 100 * v / n for k, v in c.items()}


def top_confusions(scores: Sequence[UttScore], k: int = 15) -> List[Tuple[str, str, int]]:
    c = Counter((s.gold_intent, s.pred_intent) for s in scores if not s.intent_ok)
    return [(g, p, n) for (g, p), n in c.most_common(k)]


def taxonomy(scores: Sequence[UttScore]) -> dict:
    tot = Counter()
    for s in scores:
        tot.update(s.taxonomy)
    n_gold = sum(len(s.gold["entities"]) for s in scores)
    out = {k: int(v) for k, v in tot.items()}
    out["gold_entities"] = n_gold
    out["per_100_gold"] = {k: 100 * v / max(n_gold, 1) for k, v in tot.items()}
    return out


def per_scenario_acc(scores: Sequence[UttScore]) -> Dict[str, dict]:
    g = defaultdict(list)
    for s in scores:
        g[s.gold["scenario"]].append(s.intent_ok)
    return {k: {"n": len(v), "intent_acc": 100 * float(np.mean(v))} for k, v in g.items()}


def macro_intent_f1(scores: Sequence[UttScore]) -> float:
    return aggregate(scores, average="macro")["intent_macro_f1"]


# --------------------------------------------------------------------------------------------------------------
# full per-system analysis
# --------------------------------------------------------------------------------------------------------------


def _snr_sort_key(c: str):
    """clean first, then conditions by descending SNR (number found in the name), then anything else."""
    import re
    if c.lower() == "clean":
        return (-1, 0.0, c)
    m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:db)?$", c.lower())
    return (0, -float(m.group(1)), c) if m else (1, 0.0, c)


def analyze_system(by_cond: Dict[str, List[UttScore]], out_dir: str, reference: str = "clean",
                   n_boot: int = 1000, system_name: str = "") -> dict:
    os.makedirs(os.path.join(out_dir, "tables"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "figures"), exist_ok=True)
    summary = {"system": system_name, "conditions": {}}
    all_scores = [s for v in by_cond.values() for s in v]

    for cond, scores in by_cond.items():
        res = aggregate(scores)
        res["ci95"] = bootstrap_ci(scores, n_boot)
        res["intent_macro_f1"] = macro_intent_f1(scores)
        res["intent_errors"] = intent_error_decomposition(scores)
        res["entity_taxonomy"] = taxonomy(scores)
        res["by_mic"] = breakdown(scores, lambda s: s.meta.get("mic"))
        res["by_num_entities"] = breakdown(scores, _bucket_entities)
        res["by_duration"] = breakdown(scores, _bucket_duration)
        if any("noise_type" in s.meta for s in scores):
            res["by_noise_type"] = breakdown(scores, lambda s: s.meta.get("noise_type"))
        if any("snr" in s.meta for s in scores):
            res["by_snr"] = breakdown(scores, lambda s: s.meta.get("snr"))
        res["per_scenario"] = per_scenario_acc(scores)
        res["per_slot_type"] = per_label(scores, "slu")
        res["top_confusions"] = top_confusions(scores)
        summary["conditions"][cond] = res

    # pooled SNR x noise-type grid (when per-utterance tags exist)
    if any("snr" in s.meta for s in all_scores):
        summary["snr_x_noise"] = breakdown(all_scores, lambda s: f"{s.meta.get('noise_type', 'all')}|{s.meta.get('snr')}"
                                           if "snr" in s.meta else None)

    # robustness w.r.t. the reference (clean) condition
    conds = summary["conditions"]
    if reference in conds:
        ref = conds[reference]
        rob = {}
        noisy = [c for c in conds if c != reference]
        for c in noisy:
            rob[c] = {m: {"abs_drop": ref[m] - conds[c][m],
                          "rel_drop_pct": 100 * (ref[m] - conds[c][m]) / max(ref[m], 1e-9),
                          "retention_pct": 100 * conds[c][m] / max(ref[m], 1e-9)}
                      for m in ("intent_acc", "slu_f1")}
        if noisy:
            rob["mean_over_noisy"] = {m: {"value": float(np.mean([conds[c][m] for c in noisy])),
                                          "retention_pct": float(np.mean([rob[c][m]["retention_pct"] for c in noisy]))}
                                      for m in ("intent_acc", "slu_f1")}
        # per slot type: which slots break first under noise
        worst = min(noisy, key=lambda c: conds[c]["slu_f1"]) if noisy else None
        if worst:
            slot_drop = []
            for lab, v in ref["per_slot_type"].items():
                w = conds[worst]["per_slot_type"].get(lab)
                if w and v["support"] >= 20:
                    slot_drop.append((lab, v["support"], v["f1"], w["f1"], v["f1"] - w["f1"]))
            rob["slot_types_most_degraded"] = {"condition": worst, "rows": sorted(slot_drop, key=lambda r: -r[4])[:15]}
        summary["robustness"] = rob

    _write_tables(summary, out_dir)
    _plots(summary, out_dir, reference)
    with open(os.path.join(out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    with open(os.path.join(out_dir, "report.md"), "w") as f:
        f.write(render_markdown(summary, reference))
    return summary


# --------------------------------------------------------------------------------------------------------------
# outputs
# --------------------------------------------------------------------------------------------------------------

MAIN_COLS = [("scenario_acc", "Scenario Acc"), ("action_acc", "Action Acc"), ("intent_acc", "Intent Acc"),
             ("intent_macro_f1", "Intent macro-F1"), ("span_p", "Span P"), ("span_r", "Span R"), ("span_f1", "Span F1"),
             ("word_dist_f1", "Word-dist F1"), ("char_dist_f1", "Char-dist F1"), ("slu_p", "SLU P"),
             ("slu_r", "SLU R"), ("slu_f1", "SLU-F1"), ("invalid_rate", "Invalid %")]


def _ordered(conds):
    return sorted(conds, key=_snr_sort_key)


def _write_csv(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def _write_tables(summary, out_dir):
    conds = summary["conditions"]
    t = os.path.join(out_dir, "tables")
    _write_csv(os.path.join(t, "main.csv"), ["condition", "n"] + [c[1] for c in MAIN_COLS]
               + ["Intent Acc CI lo", "Intent Acc CI hi", "SLU-F1 CI lo", "SLU-F1 CI hi"],
               [[c, conds[c]["n"]] + [round(conds[c][k], 2) for k, _ in MAIN_COLS]
                + [round(x, 2) for x in conds[c]["ci95"].get("intent_acc", [float("nan")] * 2)
                   + conds[c]["ci95"].get("slu_f1", [float("nan")] * 2)] for c in _ordered(conds)])
    tax_keys = ["correct", "filler_error", "type_confusion", "missed", "spurious"]
    _write_csv(os.path.join(t, "entity_taxonomy_per100gold.csv"), ["condition"] + tax_keys,
               [[c] + [round(conds[c]["entity_taxonomy"]["per_100_gold"].get(k, 0.0), 2) for k in tax_keys]
                for c in _ordered(conds)])
    scen = sorted({s for c in conds.values() for s in c["per_scenario"]})
    _write_csv(os.path.join(t, "per_scenario_intent_acc.csv"), ["scenario"] + _ordered(conds),
               [[s] + [round(conds[c]["per_scenario"].get(s, {}).get("intent_acc", float("nan")), 2)
                       for c in _ordered(conds)] for s in scen])
    slots = sorted({s for c in conds.values() for s in c["per_slot_type"]})
    _write_csv(os.path.join(t, "per_slot_type_slu_f1.csv"), ["slot_type", "support(ref)"] + _ordered(conds),
               [[s, max(conds[c]["per_slot_type"].get(s, {}).get("support", 0) for c in conds)]
                + [round(conds[c]["per_slot_type"].get(s, {}).get("f1", float("nan")), 2) for c in _ordered(conds)]
                for s in slots])


def _style(ax):
    ax.set_facecolor(SURFACE)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    for sp in ("left", "bottom"):
        ax.spines[sp].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=9)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def _plots(summary, out_dir, reference):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    conds = summary["conditions"]
    order = _ordered(conds)
    fig_dir = os.path.join(out_dir, "figures")

    # 1) robustness curve: one chart per metric (never a dual axis)
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.4), facecolor=SURFACE)
    for ax, (m, title) in zip(axes, (("intent_acc", "Intent accuracy (%)"), ("slu_f1", "SLU-F1 (%)"))):
        _style(ax)
        y = [conds[c][m] for c in order]
        ci = [conds[c]["ci95"].get(m, [v, v]) for c, v in zip(order, y)]
        x = np.arange(len(order))
        ax.fill_between(x, [c[0] for c in ci], [c[1] for c in ci], color=SERIES[0], alpha=0.15, linewidth=0)
        ax.plot(x, y, color=SERIES[0], linewidth=2, marker="o", markersize=8, markeredgecolor=SURFACE, markeredgewidth=2)
        for xi, yi in zip(x, y):
            ax.annotate(f"{yi:.1f}", (xi, yi), textcoords="offset points", xytext=(0, 9), ha="center", fontsize=8, color=INK)
        ax.set_xticks(x, order)
        ax.set_title(title, fontsize=10, color=INK, loc="left")
    fig.suptitle(f"{summary['system']}: performance by test condition (band = 95% bootstrap CI)", fontsize=10,
                 color=INK2, x=0.01, ha="left")
    fig.tight_layout()
    fig.savefig(os.path.join(fig_dir, "robustness_curve.png"), dpi=200, facecolor=SURFACE)
    plt.close(fig)

    # 2) entity error taxonomy, stacked per condition (2px surface gaps between segments)
    keys = [("filler_error", "Wrong value"), ("type_confusion", "Wrong slot type"), ("missed", "Missed"),
            ("spurious", "Spurious")]
    fig, ax = plt.subplots(figsize=(7, 3.4), facecolor=SURFACE)
    _style(ax)
    bottom = np.zeros(len(order))
    for i, (k, lab) in enumerate(keys):
        v = np.array([conds[c]["entity_taxonomy"]["per_100_gold"].get(k, 0.0) for c in order])
        ax.bar(order, v, bottom=bottom, color=SERIES[i], label=lab, width=0.6, edgecolor=SURFACE, linewidth=2)
        bottom += v
    ax.set_ylabel("errors per 100 gold slots", color=INK2, fontsize=9)
    ax.legend(frameon=False, fontsize=8, ncol=4, loc="upper left", bbox_to_anchor=(0, 1.15), labelcolor=INK2)
    fig.tight_layout()
    fig.savefig(os.path.join(fig_dir, "entity_error_taxonomy.png"), dpi=200, facecolor=SURFACE)
    plt.close(fig)

    # 3) heatmaps (sequential single hue)
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list("blue", BLUE_RAMP)
    for name, key, val, min_support in (("scenario_intent_acc", "per_scenario", "intent_acc", 0),
                                        ("slot_type_slu_f1", "per_slot_type", "f1", 20)):
        rows = sorted({r for c in conds.values() for r, v in c[key].items()
                       if (v.get("support", v.get("n", 0)) or 0) >= min_support})
        if not rows:
            continue
        mat = np.array([[conds[c][key].get(r, {}).get(val, np.nan) for c in order] for r in rows])
        fig, ax = plt.subplots(figsize=(1.2 + 0.9 * len(order), 0.8 + 0.28 * len(rows)), facecolor=SURFACE)
        im = ax.imshow(mat, cmap=cmap, vmin=0, vmax=100, aspect="auto")
        ax.set_xticks(range(len(order)), order, fontsize=8, color=INK2)
        ax.set_yticks(range(len(rows)), rows, fontsize=7, color=INK2)
        for i in range(len(rows)):
            for j in range(len(order)):
                if not np.isnan(mat[i, j]):
                    ax.text(j, i, f"{mat[i, j]:.0f}", ha="center", va="center", fontsize=6.5,
                            color=INK if mat[i, j] < 60 else SURFACE)
        for sp in ax.spines.values():
            sp.set_visible(False)
        fig.colorbar(im, ax=ax, fraction=0.04).ax.tick_params(labelsize=7, colors=INK2)
        fig.tight_layout()
        fig.savefig(os.path.join(fig_dir, f"{name}_heatmap.png"), dpi=200, facecolor=SURFACE)
        plt.close(fig)


def _fmt(v, d=2):
    return "-" if v is None or (isinstance(v, float) and math.isnan(v)) else f"{v:.{d}f}"


def render_markdown(summary, reference="clean") -> str:
    conds = summary["conditions"]
    order = _ordered(conds)
    L = [f"# Results: {summary['system']}", ""]
    L += ["## 1. Standard SLURP metrics (official definitions, micro-averaged)", "",
          "| Condition | N | " + " | ".join(c[1] for c in MAIN_COLS) + " |",
          "|" + "---|" * (len(MAIN_COLS) + 2)]
    for c in order:
        L.append(f"| {c} | {conds[c]['n']} | " + " | ".join(_fmt(conds[c][k]) for k, _ in MAIN_COLS) + " |")
    L += ["", "95% bootstrap CIs (utterance resampling):", "",
          "| Condition | Intent Acc | SLU-F1 | Span F1 |", "|---|---|---|---|"]
    for c in order:
        ci = conds[c]["ci95"]
        L.append(f"| {c} | " + " | ".join(f"{_fmt(conds[c][m])} [{_fmt(ci[m][0])}, {_fmt(ci[m][1])}]" if m in ci else "-"
                                         for m in ("intent_acc", "slu_f1", "span_f1")) + " |")
    if "robustness" in summary:
        rob = summary["robustness"]
        L += ["", f"## 2. Robustness relative to `{reference}`", "",
              "| Condition | Intent Acc drop (abs) | Intent retention % | SLU-F1 drop (abs) | SLU-F1 retention % |",
              "|---|---|---|---|---|"]
        for c in order:
            if c in rob:
                r = rob[c]
                L.append(f"| {c} | {_fmt(r['intent_acc']['abs_drop'])} | {_fmt(r['intent_acc']['retention_pct'])} | "
                         f"{_fmt(r['slu_f1']['abs_drop'])} | {_fmt(r['slu_f1']['retention_pct'])} |")
        if "mean_over_noisy" in rob:
            m = rob["mean_over_noisy"]
            L.append(f"| **mean (noisy)** | | {_fmt(m['intent_acc']['retention_pct'])} | | {_fmt(m['slu_f1']['retention_pct'])} |")
        if rob.get("slot_types_most_degraded", {}).get("rows"):
            sd = rob["slot_types_most_degraded"]
            L += ["", f"Slot types losing the most SLU-F1 from `{reference}` to `{sd['condition']}` (support >= 20):", "",
                  "| Slot type | Support | F1 ref | F1 noisy | Drop |", "|---|---|---|---|---|"]
            L += [f"| {r[0]} | {r[1]} | {_fmt(r[2])} | {_fmt(r[3])} | {_fmt(r[4])} |" for r in sd["rows"]]
    L += ["", "## 3. Intent error decomposition (% of all utterances)", "",
          "| Condition | scenario only | action only | both | invalid output |", "|---|---|---|---|---|"]
    for c in order:
        e = conds[c]["intent_errors"]
        L.append(f"| {c} | {_fmt(e.get('scenario_wrong_only', 0))} | {_fmt(e.get('action_wrong_only', 0))} | "
                 f"{_fmt(e.get('scenario+action_wrong', 0))} | {_fmt(e.get('invalid_output', 0))} |")
    L += ["", "## 4. Slot error taxonomy (per 100 gold slots)", "",
          "Diagnostic, not an official metric. *Wrong value* = right slot type, wrong filler (typically "
          "acoustic/ASR-driven); *wrong slot type* = right filler, wrong label (NLU-driven).", "",
          "| Condition | correct | wrong value | wrong slot type | missed | spurious |", "|---|---|---|---|---|---|"]
    for c in order:
        t = conds[c]["entity_taxonomy"]["per_100_gold"]
        L.append(f"| {c} | " + " | ".join(_fmt(t.get(k, 0)) for k in
                                         ("correct", "filler_error", "type_confusion", "missed", "spurious")) + " |")
    for bkey, title in (("by_mic", "microphone"), ("by_num_entities", "number of gold slots"),
                        ("by_duration", "utterance duration"), ("by_noise_type", "noise type"), ("by_snr", "SNR tag")):
        if not any(bkey in conds[c] for c in order):
            continue
        groups = sorted({g for c in order for g in conds[c].get(bkey, {})})
        L += ["", f"## Breakdown by {title} (Intent Acc / SLU-F1)", "",
              "| Condition | " + " | ".join(groups) + " |", "|" + "---|" * (len(groups) + 1)]
        for c in order:
            b = conds[c].get(bkey, {})
            L.append(f"| {c} | " + " | ".join(
                f"{_fmt(b[g]['intent_acc'], 1)} / {_fmt(b[g]['slu_f1'], 1)} (n={b[g]['n']})" if g in b else "-"
                for g in groups) + " |")
    worst = min(order, key=lambda c: conds[c]["intent_acc"])
    L += ["", f"## Most frequent intent confusions in `{worst}`", "", "| gold | predicted | count |", "|---|---|---|"]
    L += [f"| {g} | {p} | {n} |" for g, p, n in conds[worst]["top_confusions"]]
    L += ["", "Figures: `figures/robustness_curve.png`, `figures/entity_error_taxonomy.png`, "
          "`figures/scenario_intent_acc_heatmap.png`, `figures/slot_type_slu_f1_heatmap.png`. "
          "The same numbers are in `tables/*.csv`.", ""]
    return "\n".join(L)
