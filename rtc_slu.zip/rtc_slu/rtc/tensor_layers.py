"""
Factorized replacements for dense layers, each initialised from pretrained weights.

  * TTLinear       - Tensor-Train matrix (TT-matrix / "TT-layer", Novikov et al. 2015), init by TT-SVD.
  * TuckerLinear   - Tucker decomposition of a tensorised weight matrix, init by HOSVD + HOOI.
                     Used with the per-head layout [num_heads, head_dim, d_model] for attention projections.
  * LowRankLinear  - Truncated SVD (matrix baseline; reviewers will ask "why not plain SVD?").
  * Tucker2Conv2d  - Tucker-2 over (C_out, C_in) of a 4-D conv kernel (Kim et al. 2016) -> 1x1 / kxk / 1x1.
  * PointwiseConv1d - wraps any linear-like module so it can replace a kernel-size-1 nn.Conv1d ([B, C, T]).

Every factorized linear supports two execution modes:
  * "dense"      : rebuild W from the factors on each forward, then one GEMM. Fastest on GPUs for training,
                   storage/parameter savings are real, FLOPs are those of the dense layer.
  * "factorized" : never materialise W; contract the input with the factors. FLOP savings are real.
Both modes give the same output up to float error (see tests/test_tensor_layers.py).
"""
from __future__ import annotations

import math
import string
from typing import List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

# --------------------------------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------------------------------


def _prime_factors(n: int) -> List[int]:
    out, d = [], 2
    while d * d <= n:
        while n % d == 0:
            out.append(d)
            n //= d
        d += 1
    if n > 1:
        out.append(n)
    return out


def factorize_dim(n: int, k: int) -> List[int]:
    """Split n into k integer factors that are as balanced as possible (product is exactly n)."""
    if k == 1:
        return [n]
    buckets = [1] * k
    for p in sorted(_prime_factors(n), reverse=True):
        i = min(range(k), key=lambda j: buckets[j])
        buckets[i] *= p
    return sorted(buckets)


def mode_product(t: torch.Tensor, mat: torch.Tensor, mode: int) -> torch.Tensor:
    """t x_mode mat, where mat has shape [new_dim, t.shape[mode]]."""
    t = torch.movedim(t, mode, 0)
    shp = t.shape
    out = mat @ t.reshape(shp[0], -1)
    return torch.movedim(out.reshape(mat.shape[0], *shp[1:]), 0, mode)


def unfold(t: torch.Tensor, mode: int) -> torch.Tensor:
    return torch.movedim(t, mode, 0).reshape(t.shape[mode], -1)


def _leading_left_singular(m: torch.Tensor, r: int) -> torch.Tensor:
    u, _, _ = torch.linalg.svd(m, full_matrices=False)
    return u[:, :r]


def relative_error(w: torch.Tensor, w_hat: torch.Tensor) -> float:
    return float(torch.linalg.norm(w - w_hat) / torch.linalg.norm(w).clamp_min(1e-12))


# --------------------------------------------------------------------------------------------------------------
# base class
# --------------------------------------------------------------------------------------------------------------


class FactorizedLinear(nn.Module):
    """Common interface. Subclasses implement `weight_from_factors()` and `_factorized_forward()`."""

    method: str = "base"

    def __init__(self, in_features: int, out_features: int, bias: Optional[torch.Tensor], forward_mode: str):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.forward_mode = forward_mode
        self.bias = nn.Parameter(bias.detach().clone()) if bias is not None else None
        self.init_rel_error: Optional[float] = None

    # --- interface -----------------------------------------------------------------------------------------
    def weight_from_factors(self) -> torch.Tensor:  # [out, in]
        raise NotImplementedError

    def _factorized_forward(self, x2d: torch.Tensor) -> torch.Tensor:  # [B, in] -> [B, out]
        raise NotImplementedError

    def macs_per_token(self) -> int:  # multiply-accumulates for one input vector, factorized mode
        raise NotImplementedError

    def spec(self) -> dict:  # everything needed to rebuild the empty module (for checkpoint loading)
        raise NotImplementedError

    # --- shared --------------------------------------------------------------------------------------------
    def factor_parameters(self):
        for n, p in self.named_parameters():
            if n != "bias":
                yield p

    def num_factor_params(self) -> int:
        return sum(p.numel() for p in self.factor_parameters())

    def dense_params(self) -> int:
        return self.in_features * self.out_features

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.forward_mode == "dense":
            return F.linear(x, self.weight_from_factors().to(x.dtype), None if self.bias is None else self.bias.to(x.dtype))
        shp = x.shape
        y = self._factorized_forward(x.reshape(-1, shp[-1]))
        if self.bias is not None:
            y = y + self.bias.to(y.dtype)
        return y.reshape(*shp[:-1], self.out_features)

    @property
    def weight(self) -> torch.Tensor:  # convenience for code that peeks at .weight (dtype/device checks)
        return self.weight_from_factors()

    def extra_repr(self) -> str:
        return (f"in={self.in_features}, out={self.out_features}, params={self.num_factor_params()} "
                f"({self.num_factor_params() / self.dense_params():.3f} of dense), mode={self.forward_mode}")


# --------------------------------------------------------------------------------------------------------------
# Tensor-Train matrix
# --------------------------------------------------------------------------------------------------------------


def tt_svd(t: torch.Tensor, max_ranks: Sequence[int]) -> List[torch.Tensor]:
    """TT-SVD (Oseledets 2011). Returns cores [r_{k-1}, d_k, r_k] with r_0 = r_K = 1."""
    dims = list(t.shape)
    cores, r_prev, c = [], 1, t
    for k in range(len(dims) - 1):
        c = c.reshape(r_prev * dims[k], -1)
        u, s, vh = torch.linalg.svd(c, full_matrices=False)
        r = max(1, min(int(max_ranks[k]), s.numel()))
        cores.append(u[:, :r].reshape(r_prev, dims[k], r))
        c = s[:r, None] * vh[:r]
        r_prev = r
    cores.append(c.reshape(r_prev, dims[-1], 1))
    return cores


class TTLinear(FactorizedLinear):
    """
    W[out, in], out = prod(m_k), in = prod(n_k). Cores G_k: [r_{k-1}, m_k, n_k, r_k].
    W[(i_1..i_d), (j_1..j_d)] = G_1[:, i_1, j_1, :] @ ... @ G_d[:, i_d, j_d, :]
    """

    method = "tt"

    def __init__(self, in_modes: Sequence[int], out_modes: Sequence[int], ranks: Sequence[int],
                 bias: Optional[torch.Tensor] = None, forward_mode: str = "dense"):
        assert len(in_modes) == len(out_modes) and len(ranks) == len(in_modes) + 1 and ranks[0] == ranks[-1] == 1
        super().__init__(math.prod(in_modes), math.prod(out_modes), bias, forward_mode)
        self.in_modes, self.out_modes, self.ranks = list(in_modes), list(out_modes), list(ranks)
        self.cores = nn.ParameterList([
            nn.Parameter(torch.empty(ranks[k], out_modes[k], in_modes[k], ranks[k + 1]))
            for k in range(len(in_modes))
        ])
        for c in self.cores:
            nn.init.normal_(c, std=1.0 / math.sqrt(c.shape[0] * c.shape[2]))

    # ---- construction ---------------------------------------------------------------------------------------
    @staticmethod
    def params_for_rank(in_modes, out_modes, r: int) -> int:
        d = len(in_modes)
        ranks = TTLinear._clip_ranks(in_modes, out_modes, [1] + [r] * (d - 1) + [1])
        return sum(ranks[k] * out_modes[k] * in_modes[k] * ranks[k + 1] for k in range(d))

    @staticmethod
    def _clip_ranks(in_modes, out_modes, ranks):
        d = len(in_modes)
        sizes = [in_modes[k] * out_modes[k] for k in range(d)]
        ranks = list(ranks)
        for k in range(1, d):  # TT rank k cannot exceed prod of sizes on either side
            ranks[k] = min(ranks[k], math.prod(sizes[:k]), math.prod(sizes[k:]))
        return ranks

    @classmethod
    def from_weight(cls, weight: torch.Tensor, bias: Optional[torch.Tensor], num_cores: int = 3,
                    rank: Optional[int] = None, ratio: Optional[float] = None, forward_mode: str = "dense",
                    in_modes: Optional[Sequence[int]] = None, out_modes: Optional[Sequence[int]] = None):
        out_f, in_f = weight.shape
        in_modes = list(in_modes) if in_modes else factorize_dim(in_f, num_cores)
        out_modes = list(out_modes) if out_modes else factorize_dim(out_f, num_cores)
        d = len(in_modes)
        if rank is None:
            assert ratio is not None, "TTLinear needs `rank` or `ratio`"
            budget, rank = ratio * in_f * out_f, 1
            while cls.params_for_rank(in_modes, out_modes, rank + 1) <= budget and rank < 4096:
                rank += 1
        w = weight.detach().double()
        # [m1..md, n1..nd] -> [m1,n1,m2,n2,...] -> [m1 n1, ..., md nd]
        t = w.reshape(*out_modes, *in_modes)
        perm = [i for k in range(d) for i in (k, d + k)]
        t = t.permute(*perm).reshape(*[out_modes[k] * in_modes[k] for k in range(d)])
        cores = tt_svd(t, [rank] * (d - 1))
        ranks = [1] + [c.shape[2] for c in cores[:-1]] + [1]
        mod = cls(in_modes, out_modes, ranks, bias, forward_mode).to(weight.dtype)
        with torch.no_grad():
            for k, c in enumerate(cores):
                mod.cores[k].copy_(c.reshape(ranks[k], out_modes[k], in_modes[k], ranks[k + 1]).to(weight.dtype))
            mod.init_rel_error = relative_error(w, mod.weight_from_factors().double())
        return mod

    # ---- compute ---------------------------------------------------------------------------------------------
    def weight_from_factors(self) -> torch.Tensor:
        c0 = self.cores[0]
        w = c0.reshape(c0.shape[1], c0.shape[2], c0.shape[3])  # [M_acc, N_acc, r]
        for core in list(self.cores)[1:]:
            a, b, _ = w.shape
            w = torch.einsum("abr,rmns->ambns", w, core).reshape(a * core.shape[1], b * core.shape[2], core.shape[3])
        return w.squeeze(-1)

    def _factorized_forward(self, x: torch.Tensor) -> torch.Tensor:
        bsz, d = x.shape[0], len(self.cores)
        n_rest = self.in_features // self.in_modes[0]
        s = x.reshape(bsz, self.in_modes[0], n_rest, 1, 1)  # [B, n_k, N_rest, M_prev, r_{k-1}]
        for k, core in enumerate(self.cores):
            core = core.to(x.dtype)
            out = torch.einsum("bnqpr,rmns->bqpms", s, core)  # [B, N_rest, M_prev, m_k, r_k]
            b_, q_, p_, m_, r_ = out.shape
            out = out.reshape(b_, q_, p_ * m_, r_)
            if k + 1 < d:
                nk = self.in_modes[k + 1]
                s = out.reshape(b_, nk, q_ // nk, p_ * m_, r_)
            else:
                s = out
        return s.reshape(bsz, self.out_features)

    def macs_per_token(self) -> int:
        macs, n_rest, m_prev = 0, self.in_features, 1
        for k in range(len(self.cores)):
            n_rest //= self.in_modes[k]
            macs += n_rest * m_prev * self.ranks[k] * self.out_modes[k] * self.in_modes[k] * self.ranks[k + 1]
            m_prev *= self.out_modes[k]
        return macs

    def spec(self) -> dict:
        return {"method": "tt", "in_modes": self.in_modes, "out_modes": self.out_modes, "ranks": self.ranks,
                "bias": self.bias is not None}


# --------------------------------------------------------------------------------------------------------------
# Tucker on a tensorised matrix
# --------------------------------------------------------------------------------------------------------------


def tucker_hooi(t: torch.Tensor, ranks: Sequence[int], n_iter: int = 10) -> Tuple[torch.Tensor, List[torch.Tensor]]:
    """HOSVD initialisation followed by HOOI refinement. Returns (core, factors[dim_i, R_i])."""
    factors = [_leading_left_singular(unfold(t, i), r) for i, r in enumerate(ranks)]
    for _ in range(n_iter):
        for i in range(t.dim()):
            y = t
            for j, u in enumerate(factors):
                if j != i:
                    y = mode_product(y, u.T, j)
            factors[i] = _leading_left_singular(unfold(y, i), ranks[i])
    core = t
    for j, u in enumerate(factors):
        core = mode_product(core, u.T, j)
    return core, factors


class TuckerLinear(FactorizedLinear):
    """
    W[out, in] is viewed as a tensor with modes (out_modes..., in_modes...), e.g. for an attention Q/K/V projection
    (num_heads, head_dim | d_model) and for the output projection (d_model | num_heads, head_dim).
    W = G x_1 U_1 x_2 ... x_P U_P,  U_i: [dim_i, R_i].
    """

    method = "tucker"

    def __init__(self, out_modes: Sequence[int], in_modes: Sequence[int], ranks: Sequence[int],
                 bias: Optional[torch.Tensor] = None, forward_mode: str = "dense"):
        assert len(ranks) == len(out_modes) + len(in_modes)
        super().__init__(math.prod(in_modes), math.prod(out_modes), bias, forward_mode)
        self.out_modes, self.in_modes, self.ranks = list(out_modes), list(in_modes), list(ranks)
        dims = self.out_modes + self.in_modes
        self.core = nn.Parameter(torch.randn(*ranks) * 0.02)
        self.factors = nn.ParameterList([nn.Parameter(torch.randn(d, r) / math.sqrt(d)) for d, r in zip(dims, ranks)])
        self._build_einsum()

    def _build_einsum(self):
        p, q = len(self.out_modes), len(self.in_modes)
        letters = iter(string.ascii_letters.replace("z", ""))
        dim_l = [next(letters) for _ in range(p + q)]
        rank_l = [next(letters) for _ in range(p + q)]
        core = "".join(rank_l)
        facs = [dim_l[i] + rank_l[i] for i in range(p + q)]
        # dense weight: core, factors -> out dims + in dims
        self._eq_weight = f"{core},{','.join(facs)}->{''.join(dim_l)}"
        # factorized forward: x[z, in dims], in factors, core, out factors -> [z, out dims]
        x_sub = "z" + "".join(dim_l[p:])
        self._eq_fwd = f"{x_sub},{','.join(facs[p:])},{core},{','.join(facs[:p])}->z{''.join(dim_l[:p])}"

    @staticmethod
    def params_for_ranks(dims, ranks) -> int:
        return math.prod(ranks) + sum(d * r for d, r in zip(dims, ranks))

    @staticmethod
    def ranks_for_ratio(dims: Sequence[int], ratio: float, fixed: Optional[Sequence[Optional[int]]] = None) -> List[int]:
        """Scale every mode's rank by the same fraction alpha (bisection) until the parameter budget is met.
        `fixed[i]` (if not None) pins mode i's rank (e.g. keep all heads)."""
        fixed = list(fixed) if fixed else [None] * len(dims)
        budget = ratio * math.prod(dims)

        def ranks_at(alpha):
            rs = [f if f is not None else max(1, min(d, round(alpha * d))) for d, f in zip(dims, fixed)]
            # Tucker rank i cannot exceed the product of the other ranks
            for i in range(len(rs)):
                rs[i] = min(rs[i], math.prod(rs[:i] + rs[i + 1:]))
            return rs

        lo, hi = 0.0, 1.0
        for _ in range(60):
            mid = (lo + hi) / 2
            if TuckerLinear.params_for_ranks(dims, ranks_at(mid)) <= budget:
                lo = mid
            else:
                hi = mid
        return ranks_at(lo)

    @classmethod
    def from_weight(cls, weight: torch.Tensor, bias: Optional[torch.Tensor], out_modes: Sequence[int],
                    in_modes: Sequence[int], ranks: Optional[Sequence[int]] = None, ratio: Optional[float] = None,
                    fixed_ranks: Optional[Sequence[Optional[int]]] = None, n_iter: int = 10,
                    forward_mode: str = "dense"):
        dims = list(out_modes) + list(in_modes)
        if ranks is None:
            assert ratio is not None, "TuckerLinear needs `ranks` or `ratio`"
            ranks = cls.ranks_for_ratio(dims, ratio, fixed_ranks)
        w = weight.detach().double()
        core, factors = tucker_hooi(w.reshape(*dims), ranks, n_iter=n_iter)
        ranks = list(core.shape)
        mod = cls(out_modes, in_modes, ranks, bias, forward_mode).to(weight.dtype)
        with torch.no_grad():
            mod.core.copy_(core.to(weight.dtype))
            for p, u in zip(mod.factors, factors):
                p.copy_(u.to(weight.dtype))
            mod.init_rel_error = relative_error(w, mod.weight_from_factors().double())
        return mod

    def weight_from_factors(self) -> torch.Tensor:
        w = torch.einsum(self._eq_weight, self.core, *self.factors)
        return w.reshape(self.out_features, self.in_features)

    def _factorized_forward(self, x: torch.Tensor) -> torch.Tensor:
        p = len(self.out_modes)
        xs = x.reshape(x.shape[0], *self.in_modes)
        f = [u.to(x.dtype) for u in self.factors]
        # torch picks the contraction order (via opt_einsum when installed)
        y = torch.einsum(self._eq_fwd, xs, *f[p:], self.core.to(x.dtype), *f[:p])
        return y.reshape(x.shape[0], self.out_features)

    def macs_per_token(self) -> int:
        # sequential: project each input mode, contract core, expand each output mode
        p = len(self.out_modes)
        dims, rs = self.out_modes + self.in_modes, self.ranks
        cur = list(self.in_modes)
        macs = 0
        for i in range(len(self.in_modes)):  # in-mode projections
            macs += math.prod(cur) * rs[p + i]
            cur[i] = rs[p + i]
        macs += math.prod(rs)  # core contraction (in-ranks -> out-ranks)
        cur = list(rs[:p])
        for i in range(p):
            macs += math.prod(cur) * dims[i]
            cur[i] = dims[i]
        return macs

    def spec(self) -> dict:
        return {"method": "tucker", "out_modes": self.out_modes, "in_modes": self.in_modes, "ranks": self.ranks,
                "bias": self.bias is not None}


# --------------------------------------------------------------------------------------------------------------
# Truncated SVD
# --------------------------------------------------------------------------------------------------------------


class LowRankLinear(FactorizedLinear):
    method = "svd"

    def __init__(self, in_features: int, out_features: int, rank: int, bias: Optional[torch.Tensor] = None,
                 forward_mode: str = "factorized"):
        super().__init__(in_features, out_features, bias, forward_mode)
        self.rank = rank
        self.u = nn.Parameter(torch.randn(out_features, rank) / math.sqrt(rank))
        self.v = nn.Parameter(torch.randn(rank, in_features) / math.sqrt(in_features))

    @classmethod
    def from_weight(cls, weight, bias, rank: Optional[int] = None, ratio: Optional[float] = None,
                    forward_mode: str = "factorized"):
        out_f, in_f = weight.shape
        if rank is None:
            rank = max(1, int(ratio * in_f * out_f / (in_f + out_f)))
        rank = min(rank, in_f, out_f)
        w = weight.detach().double()
        u, s, vh = torch.linalg.svd(w, full_matrices=False)
        sq = s[:rank].sqrt()
        mod = cls(in_f, out_f, rank, bias, forward_mode).to(weight.dtype)
        with torch.no_grad():
            mod.u.copy_((u[:, :rank] * sq).to(weight.dtype))
            mod.v.copy_((sq[:, None] * vh[:rank]).to(weight.dtype))
            mod.init_rel_error = relative_error(w, mod.weight_from_factors().double())
        return mod

    def weight_from_factors(self):
        return self.u @ self.v

    def _factorized_forward(self, x):
        return (x @ self.v.to(x.dtype).T) @ self.u.to(x.dtype).T

    def macs_per_token(self):
        return self.rank * (self.in_features + self.out_features)

    def spec(self):
        return {"method": "svd", "in_features": self.in_features, "out_features": self.out_features,
                "rank": self.rank, "bias": self.bias is not None}


# --------------------------------------------------------------------------------------------------------------
# Conv wrappers
# --------------------------------------------------------------------------------------------------------------


class PointwiseConv1d(nn.Module):
    """Drop-in replacement for nn.Conv1d(kernel_size=1, groups=1) operating on [B, C, T]."""

    def __init__(self, linear: nn.Module):
        super().__init__()
        self.linear = linear
        self.in_channels = getattr(linear, "in_features", None)
        self.out_channels = getattr(linear, "out_features", None)

    def forward(self, x):
        return self.linear(x.transpose(1, 2)).transpose(1, 2)


class Tucker2Conv2d(nn.Module):
    """Conv2d(C_in -> C_out, k x k) ~= 1x1(C_in -> R_in) -> kxk(R_in -> R_out) -> 1x1(R_out -> C_out)."""

    method = "tucker2"

    def __init__(self, conv: nn.Conv2d, r_in: int, r_out: int):
        super().__init__()
        assert conv.groups == 1, "Tucker-2 only for groups=1 convolutions"
        self.in_channels, self.out_channels = conv.in_channels, conv.out_channels
        self.r_in, self.r_out = r_in, r_out
        self.kernel_size, self.stride, self.padding, self.dilation = conv.kernel_size, conv.stride, conv.padding, conv.dilation
        self.first = nn.Conv2d(conv.in_channels, r_in, 1, bias=False)
        self.core = nn.Conv2d(r_in, r_out, conv.kernel_size, stride=conv.stride, padding=conv.padding,
                              dilation=conv.dilation, bias=False)
        self.last = nn.Conv2d(r_out, conv.out_channels, 1, bias=conv.bias is not None)
        self.init_rel_error: Optional[float] = None

    @classmethod
    def from_conv(cls, conv: nn.Conv2d, ranks: Optional[Tuple[int, int]] = None, ratio: Optional[float] = None,
                  n_iter: int = 10):
        w = conv.weight.detach().double()  # [C_out, C_in, kh, kw]
        c_out, c_in, kh, kw = w.shape
        if ranks is None:
            budget = ratio * w.numel()
            alpha_lo, alpha_hi = 0.0, 1.0
            for _ in range(50):
                a = (alpha_lo + alpha_hi) / 2
                ro, ri = max(1, round(a * c_out)), max(1, round(a * c_in))
                if ri * c_in + ro * ri * kh * kw + ro * c_out <= budget:
                    alpha_lo = a
                else:
                    alpha_hi = a
            ranks = (max(1, round(alpha_lo * c_out)), max(1, round(alpha_lo * c_in)))
        r_out, r_in = ranks
        u_out = _leading_left_singular(unfold(w, 0), r_out)
        u_in = _leading_left_singular(unfold(w, 1), r_in)
        for _ in range(n_iter):  # HOOI on the two channel modes only
            u_out = _leading_left_singular(unfold(mode_product(w, u_in.T, 1), 0), r_out)
            u_in = _leading_left_singular(unfold(mode_product(w, u_out.T, 0), 1), r_in)
        core = mode_product(mode_product(w, u_out.T, 0), u_in.T, 1)  # [R_out, R_in, kh, kw]
        mod = cls(conv, r_in=r_in, r_out=r_out).to(conv.weight.dtype)
        with torch.no_grad():
            mod.first.weight.copy_(u_in.T.reshape(r_in, c_in, 1, 1).to(conv.weight.dtype))
            mod.core.weight.copy_(core.to(conv.weight.dtype))
            mod.last.weight.copy_(u_out.reshape(c_out, r_out, 1, 1).to(conv.weight.dtype))
            if conv.bias is not None:
                mod.last.bias.copy_(conv.bias.detach())
            w_hat = mode_product(mode_product(core, u_out, 0), u_in, 1)
            mod.init_rel_error = relative_error(w, w_hat)
        return mod

    @property
    def weight(self):  # dense-equivalent kernel (for inspection only)
        w = torch.einsum("oa,abhw,bi->oihw", self.last.weight[:, :, 0, 0], self.core.weight, self.first.weight[:, :, 0, 0])
        return w

    def forward(self, x):
        return self.last(self.core(self.first(x)))

    def num_factor_params(self):
        return self.first.weight.numel() + self.core.weight.numel() + self.last.weight.numel()

    def dense_params(self):
        return self.in_channels * self.out_channels * self.kernel_size[0] * self.kernel_size[1]

    def spec(self):
        return {"method": "tucker2", "r_in": self.r_in, "r_out": self.r_out}


def build_empty_from_spec(spec: dict, ref: nn.Module, forward_mode: str = "dense") -> nn.Module:
    """Rebuild a factorized module with the right shapes (values come from a state_dict afterwards)."""
    m = spec["method"]
    is_conv1d = isinstance(ref, nn.Conv1d)
    bias = None
    if getattr(ref, "bias", None) is not None:
        bias = torch.zeros_like(ref.bias)
    if m == "tt":
        lin = TTLinear(spec["in_modes"], spec["out_modes"], spec["ranks"], bias, forward_mode)
    elif m == "tucker":
        lin = TuckerLinear(spec["out_modes"], spec["in_modes"], spec["ranks"], bias, forward_mode)
    elif m == "svd":
        lin = LowRankLinear(spec["in_features"], spec["out_features"], spec["rank"], bias, forward_mode)
    elif m == "tucker2":
        return Tucker2Conv2d(ref, r_in=spec["r_in"], r_out=spec["r_out"])
    else:
        raise ValueError(m)
    return PointwiseConv1d(lin) if is_conv1d else lin
