"""Parameter / storage / compute accounting and measured latency."""
from __future__ import annotations

import time
from typing import Dict

import torch
import torch.nn as nn

from .adapters import ParallelNoiseAdapter
from .decompose import set_forward_mode
from .tensor_layers import FactorizedLinear, Tucker2Conv2d


def param_counts(model: nn.Module) -> Dict[str, int]:
    out = {"total": 0, "encoder": 0, "decoder": 0, "other": 0, "adapters": 0, "trainable": 0}
    for n, p in model.named_parameters():
        k = p.numel()
        out["total"] += k
        out["trainable"] += k if p.requires_grad else 0
        if ".noise_adapter" in n:
            out["adapters"] += k
        top = n.split(".")[0]
        if top == "encoder":
            out["encoder"] += k
        elif top in ("decoder", "embedding", "classifier"):
            out["decoder"] += k
        else:
            out["other"] += k
    out["storage_mb_fp32"] = out["total"] * 4 / 2 ** 20
    out["storage_mb_fp16"] = out["total"] * 2 / 2 ** 20
    out["storage_mb_int8_est"] = out["total"] / 2 ** 20
    return out


def encoder_linear_macs_per_frame(model: nn.Module) -> Dict[str, float]:
    """MACs per encoder frame (40 ms after 4x subsampling) for all linear-like layers of the Conformer blocks.
    Attention score/softmax and depthwise conv MACs are identical for every system and are excluded."""
    dense = fact = adapters = 0
    for name, m in model.named_modules():
        if not name.startswith("encoder.layers"):
            continue
        if ".noise_adapter" in name:  # counted via adapter_macs_per_token below
            continue
        if isinstance(m, FactorizedLinear):
            dense_eq = m.in_features * m.out_features
            dense += dense_eq
            fact += min(dense_eq, m.macs_per_token())  # executor picks the cheaper path
        elif isinstance(m, nn.Linear):
            dense += m.in_features * m.out_features
            fact += m.in_features * m.out_features
        elif isinstance(m, nn.Conv1d) and m.kernel_size == (1,) and m.groups == 1:
            dense += m.in_channels * m.out_channels
            fact += m.in_channels * m.out_channels
        if isinstance(m, ParallelNoiseAdapter):
            adapters += m.adapter_macs_per_token()
    return {"dense_equiv_macs_per_frame": dense, "macs_per_frame": fact + adapters, "adapter_macs_per_frame": adapters}


@torch.no_grad()
def measure_latency(model: nn.Module, device: str, seconds: float = 5.0, batch: int = 1, repeats: int = 10,
                    mode: str = "dense") -> Dict[str, float]:
    """Encoder-only real-time factor on synthetic audio (decoder cost is identical across systems)."""
    model.eval()
    set_forward_mode(model, mode)
    sr = 16000
    wav = torch.randn(batch, int(seconds * sr), device=device) * 0.05
    lens = torch.full((batch,), wav.shape[1], device=device, dtype=torch.long)
    feats, flen = model.preprocessor(input_signal=wav, length=lens)

    def run():
        model.encoder(audio_signal=feats, length=flen)

    for _ in range(3):
        run()
    if device.startswith("cuda"):
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(repeats):
        run()
    if device.startswith("cuda"):
        torch.cuda.synchronize()
    dt = (time.perf_counter() - t0) / repeats
    set_forward_mode(model, "dense")
    return {"mode": mode, "encoder_seconds_per_call": dt, "rtf": dt / (seconds * batch)}


def efficiency_report(model: nn.Module, device: str, measure: bool = True) -> dict:
    rep = {"params": param_counts(model), "macs": encoder_linear_macs_per_frame(model)}
    n_fact = sum(1 for m in model.modules() if isinstance(m, (FactorizedLinear, Tucker2Conv2d)))
    rep["n_factorized_modules"] = n_fact
    if measure:
        rep["latency"] = [measure_latency(model, device, mode="dense")]
        if n_fact:
            rep["latency"].append(measure_latency(model, device, mode="factorized"))
    return rep
