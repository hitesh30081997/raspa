"""Surgery on a real NeMo SLUIntentSlotBPEModel (tiny fixture from tests/make_tiny_fixture.py).
   RTC_FIXTURE=/tmp/rtc_fixture python -m pytest tests/test_surgery.py"""
import os
import sys

import pytest
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
FIX = os.environ.get("RTC_FIXTURE", "/tmp/rtc_fixture")
pytestmark = pytest.mark.skipif(not os.path.exists(os.path.join(FIX, "tiny_slu.nemo")), reason="no fixture")

from rtc.decompose import (GROUP_PATTERNS, apply_adapters, decompose_model, restore_surgery, set_forward_mode,  # noqa
                           set_trainable, surgery_state)
from rtc.tensor_layers import FactorizedLinear, Tucker2Conv2d  # noqa


def _load():
    from nemo.collections.asr.models import SLUIntentSlotBPEModel
    return SLUIntentSlotBPEModel.restore_from(os.path.join(FIX, "tiny_slu.nemo"), map_location="cpu").eval()


@pytest.fixture(scope="module")
def base():
    return _load().double()


def _enc(m, feats, lens):
    return m.encoder(audio_signal=feats, length=lens)[0]


def _inputs(m):
    torch.manual_seed(0)
    wav = torch.randn(2, 16000, dtype=torch.float64) * 0.1
    lens = torch.tensor([16000, 12000])
    with torch.no_grad():
        return m.preprocessor(input_signal=wav.float(), length=lens)


FULL = {"groups": {
    "ffn": {"method": "tt", "rank": 100000, "num_cores": 2},
    "attn_qkv": {"method": "tucker", "rank": None, "ratio": 10.0, "layout": "heads"},
    "attn_out": {"method": "tucker", "ratio": 10.0, "layout": "heads"},
    "attn_pos": {"method": "svd", "rank": 100000},
    "conv_pw": {"method": "tt", "rank": 100000, "num_cores": 2},
    "subsampling_conv": {"method": "tucker", "ratio": 10.0},
    "subsampling_out": {"method": "tt", "rank": 100000, "num_cores": 2}}}


def test_patterns_hit_expected_modules(base):
    import re
    names = [n for n, _ in base.named_modules()]
    L = len(base.encoder.layers)
    expect = {"ffn": 4 * L, "attn_qkv": 3 * L, "attn_out": L, "attn_pos": L, "conv_pw": 2 * L, "subsampling_out": 1}
    for g, n_exp in expect.items():
        assert sum(bool(re.search(GROUP_PATTERNS[g], n)) for n in names) == n_exp, g


@pytest.mark.parametrize("mode", ["dense", "factorized"])
def test_full_rank_decomposition_is_lossless(base, mode):
    m = _load().double()
    feats, flen = _inputs(m)
    feats = feats.double()
    with torch.no_grad():
        ref = _enc(m, feats, flen)
    rep = decompose_model(m, {**FULL, "forward_mode": mode}, log=lambda *_: None)
    assert any(r["group"] == "subsampling_conv" for r in rep)
    assert all(r["rel_error"] < 1e-8 for r in rep), max(r["rel_error"] for r in rep)
    m.double().eval()
    with torch.no_grad():
        out = _enc(m, feats, flen)
    assert torch.allclose(out, ref, atol=1e-6), (out - ref).abs().max()


def test_adapters_identity_trainability_and_checkpoint(base):
    m = _load().float()
    feats, flen = _inputs(m)
    with torch.no_grad():
        ref = _enc(m, feats, flen)
    comp = {"groups": {"ffn": {"method": "tt", "ratio": 0.3, "num_cores": 2},
                       "attn_qkv": {"method": "tucker", "ratio": 0.3, "layout": "heads"},
                       "conv_pw": {"method": "svd", "ratio": 0.3}}}
    decompose_model(m, comp, log=lambda *_: None)
    m.eval()
    with torch.no_grad():
        compressed = _enc(m, feats, flen)
    acfg = {"targets": ["ffn", "attn_qkv", "attn_out", "conv_pw"], "rank": 4}
    rep = apply_adapters(m, acfg, log=lambda *_: None)
    L = len(m.encoder.layers)
    assert len(rep) == L * (4 + 3 + 1 + 2)
    with torch.no_grad():
        assert torch.allclose(_enc(m, feats, flen), compressed, atol=1e-6)  # zero-init up-projection
    assert not torch.allclose(compressed, ref, atol=1e-3)  # compression did change the function

    s = set_trainable(m, "adapters", log=lambda *_: None)
    names = [n for n, p in m.named_parameters() if p.requires_grad]
    assert names and all(".noise_adapter" in n for n in names)
    assert s["trainable"] == sum(r["params"] for r in rep)
    set_trainable(m, "factors+norms", log=lambda *_: None)
    tr = [n for n, p in m.named_parameters() if p.requires_grad]
    assert not any(".noise_adapter" in n for n in tr) and any("cores" in n for n in tr)

    # an adapter update changes the output; gradients reach adapters only
    set_trainable(m, "adapters", log=lambda *_: None)
    m.train()
    out = _enc(m, feats, flen)
    out.pow(2).mean().backward()
    assert all(p.grad is not None for n, p in m.named_parameters() if p.requires_grad)
    assert all(p.grad is None for n, p in m.named_parameters() if not p.requires_grad)

    # checkpoint round trip into a fresh copy of the base model
    with torch.no_grad():
        for n, p in m.named_parameters():
            if n.endswith("noise_adapter.3.weight"):
                p.normal_(0, 0.01)
    m.eval()
    with torch.no_grad():
        target = _enc(m, feats, flen)
    st = surgery_state(m, acfg)
    fresh = _load().float()
    restore_surgery(fresh, st, log=lambda *_: None)
    fresh.load_state_dict(m.state_dict(), strict=True)
    fresh.eval()
    with torch.no_grad():
        assert torch.allclose(_enc(fresh, feats, flen), target, atol=1e-6)
    set_forward_mode(fresh, "factorized")
    with torch.no_grad():
        assert torch.allclose(_enc(fresh, feats, flen), target, atol=1e-4)
