"""
Builds a tiny but architecturally identical NeMo SLU model (Conformer + Transformer decoder, same classes as
slu_conformer_transformer_large_slurp) plus synthetic SLURP-style manifests, so the whole pipeline can be
smoke-tested on CPU without the 127M checkpoint or the real data.

  python tests/make_tiny_fixture.py /tmp/rtc_fixture
"""
import json
import os
import random
import sys

import numpy as np
import soundfile as sf


def main(root):
    os.makedirs(root, exist_ok=True)
    rng = random.Random(0)
    scen = {"alarm": ["set", "query"], "music": ["play"], "weather": ["query"]}
    fills = {"time": ["five am", "seven pm", "noon"], "music_genre": ["jazz", "rock"], "place_name": ["paris", "london"]}
    sems = []
    for _ in range(400):
        s = rng.choice(list(scen))
        a = rng.choice(scen[s])
        ents = [{"type": t, "filler": rng.choice(fills[t])} for t in rng.sample(list(fills), rng.randint(0, 2))]
        sems.append({"scenario": s, "action": a, "entities": ents})

    # tokenizer (SentencePiece unigram with bos/eos/pad, as in NeMo's SLURP recipe)
    import sentencepiece as spm
    tok_dir = os.path.join(root, "tokenizer")
    os.makedirs(tok_dir, exist_ok=True)
    txt = os.path.join(tok_dir, "text.txt")
    with open(txt, "w") as f:
        for s in sems:
            f.write(str(s) + "\n")
    spm.SentencePieceTrainer.train(input=txt, model_prefix=os.path.join(tok_dir, "tokenizer"), vocab_size=58,
                                   model_type="unigram", character_coverage=1.0, bos_id=1, eos_id=2, pad_id=3,
                                   unk_id=0, hard_vocab_limit=False)
    sp = spm.SentencePieceProcessor(model_file=os.path.join(tok_dir, "tokenizer.model"))
    with open(os.path.join(tok_dir, "vocab.txt"), "w") as f:
        for i in range(sp.get_piece_size()):
            f.write(sp.id_to_piece(i) + "\n")

    # synthetic audio: the intent is encoded in the pitch so the tiny model can learn something
    wav_dir = os.path.join(root, "wavs")
    os.makedirs(wav_dir, exist_ok=True)
    keys = sorted({(s["scenario"], s["action"]) for s in sems})

    def make(split, idx_range, snr=None, noisy_tag=""):
        out = []
        for i in idx_range:
            sem = sems[i]
            f0 = 200 + 120 * keys.index((sem["scenario"], sem["action"]))
            dur = 1.0 + 0.3 * len(sem["entities"])
            t = np.arange(int(16000 * dur)) / 16000
            x = 0.3 * np.sin(2 * np.pi * f0 * t)
            if snr is not None:
                n = np.random.default_rng(i).standard_normal(len(x))
                x = x + n * np.sqrt(np.mean(x ** 2) / (10 ** (snr / 10)) / np.mean(n ** 2))
            mic = "-headset" if i % 2 else ""
            name = f"audio-{1000 + i}{mic}{noisy_tag}.wav"
            path = os.path.join(wav_dir, name)
            sf.write(path, x.astype(np.float32), 16000)
            it = {"audio_filepath": os.path.relpath(path, root), "duration": dur, "text": str(sem),
                  "slurp_id": str(i)}
            if snr is not None:
                it.update(snr=snr, noise_type="white")
            out.append(it)
        with open(os.path.join(root, f"{split}.json"), "w") as f:
            for it in out:
                f.write(json.dumps(it) + "\n")

    make("train_slu", range(0, 300))
    make("train_synthetic_slu", range(0, 0))
    make("devel_slu", range(300, 340))
    make("test_slu", range(340, 400))
    make("train_noisy_slu", range(0, 300), snr=5, noisy_tag="_snr5")
    make("devel_noisy_slu", range(300, 340), snr=5, noisy_tag="_snr5")
    for snr in (20, 10, 5, 0):
        make(f"test_snr{snr}_slu", range(340, 400), snr=snr, noisy_tag=f"_snr{snr}")

    # tiny model with the SAME classes as the NGC checkpoint
    from omegaconf import OmegaConf
    from nemo.collections.asr.models import SLUIntentSlotBPEModel
    cfg_path = sys.argv[2] if len(sys.argv) > 2 else None
    cfg = OmegaConf.load(cfg_path)
    m = cfg.model
    m.train_ds.manifest_filepath = os.path.join(root, "train_slu.json")
    m.validation_ds.manifest_filepath = os.path.join(root, "devel_slu.json")
    m.tokenizer.dir = tok_dir
    m.encoder.n_layers, m.encoder.d_model, m.encoder.n_heads = 2, 64, 4
    m.decoder.num_layers, m.decoder.inner_size, m.decoder.num_attention_heads = 1, 128, 4
    m.sequence_generator.max_sequence_length = 128
    m.embedding.max_sequence_length = 128
    model = SLUIntentSlotBPEModel(cfg=m)
    model.save_to(os.path.join(root, "tiny_slu.nemo"))
    print("fixture ready:", root)


if __name__ == "__main__":
    main(sys.argv[1])
