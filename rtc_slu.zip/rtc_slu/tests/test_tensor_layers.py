import math
import os
import sys

import pytest
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rtc.tensor_layers import (LowRankLinear, PointwiseConv1d, TTLinear, Tucker2Conv2d, TuckerLinear,  # noqa
                               build_empty_from_spec, factorize_dim)

torch.manual_seed(0)


def _low_tt_rank_weight(out_f, in_f):
    # a weight that is exactly representable at modest TT rank, to check exact recovery
    lin = TTLinear(factorize_dim(in_f, 3), factorize_dim(out_f, 3), [1, 4, 4, 1])
    return lin.weight_from_factors().detach()


def test_factorize_dim():
    assert math.prod(factorize_dim(2048, 3)) == 2048
    assert factorize_dim(512, 3) == [8, 8, 8]
    assert math.prod(factorize_dim(10240, 3)) == 10240


@pytest.mark.parametrize("out_f,in_f", [(2048, 512), (512, 2048), (1024, 512), (512, 10240)])
def test_tt_full_rank_is_exact_and_modes_agree(out_f, in_f):
    w = torch.randn(out_f, in_f, dtype=torch.float64)
    b = torch.randn(out_f, dtype=torch.float64)
    lin = TTLinear.from_weight(w, b, num_cores=3, rank=4096)
    assert lin.init_rel_error < 1e-10
    x = torch.randn(7, 5, in_f, dtype=torch.float64)
    ref = x @ w.T + b
    lin.forward_mode = "dense"
    assert torch.allclose(lin(x), ref, atol=1e-8)
    lin.forward_mode = "factorized"
    assert torch.allclose(lin(x), ref, atol=1e-8)


def test_tt_exact_recovery_low_rank_and_ratio():
    w = _low_tt_rank_weight(2048, 512)
    lin = TTLinear.from_weight(w, None, num_cores=3, rank=4)
    assert lin.init_rel_error < 1e-5
    lin2 = TTLinear.from_weight(torch.randn(2048, 512), None, num_cores=3, ratio=0.1)
    assert lin2.num_factor_params() <= 0.1 * 2048 * 512
    # NOTE: TT saves parameters, but sequential TT contraction can cost MORE MACs than the dense GEMM at
    # moderate ranks (here ~6x). Report FLOPs honestly (rtc.efficiency picks min(dense, factorized)).
    assert lin2.macs_per_token() > 0
    lin_small = TTLinear.from_weight(torch.randn(2048, 512), None, num_cores=3, rank=4)
    assert lin_small.macs_per_token() < 2048 * 512


@pytest.mark.parametrize("layout", ["qkv", "out", "ffn"])
def test_tucker_modes_agree(layout):
    if layout == "qkv":
        w, om, im = torch.randn(512, 512, dtype=torch.float64), [8, 64], [512]
    elif layout == "out":
        w, om, im = torch.randn(512, 512, dtype=torch.float64), [512], [8, 64]
    else:
        w, om, im = torch.randn(2048, 512, dtype=torch.float64), [32, 64], [16, 32]
    full = TuckerLinear.from_weight(w, None, om, im, ranks=list(om) + list(im), n_iter=1)
    assert full.init_rel_error < 1e-8
    t = TuckerLinear.from_weight(w, torch.zeros(w.shape[0], dtype=torch.float64), om, im, ratio=0.3, n_iter=3)
    assert t.num_factor_params() <= 0.3 * w.numel() + 1
    x = torch.randn(3, w.shape[1], dtype=torch.float64)
    t.forward_mode = "dense"
    a = t(x)
    t.forward_mode = "factorized"
    assert torch.allclose(a, t(x), atol=1e-8)


def test_tucker_hooi_beats_or_equals_hosvd():
    w = torch.randn(512, 512, dtype=torch.float64)
    a = TuckerLinear.from_weight(w, None, [8, 64], [512], ratio=0.3, n_iter=0)
    b = TuckerLinear.from_weight(w, None, [8, 64], [512], ratio=0.3, n_iter=10)
    assert b.init_rel_error <= a.init_rel_error + 1e-9


def test_svd_optimal_error():
    w = torch.randn(256, 128, dtype=torch.float64)
    lr = LowRankLinear.from_weight(w, None, rank=16)
    s = torch.linalg.svdvals(w)
    expected = float(s[16:].pow(2).sum().sqrt() / s.pow(2).sum().sqrt())
    assert abs(lr.init_rel_error - expected) < 1e-9  # Eckart-Young


def test_tucker2_conv_full_rank_exact():
    conv = nn.Conv2d(32, 48, 3, stride=2, padding=1).double()
    t2 = Tucker2Conv2d.from_conv(conv, ranks=(48, 32))
    x = torch.randn(2, 32, 20, 16, dtype=torch.float64)
    assert torch.allclose(t2(x), conv(x), atol=1e-8)
    assert t2.stride == conv.stride and t2.padding == conv.padding  # read by NeMo's MaskedConvSequential
    small = Tucker2Conv2d.from_conv(conv, ratio=0.3)
    assert small.num_factor_params() <= 0.3 * conv.weight.numel() + 1


def test_pointwise_conv_and_spec_rebuild():
    conv = nn.Conv1d(64, 128, 1).double()
    lin = TTLinear.from_weight(conv.weight[:, :, 0], conv.bias, num_cores=2, rank=1000)
    pw = PointwiseConv1d(lin)
    x = torch.randn(2, 64, 9, dtype=torch.float64)
    assert torch.allclose(pw(x), conv(x), atol=1e-8)
    empty = build_empty_from_spec(lin.spec(), conv).double()
    empty.load_state_dict(pw.state_dict())
    assert torch.allclose(empty(x), conv(x), atol=1e-8)


def test_gradients_flow():
    lin = TTLinear.from_weight(torch.randn(64, 32), torch.zeros(64), num_cores=2, rank=4, forward_mode="factorized")
    lin(torch.randn(4, 32)).pow(2).sum().backward()
    assert all(c.grad is not None and c.grad.abs().sum() > 0 for c in lin.cores)
