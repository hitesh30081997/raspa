#!/usr/bin/env bash
# End-to-end CPU smoke test of every experiment config on the tiny fixture (a few minutes).
set -euo pipefail
cd "$(dirname "$0")/../.."
FIX=${RTC_FIXTURE:-/tmp/rtc_fixture}
NEMO_CFG=${NEMO_SLU_CFG:?set NEMO_SLU_CFG to NeMo examples/slu/speech_intent_slot/configs/conformer_transformer_large_bpe.yaml}
[ -f "$FIX/tiny_slu.nemo" ] || python tests/make_tiny_fixture.py "$FIX" "$NEMO_CFG"

# 1) train the tiny model on clean data -> it plays the role of the pretrained SLURP model
[ -f /tmp/rtc_exp/tiny_pretrain/checkpoints/final.pt ] || python scripts/run_experiment.py --no_latency --config tests/smoke/tiny_pretrain.yaml tests/smoke/smoke.yaml
python scripts/export_nemo.py --base_nemo "$FIX/tiny_slu.nemo" --ckpt /tmp/rtc_exp/tiny_pretrain/checkpoints/final.pt \
       --out "$FIX/tiny_pretrained.nemo"

# 2) every experiment, with stages shortened to 1 epoch
run() {
  python tests/smoke/shorten.py "configs/experiments/$1.yaml" > "/tmp/rtc_short_$1.yaml"
  python scripts/run_experiment.py --config "/tmp/rtc_short_$1.yaml" tests/smoke/smoke.yaml \
         pretrained.nemo_path="$FIX/tiny_pretrained.nemo" "${@:2}"
}
run B0_pretrained
run C0_tt_raw
run C1_tt_heal
run RTC_tt  init_checkpoint=/tmp/rtc_exp/C1_tt_heal/checkpoints/final.pt
run C2_tt_heal_fullft_noisy init_checkpoint=/tmp/rtc_exp/C1_tt_heal/checkpoints/final.pt
run RTC_tt_noheal
run B2_adapters_uncompressed
run RTC_svd
run RTC_tucker
python scripts/run_experiment.py --eval_only --config /tmp/rtc_short_RTC_tt.yaml tests/smoke/smoke.yaml \
       pretrained.nemo_path="$FIX/tiny_pretrained.nemo"
python scripts/compare_systems.py --exp_root /tmp/rtc_exp --reference B0_pretrained --proposed RTC_tt \
       --out /tmp/rtc_exp/_comparison --pareto_condition snr_0
echo "SMOKE OK"
