"""Print an experiment yaml with every stage cut to a short run (smoke tests only)."""
import sys

from omegaconf import OmegaConf

cfg = OmegaConf.load(sys.argv[1])
for st in cfg.get("stages") or []:
    st.epochs = 3
    st.eval_every_steps = 19
    st.log_every = 19
    st.warmup_steps = 5
    if "lr" in st and st.lr < 1e-3:
        st.lr = 1e-3
print(OmegaConf.to_yaml(cfg))
