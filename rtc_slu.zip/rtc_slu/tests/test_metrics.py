"""Equivalence of rtc.slurp_metrics with the official SLURP evaluation code.

Requires the official repo (git clone https://github.com/pswietojanski/slurp) and `pip install jiwer textdistance`.
Set SLURP_EVAL_DIR=/path/to/slurp/scripts/evaluation; the test is skipped otherwise.
"""
import importlib
import os
import random
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rtc import slurp_metrics as M  # noqa

EVAL_DIR = os.environ.get("SLURP_EVAL_DIR", "/home/claude/ref/slurp/scripts/evaluation")


def _official():
    if not os.path.isdir(EVAL_DIR):
        pytest.skip("official SLURP evaluation code not found")
    sys.path.insert(0, EVAL_DIR)
    import jiwer
    dist = importlib.import_module("metrics.distance")
    # newer jiwer renamed `truth` -> `reference`; patch so the official code runs unchanged otherwise
    dist.WordDistance.__call__ = lambda self, truth, hypothesis: jiwer.wer(truth, hypothesis)
    return importlib.import_module("metrics.metrics").ErrorMetric


WORDS = "the a five am pm alarm wake me up tomorrow jazz play music rock seven thirty".split()
TYPES = ["time", "date", "music_genre", "event_name", "place_name"]
SCEN = ["alarm", "music", "calendar"]
ACTS = ["set", "query", "remove"]


def rand_ents(rng, base=None):
    if base is not None and rng.random() < 0.6:  # perturb gold to create near misses
        out = []
        for e in base:
            r = rng.random()
            if r < 0.5:
                out.append(dict(e))
            elif r < 0.7:
                w = e["filler"].split()
                w[rng.randrange(len(w))] = rng.choice(WORDS)
                out.append({"type": e["type"], "filler": " ".join(w)})
            elif r < 0.85:
                out.append({"type": rng.choice(TYPES), "filler": e["filler"]})
        if rng.random() < 0.3:
            out.append({"type": rng.choice(TYPES), "filler": " ".join(rng.sample(WORDS, rng.randint(1, 3)))})
        return out
    return [{"type": rng.choice(TYPES), "filler": " ".join(rng.choices(WORDS, k=rng.randint(1, 4)))}
            for _ in range(rng.randint(0, 3))]


@pytest.mark.parametrize("average", ["micro", "macro"])
def test_matches_official(average):
    EM = _official()
    rng = random.Random(1)
    off = {k: EM.get_instance(metric=m, average=average, **kw) for k, m, kw in [
        ("scenario", "f1", {}), ("action", "f1", {}), ("intent", "f1", {}), ("span", "span_f1", {}),
        ("word", "span_distance_f1", {"distance": "word"}), ("char", "span_distance_f1", {"distance": "char"})]}
    slu = EM.get_instance(metric="slu_f1", average=average)
    mine = []
    for i in range(3000):
        g = {"scenario": rng.choice(SCEN), "action": rng.choice(ACTS), "entities": rand_ents(rng)}
        p = {"scenario": g["scenario"] if rng.random() < .8 else rng.choice(SCEN),
             "action": g["action"] if rng.random() < .8 else rng.choice(ACTS),
             "entities": rand_ents(rng, g["entities"])}
        off["scenario"](g["scenario"], p["scenario"])
        off["action"](g["action"], p["action"])
        off["intent"](f"{g['scenario']}_{g['action']}", f"{p['scenario']}_{p['action']}")
        for k in ("span", "word", "char"):
            off[k](g["entities"], p["entities"])
        mine.append(M.score_utterance(str(i), str(g), str(p)))
    res = M.aggregate(mine, average)
    o = {k: v.get_metric() for k, v in off.items()}
    slu(o["word"])
    slu(o["char"])
    o["slu"] = slu.get_metric()
    if average == "micro":
        assert abs(res["intent_acc"] - 100 * o["intent"]["overall"][0]) < 1e-9
        assert abs(res["scenario_acc"] - 100 * o["scenario"]["overall"][0]) < 1e-9
        assert abs(res["action_acc"] - 100 * o["action"]["overall"][0]) < 1e-9
    else:
        assert abs(res["intent_macro_f1"] - 100 * o["intent"]["overall"][2]) < 1e-9
    for mine_k, off_k in (("span", "span"), ("word_dist", "word"), ("char_dist", "char"), ("slu", "slu")):
        for j, s in enumerate("prf"):
            key = f"{mine_k}_{'f1' if s == 'f' else s}"
            assert abs(res[key] - 100 * o[off_k]["overall"][j]) < 1e-9, (key, res[key], o[off_k]["overall"][j])


def test_parser_handles_garbage():
    d, bad = M.parse_semantics("{'scenario': 'alarm', 'action': 'set', 'entities': [{'type': 'time'")
    assert bad and d["scenario"] == "none"
    d, bad = M.parse_semantics("{'scenario': 'alarm', 'action': 'set', 'entities': [{'type': 'time', 'filler': 'five am'}]}")
    assert not bad and d["entities"] == [{"type": "time", "filler": "five am"}]


def test_taxonomy():
    g = [{"type": "time", "filler": "five am"}, {"type": "date", "filler": "tomorrow"}, {"type": "place_name", "filler": "x"}]
    p = [{"type": "time", "filler": "five pm"}, {"type": "event_name", "filler": "tomorrow"}, {"type": "date", "filler": "q"}]
    t = M.entity_error_taxonomy(g, p)
    assert t == {"filler_error": 2, "missed": 1, "spurious": 1}
