"""
model_seq_ec.py
Efficient Conformer student (burchim/EfficientConformer) with the SAME output head as the
NeMo teacher (slu_conformer_transformer_large_slurp). Drop-in replacement for the
WavLM/HuBERT student in model_seq.py: identical decoder, decoding (greedy / beam search),
N-best scoring and parameter-group helpers, so train_seq_kd.py trains it the same way.

Architecture
------------
  waveform -> Efficient Conformer encoder
                log-mel (10 ms) -> Conv2d subsampling (20 ms)
                -> stage 1 blocks (20 ms) -> stage 2 (40 ms) -> stage 3 (80 ms)
           -> block read-out: "single" block, or learned weighted sum over blocks
              (default: all blocks of the last stage; earlier-stage blocks are
               average-pooled to 80 ms and linearly projected to the last-stage width)
           -> adapter: Linear(D_enc -> 512) + LayerNorm (+ optional Transformer layers)
           -> [teacher-identical] TransformerEmbedding + TransformerDecoder + classifier

Encoder output is at 80 ms per frame (teacher: 40 ms). The decoder cross-attends to any
length, and the encoder-KD loss in train_seq_kd.py already interpolates the student
states onto the teacher's time axis, so no other change is needed.
"""
import copy

import torch
import torch.nn as nn
import torch.nn.functional as F

from efficient_conformer import build_encoder, load_encoder_params
from model import LayerWeightedSum
from model_seq import HubertSemanticSLU, _reset_parameters, length_mask


def _stage_layout(params):
    """Per block: (output dim, cumulative time stride after the block, relative to subsampling)."""
    n = params["num_blocks"]
    dims = params["dim_model"] if isinstance(params["dim_model"], list) else [params["dim_model"]] * 3
    strided = params.get("strided_blocks", [])
    expand = params.get("expand_blocks", [])
    out, stride = [], 1
    for b in range(n):
        if b in strided:
            s = params["conv_stride"] if not isinstance(params["conv_stride"], list) else \
                params["conv_stride"][sum(b > x for x in strided)]
            a = params["att_stride"] if not isinstance(params["att_stride"], list) else \
                params["att_stride"][sum(b > x for x in strided)]
            stride *= s * a
        out.append((dims[sum(b >= x for x in expand)], stride))
    return out


class EfficientConformerSemanticSLU(HubertSemanticSLU):
    """Reuses every decoding / training helper of HubertSemanticSLU; only the encoder differs."""

    def __init__(self, teacher_nemo_model, ec_config="medium", ec_checkpoint=None,
                 layer_fusion="weighted_sum", semantic_layer=-1, fusion_layers=None,
                 freeze_subsampling=False, freeze_encoder_layers=0, spec_augment=True,
                 adapter_layers=2, dropout=0.1, init_decoder_from_teacher=True, verbose=True):
        nn.Module.__init__(self)  # skip the HuBERT/WavLM construction of the parent
        self.ec_params = load_encoder_params(ec_config)
        self.encoder = build_encoder(self.ec_params, checkpoint=ec_checkpoint, verbose=verbose)
        self.spec_augment = spec_augment

        layout = _stage_layout(self.ec_params)
        n_blocks = len(layout)
        H, final_stride = layout[-1]
        self.hidden_size = H

        if freeze_subsampling:
            for p in self.encoder.subsampling_module.parameters():
                p.requires_grad = False
            for p in self.encoder.linear.parameters():
                p.requires_grad = False
        for i, blk in enumerate(self.encoder.blocks):
            if i < freeze_encoder_layers:
                for p in blk.parameters():
                    p.requires_grad = False

        # ---- block read-out ----
        self.layer_fusion = layer_fusion
        self.semantic_layer = semantic_layer % n_blocks          # -1 -> last block
        if fusion_layers is None:                                 # default: every last-stage block
            fusion_layers = [i for i, (_, s) in enumerate(layout) if s == final_stride]
        self.fusion_layers = [i % n_blocks for i in fusion_layers]
        self.pool_factors = {}
        self.layer_proj = nn.ModuleDict()
        read = self.fusion_layers if layer_fusion == "weighted_sum" else [self.semantic_layer]
        for i in read:
            d, s = layout[i]
            self.pool_factors[i] = final_stride // s
            if d != H:
                self.layer_proj[str(i)] = nn.Linear(d, H)
        if layer_fusion == "weighted_sum":
            self.fusion = LayerWeightedSum(len(self.fusion_layers))

        # ---- bridge encoder space -> teacher decoder space ----
        d_model = int(teacher_nemo_model.cfg.encoder.d_model)
        self.d_model = d_model
        self.adapter = nn.Sequential(nn.Linear(H, d_model), nn.LayerNorm(d_model), nn.Dropout(dropout))
        self.adapter_encoder = None
        if adapter_layers > 0:
            layer = nn.TransformerEncoderLayer(d_model, nhead=8, dim_feedforward=4 * d_model,
                                               dropout=dropout, batch_first=True, norm_first=True)
            self.adapter_encoder = nn.TransformerEncoder(layer, num_layers=adapter_layers)

        # ---- teacher-identical output head ----
        self.embedding = copy.deepcopy(teacher_nemo_model.embedding)
        self.decoder = copy.deepcopy(teacher_nemo_model.decoder)
        self.classifier = copy.deepcopy(teacher_nemo_model.classifier)
        for mod in (self.embedding, self.decoder, self.classifier):
            mod.train()
            for p in mod.parameters():
                p.requires_grad = True
            if not init_decoder_from_teacher:
                _reset_parameters(mod)

    # ------------------------------------------------------------------ #
    def backbone_parameters(self):
        return [p for p in self.encoder.parameters() if p.requires_grad]

    def bridge_parameters(self):
        mods = [self.adapter, self.layer_proj] + ([self.adapter_encoder] if self.adapter_encoder is not None else [])
        if self.layer_fusion == "weighted_sum":
            mods.append(self.fusion)
        return [p for m in mods for p in m.parameters()]

    def log_layer_fusion_weights(self):
        if self.layer_fusion != "weighted_sum":
            return None
        return {"blocks": self.fusion_layers, "weights": self.fusion.normalized_weights().tolist()}

    # ------------------------------------------------------------------ #
    def _run_encoder(self, wav, wav_lens, keep):
        """Mirror of ConformerEncoder.forward that also returns the outputs of blocks in `keep`."""
        enc = self.encoder
        x, x_len = enc.preprocessing(wav, wav_lens)
        if self.training and self.spec_augment:
            x = enc.augment(x, x_len)
        x, x_len = enc.subsampling_module(x, x_len)
        mask = enc.padding_mask(x, x_len)
        x = enc.dropout(enc.linear(x.transpose(1, 2)))
        if enc.pos_enc is not None:
            x = x + enc.pos_enc(x.size(0), x.size(1))
        feats, last = {}, max(keep)
        for i, block in enumerate(enc.blocks):
            if i <= last:                               # blocks after the last read-out are skipped
                x, _, _ = block(x, mask)
                if i in keep:
                    feats[i] = x
            if block.stride > 1:
                if mask is not None:
                    mask = mask[:, :, ::block.stride, ::block.stride]
                x_len = torch.div(x_len - 1, block.stride, rounding_mode="floor") + 1
        return feats, x_len                             # x_len: frames at the FINAL (80 ms) rate

    def _to_final(self, i, h, T):
        """Bring block i's output to the final frame rate / width: (B, T, H)."""
        f = self.pool_factors[i]
        if f > 1:
            h = F.avg_pool1d(h.transpose(1, 2), kernel_size=f, stride=f, ceil_mode=True).transpose(1, 2)
        h = h[:, :T]
        if h.shape[1] < T:
            h = F.pad(h, (0, 0, 0, T - h.shape[1]))
        if str(i) in self.layer_proj:
            h = self.layer_proj[str(i)](h)
        return h

    def encode(self, input_values, attention_mask):
        """-> enc (B, T, d_model) at 80 ms frames, enc_lens (B,)"""
        wav_lens = attention_mask.sum(-1).long()
        keep = self.fusion_layers if self.layer_fusion == "weighted_sum" else [self.semantic_layer]
        feats, lens = self._run_encoder(input_values, wav_lens, set(keep))
        T = max(int(lens.max()), 1)
        if self.layer_fusion == "weighted_sum":
            x = self.fusion([self._to_final(i, feats[i], T) for i in self.fusion_layers])
        else:
            x = self._to_final(self.semantic_layer, feats[self.semantic_layer], T)
        lens = lens.clamp(max=x.shape[1])
        x = self.adapter(x)
        if self.adapter_encoder is not None:
            pad = length_mask(lens, x.shape[1]) == 0
            x = self.adapter_encoder(x, src_key_padding_mask=pad)
        return x, lens
