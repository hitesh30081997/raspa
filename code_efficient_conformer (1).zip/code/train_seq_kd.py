"""
train_seq_kd.py
Train a student (Efficient Conformer by default, or WavLM/HuBERT with --encoder wavlm)
whose output is the SAME as the NeMo teacher's
(slu_conformer_transformer_large_slurp): same tokenizer, same Transformer decoder,
same semantics string, e.g.

    {'scenario': 'alarm'| 'action': 'set'| 'entities': [{'type': 'time'| 'filler': 'five am'}]}

Student sees NOISY audio (default 5 dB SNR); teacher sees CLEAN audio.

Loss per batch (all token-level terms are teacher-forced on the gold target):
  ce      : cross-entropy of student tokens vs gold semantics
  kd_tok  : T^2 * KL(teacher token distribution || student)  -- same vocab, so
            the student matches the teacher's full distribution at every token
  kd_dec  : 1 - cos(student decoder states, teacher decoder states)
  kd_enc  : 1 - cos(student adapter output, teacher Conformer output),
            time-aligned (student 20 ms -> teacher 40 ms frames)

  seq_kd  : cross-entropy of the student on the TEACHER's beam-search output
            (Kim & Rush sequence-level KD; teacher decodes clean audio with
            --teacher_beam_size, default 32; cached to <output_dir>)
  mwer    : (optional, --mwer_weight > 0) minimum-Bayes-risk loss over the
            student's own N-best list from a beam of --mwer_beam_size (default 32);
            risk = intent error + (1 - entity F1) of each hypothesis vs gold

  L = w_ce*ce + w_tok*kd_tok + w_dec*kd_dec + w_enc*kd_enc + w_seq*seq_kd + w_mwer*mwer

Decoding: dev evaluation and inference use beam search (--beam_size, default 32).

Student encoder (--encoder):
  efficient_conformer (default)  burchim/EfficientConformer encoder (model_seq_ec.py).
      --ec_config small|medium|large|<repo json>   architecture (default medium, 31.5M params)
      --ec_checkpoint <file.ckpt>                   official LibriSpeech CTC checkpoint (optional;
                                                    random init if omitted -- expect slower training)
      --layer_fusion weighted_sum fuses the last-stage blocks by default; --fusion_layers picks
      block indices (0-based), --semantic_layer picks one block for --layer_fusion single.
  wavlm   the original WavLM/HuBERT student (model_seq.py), --hubert_name as before.

Example:
    python train_seq_kd.py \
        --slurp_jsonl_dir /data/slurp/dataset/slurp --audio_root /data/slurp/audio \
        --noise_dir /data/musan/noise --snr_db 5 \
        --output_dir ./ckpt_seq_kd --epochs 20 --batch_size 8 \
        --beam_size 32 --teacher_beam_size 32 \
        --encoder efficient_conformer --ec_config medium \
        --ec_checkpoint /path/to/EfficientConformerCTCMedium/checkpoints_swa-equal-401-450.ckpt
    # add N-best MWER training from epoch 5 (slower: a beam-32 search per batch)
        ... --mwer_weight 0.1 --mwer_start_epoch 5
"""
import argparse
import math
import json
from collections import Counter
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from metrics import intent_accuracy, slu_f1
from students import build_student
from seq_dataset import SemanticsSlurpDataset, TargetFormatter, collate_semantics
from teacher_nemo import (DEFAULT_NEMO_PATH, NemoSLUTeacher, download_teacher,
                          entities_to_tagged_text, parse_semantics, semantics_entities,
                          semantics_intent)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--slurp_jsonl_dir", required=True)
    p.add_argument("--audio_root", required=True)
    p.add_argument("--output_dir", default="./ckpt_seq_kd")
    p.add_argument("--noise_dir", default=None)
    p.add_argument("--dev_noise_dir", default=None)
    p.add_argument("--noisy_audio_root", default=None)
    p.add_argument("--snr_db", type=float, default=5.0)
    p.add_argument("--max_audio_seconds", type=float, default=15.0)
    # student
    p.add_argument("--encoder", choices=["efficient_conformer", "wavlm"], default="efficient_conformer")
    p.add_argument("--hubert_name", default="/home/hp2/models/Wavlm-base-plus", help="--encoder wavlm only")
    p.add_argument("--ec_config", default="medium",
                   help="Efficient Conformer size (small|medium|large) or a repo config json")
    p.add_argument("--ec_checkpoint", default=None,
                   help="Official Efficient Conformer .ckpt to initialise the encoder (CTC head ignored)")
    p.add_argument("--ec_freeze_subsampling", action="store_true",
                   help="Freeze the conv subsampling + input projection (analogue of WavLM's frozen CNN)")
    p.add_argument("--no_spec_augment", action="store_true",
                   help="Disable the encoder's SpecAugment during training (efficient_conformer only)")
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="weighted_sum")
    p.add_argument("--semantic_layer", type=int, default=None,
                   help="single-layer read-out. wavlm: hidden_states index (default 10); "
                        "efficient_conformer: 0-based block index (default -1 = last block)")
    p.add_argument("--fusion_layers", default=None,
                   help="comma-separated layers to fuse. wavlm: hidden_states indices (default all); "
                        "efficient_conformer: block indices (default all last-stage blocks)")
    p.add_argument("--freeze_encoder_layers", type=int, default=0,
                   help="freeze the first N Transformer (wavlm) / Conformer (efficient_conformer) blocks")
    p.add_argument("--adapter_layers", type=int, default=2)
    p.add_argument("--random_decoder", action="store_true",
                   help="Random-init the teacher-shaped decoder instead of copying teacher weights")
    # teacher
    p.add_argument("--teacher_nemo", default=DEFAULT_NEMO_PATH)
    p.add_argument("--teacher_device", default=None)
    p.add_argument("--teacher_input", choices=["clean", "noisy"], default="clean")
    # optimisation
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--lr", type=float, default=None,
                   help="encoder lr. default: 3e-5 wavlm, 1e-4 pretrained efficient_conformer, "
                        "3e-4 randomly-initialised efficient_conformer")
    p.add_argument("--bridge_lr", type=float, default=5e-4, help="adapter + layer fusion")
    p.add_argument("--decoder_lr", type=float, default=1e-4, help="teacher-shaped decoder")
    p.add_argument("--freeze_decoder_epochs", type=int, default=1,
                   help="Keep the copied teacher decoder frozen for the first N epochs so the "
                        "encoder+adapter first learn to produce teacher-like features")
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--accum_steps", type=int, default=1,
                   help="gradient accumulation: effective batch = batch_size * accum_steps")
    p.add_argument("--warmup_pct", type=float, default=0.3, help="OneCycle fraction of steps spent warming up")
    p.add_argument("--max_bad_steps", type=int, default=50,
                   help="stop if this many consecutive steps have a non-finite loss/gradient")
    p.add_argument("--init_student", default=None,
                   help="start from the weights of a saved student (e.g. a previous best_student.pt)")
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    # loss weights
    p.add_argument("--ce_weight", type=float, default=1.0)
    p.add_argument("--kd_token_weight", type=float, default=1.0)
    p.add_argument("--kd_temperature", type=float, default=2.0)
    p.add_argument("--kd_dec_weight", type=float, default=0.5)
    p.add_argument("--kd_enc_weight", type=float, default=1.0)
    # beam search
    p.add_argument("--beam_size", type=int, default=32, help="student beam for dev eval (1 = greedy)")
    p.add_argument("--length_penalty", type=float, default=1.0,
                   help="GNMT length-penalty alpha used to rank finished beams (0 = off)")
    p.add_argument("--teacher_beam_size", type=int, default=32,
                   help="teacher beam for seq-KD targets and dev reference (1 = NeMo greedy)")
    p.add_argument("--seq_kd_weight", type=float, default=1.0,
                   help="CE on teacher beam-search outputs (0 disables, skips the cache pass)")
    p.add_argument("--seq_kd_cache", default=None,
                   help="json cache of teacher beam outputs on train (default <output_dir>/teacher_beam_train.json)")
    p.add_argument("--mwer_weight", type=float, default=0.0,
                   help="N-best minimum-risk loss on the student's own beam (0 = off)")
    p.add_argument("--mwer_beam_size", type=int, default=32)
    p.add_argument("--mwer_start_epoch", type=int, default=0)
    # eval
    p.add_argument("--max_decode_len", type=int, default=128)
    p.add_argument("--eval_teacher", action="store_true")
    args = p.parse_args()
    if args.semantic_layer is None:
        args.semantic_layer = 10 if args.encoder == "wavlm" else -1
    if args.lr is None:
        args.lr = 3e-5 if args.encoder == "wavlm" else (1e-4 if args.ec_checkpoint else 3e-4)
    return args


# --------------------------------------------------------------------------- #
def intents_from_jsonl(path):
    pairs = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                r = json.loads(line)
                if r.get("scenario") is not None and r.get("action") is not None:
                    pairs.setdefault(f"{r['scenario']}_{r['action']}", (r["scenario"], r["action"]))
    return sorted(pairs), pairs


def pad_audio(items, key):
    n = max(it[key].shape[0] for it in items)
    wav = torch.zeros(len(items), n)
    lens = torch.zeros(len(items), dtype=torch.long)
    for i, it in enumerate(items):
        L = it[key].shape[0]
        wav[i, :L], lens[i] = it[key], L
    return wav, lens


def masked_mean(x, mask):
    return (x * mask).sum() / mask.sum().clamp(min=1.0)


def enc_kd_loss(s_enc, t_enc, t_lens):
    Tt = t_enc.shape[1]
    s = F.interpolate(s_enc.transpose(1, 2), size=Tt, mode="linear", align_corners=False).transpose(1, 2)
    mask = (torch.arange(Tt, device=s.device)[None, :] < t_lens[:, None]).float()
    return masked_mean(1.0 - F.cosine_similarity(s, t_enc, dim=-1), mask)


def gold_tagged(entities):
    return entities_to_tagged_text({"entities": [{"type": t, "filler": f} for t, f in entities]})


def score(texts, batch_intents, batch_entities):
    sems = [parse_semantics(t) for t in texts]
    pi = [semantics_intent(s) or "<invalid>" for s in sems]
    acc = intent_accuracy(pi, batch_intents)
    f1 = slu_f1([entities_to_tagged_text(s) for s in sems], [gold_tagged(e) for e in batch_entities])
    return {"intent_accuracy": acc, **f1, "invalid": sum(s is None for s in sems)}


def utt_risk(text, gold_intent, gold_entities):
    """Semantic risk of one hypothesis in [0, 2]: intent error + (1 - entity F1)."""
    sem = parse_semantics(text)
    if sem is None:
        return 2.0
    r = 0.0 if semantics_intent(sem) == gold_intent else 1.0
    pred, gold = Counter(semantics_entities(sem)), Counter(tuple(e) for e in gold_entities)
    if not pred and not gold:
        return r
    tp = sum((pred & gold).values())
    p_ = tp / max(1, sum(pred.values()))
    r_ = tp / max(1, sum(gold.values()))
    f1 = 0.0 if tp == 0 else 2 * p_ * r_ / (p_ + r_)
    return r + (1.0 - f1)


def build_targets(seqs, device):
    """[[BOS ... EOS], ...] -> dec_inp, labels, mask (teacher layout, as in collate)."""
    Lt = max(len(t) for t in seqs) - 1
    dec_inp = torch.zeros(len(seqs), Lt, dtype=torch.long)
    labels = torch.zeros(len(seqs), Lt, dtype=torch.long)
    mask = torch.zeros(len(seqs), Lt)
    for i, t in enumerate(seqs):
        k = len(t) - 1
        dec_inp[i, :k], labels[i, :k], mask[i, :k] = torch.tensor(t[:-1]), torch.tensor(t[1:]), 1.0
    return dec_inp.to(device), labels.to(device), mask.to(device)


def fmt_m(m):
    return (f"intent_acc={m['intent_accuracy']:.4f} slu_f1={m['f1']:.4f} "
            f"(P={m['precision']:.4f} R={m['recall']:.4f}) unparseable={m['invalid']}")


# --------------------------------------------------------------------------- #
@torch.no_grad()
def teacher_outputs(teacher, loader, key, beam_size=1, max_len=128, length_penalty=1.0,
                    cache_path=None, save_every=200):
    """audio_file -> teacher semantics string. Resumable json cache if cache_path is given."""
    out = {}
    if cache_path is not None and Path(cache_path).exists():
        out = json.loads(Path(cache_path).read_text())
        print(f"[teacher] loaded {len(out)} cached outputs from {cache_path}")
    if out and all(e["audio_file"] in out for e in loader.dataset.examples):
        return out
    for i, b in enumerate(tqdm(loader, desc=f"teacher decode ({key}, beam={beam_size})")):
        if all(f in out for f in b["audio_files"]):
            continue
        enc, lens = teacher.encode(b[key].to(teacher.device), b["attention_mask"].sum(-1).to(teacher.device))
        for f, t in zip(b["audio_files"], teacher.decode(enc, lens, beam_size=beam_size, max_len=max_len,
                                                         length_penalty=length_penalty)):
            out[f] = t
        if cache_path is not None and (i + 1) % save_every == 0:
            Path(cache_path).write_text(json.dumps(out))
    if cache_path is not None:
        Path(cache_path).write_text(json.dumps(out))
    return out


@torch.no_grad()
def evaluate(student, teacher, loader, device, max_len, teacher_ref=None, show=3,
             beam_size=32, length_penalty=1.0):
    student.eval()
    texts, intents, ents, files = [], [], [], []
    for b in tqdm(loader, desc=f"dev decode (beam={beam_size})", leave=False):
        ids = student.decode(b["noisy"].to(device), b["attention_mask"].to(device),
                             teacher.bos, teacher.tok.eos_id, beam_size=beam_size,
                             max_len=max_len, length_penalty=length_penalty)
        texts += [teacher.ids_to_text(x) for x in ids]
        intents += b["gold_intents"]
        ents += b["gold_entities"]
        files += b["audio_files"]
    student.train()
    m = score(texts, intents, ents)
    if teacher_ref:
        tt = [teacher_ref.get(f, "") for f in files]
        m["same_as_teacher"] = sum(a.strip() == b.strip() for a, b in zip(texts, tt)) / max(1, len(tt))
        m["same_intent_as_teacher"] = sum(
            semantics_intent(parse_semantics(a)) == semantics_intent(parse_semantics(b))
            for a, b in zip(texts, tt)) / max(1, len(tt))
    for i in range(min(show, len(texts))):
        print(f"    student: {texts[i]}")
        if teacher_ref:
            print(f"    teacher: {teacher_ref.get(files[i], '')}")
    return m


# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    if (args.noise_dir is None) == (args.noisy_audio_root is None):
        raise SystemExit("Give exactly one of --noise_dir or --noisy_audio_root")
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "seq_kd_args.json").write_text(json.dumps(vars(args), indent=2))
    jdir = Path(args.slurp_jsonl_dir)
    tdev = args.teacher_device or args.device

    # ---- data ----
    common = dict(max_audio_seconds=args.max_audio_seconds, snr_db=args.snr_db,
                  noisy_audio_root=args.noisy_audio_root)
    train_ds = SemanticsSlurpDataset(jdir / "train.jsonl", args.audio_root,
                                     noise_dir=args.noise_dir, deterministic=False, **common)
    dev_ds = SemanticsSlurpDataset(jdir / "devel.jsonl", args.audio_root,
                                   noise_dir=(args.dev_noise_dir or args.noise_dir) if args.noise_dir else None,
                                   deterministic=True, **common)
    print(f"[data] train={len(train_ds)} dev={len(dev_ds)} snr={args.snr_db} dB")

    # ---- teacher + calibration of its exact output format ----
    intent_list, pairs = intents_from_jsonl(jdir / "train.jsonl")
    teacher = NemoSLUTeacher(download_teacher(args.teacher_nemo), intent_list, pairs, tdev)
    cal_items = [dev_ds[i] for i in range(min(8, len(dev_ds)))]
    wav, lens = pad_audio(cal_items, "clean")
    teacher.calibrate(wav, lens)
    fmt = TargetFormatter(teacher)
    ex = cal_items[0]
    print(f"[format] gold target example: {fmt.render(ex['scenario'], ex['action'], ex['entities'])}")

    for ds in (train_ds, dev_ds):
        ds.attach_targets(fmt)
    print("[format] gold targets tokenised")
    collate = collate_semantics
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, drop_last=True,
                              num_workers=args.num_workers, collate_fn=collate)
    dev_loader = DataLoader(dev_ds, batch_size=args.batch_size, shuffle=False,
                            num_workers=args.num_workers, collate_fn=collate)

    tb = dict(beam_size=args.teacher_beam_size, max_len=args.max_decode_len,
              length_penalty=args.length_penalty)
    teacher_ref = teacher_outputs(teacher, dev_loader, "clean", **tb)
    if args.eval_teacher:
        tn = teacher_outputs(teacher, dev_loader, "noisy", **tb)
        for key, ref in (("clean", teacher_ref), (f"noisy {args.snr_db} dB", tn)):
            texts = [ref[e["audio_file"]] for e in dev_ds.examples]
            m = score(texts, [f"{e['scenario']}_{e['action']}" for e in dev_ds.examples],
                      [e["entities"] for e in dev_ds.examples])
            print(f"[teacher] dev {key}: {fmt_m(m)}")

    # ---- sequence-level KD targets: teacher beam search on CLEAN train audio ----
    seq_targets = {}
    if args.seq_kd_weight > 0:
        cache = args.seq_kd_cache or str(out_dir / f"teacher_beam{args.teacher_beam_size}_train.json")
        scan_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=False,
                                 num_workers=args.num_workers, collate_fn=collate)
        t_train = teacher_outputs(teacher, scan_loader, "clean", cache_path=cache, **tb)
        n_bad = 0
        for f, text in t_train.items():
            if parse_semantics(text) is None:      # drop unparseable teacher outputs
                n_bad += 1
                continue
            seq_targets[f] = fmt.encode_target(text)
        print(f"[seq-kd] {len(seq_targets)} teacher beam-{args.teacher_beam_size} targets "
              f"({n_bad} unparseable dropped; those utterances fall back to gold)")

    # ---- student ----
    student_cfg = {k: getattr(args, k) for k in ("encoder", "hubert_name", "layer_fusion", "semantic_layer",
                                                  "fusion_layers", "adapter_layers", "no_spec_augment",
                                                  "beam_size", "length_penalty")}
    if args.encoder == "efficient_conformer":
        from efficient_conformer import load_encoder_params
        student_cfg["ec_params"] = load_encoder_params(args.ec_config)   # saved in every ckpt
    student = build_student(
        teacher.model, student_cfg, ec_checkpoint=args.ec_checkpoint,
        freeze_encoder_layers=args.freeze_encoder_layers, freeze_subsampling=args.ec_freeze_subsampling,
        init_decoder_from_teacher=not args.random_decoder,
    ).to(args.device)
    if args.init_student:
        sd = torch.load(args.init_student, map_location="cpu", weights_only=False)
        sd = sd.get("state_dict", sd)
        bad = [k for k, v in sd.items() if torch.is_floating_point(v) and not torch.isfinite(v).all()]
        if bad:
            raise SystemExit(f"{args.init_student} has non-finite weights ({bad[:3]} ...); use an earlier checkpoint")
        student.load_state_dict(sd)
        print(f"[student] initialised from {args.init_student}")
    print(f"[student] encoder={args.encoder} "
          f"total params={sum(p.numel() for p in student.parameters()):,}")

    groups = [
        {"params": student.backbone_parameters(), "lr": args.lr},
        {"params": student.bridge_parameters(), "lr": args.bridge_lr},
        {"params": student.decoder_parameters(), "lr": args.decoder_lr},
    ]
    optimizer = torch.optim.AdamW(groups)
    steps_per_epoch = math.ceil(len(train_loader) / args.accum_steps)
    total = max(1, args.epochs * steps_per_epoch)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=[args.lr, args.bridge_lr, args.decoder_lr], total_steps=total,
        pct_start=args.warmup_pct)
    print(f"[optim] effective batch {args.batch_size * args.accum_steps}, {total} optimizer steps, "
          f"peak at step {int(args.warmup_pct * total)} (epoch ~{args.warmup_pct * args.epochs:.1f})")
    for name, g in zip([args.encoder, "bridge", "decoder"], groups):
        print(f"[optim] {name}: {sum(p.numel() for p in g['params']):,} params, lr={g['lr']}")

    T = args.kd_temperature
    best, step, bad_steps = -1.0, 0, 0
    for epoch in range(args.epochs):
        freeze_dec = epoch < args.freeze_decoder_epochs and not args.random_decoder
        student.set_decoder_trainable(not freeze_dec)
        student.train()
        running, micro, epoch_bad = {}, 0, 0
        optimizer.zero_grad(set_to_none=True)
        pbar = tqdm(train_loader, desc=f"epoch {epoch}{' (decoder frozen)' if freeze_dec else ''}")
        for b in pbar:
            att = b["attention_mask"]
            t_wav = b["clean"] if args.teacher_input == "clean" else b["noisy"]
            with torch.no_grad():
                t_enc, t_lens = teacher.encode(t_wav.to(tdev), att.sum(-1).to(tdev))
                t_logp, t_h = teacher.forced(t_enc, t_lens, b["dec_inp"].to(tdev), b["dec_mask"].to(tdev))
            t_enc, t_lens, t_logp, t_h = (x.to(args.device) for x in (t_enc, t_lens, t_logp, t_h))

            dec_inp, labels, mask = (b[k].to(args.device) for k in ("dec_inp", "labels", "dec_mask"))
            out = student(b["noisy"].to(args.device), att.to(args.device), dec_inp, mask)
            s_logp = out["log_probs"]

            ce = masked_mean(-s_logp.gather(-1, labels.unsqueeze(-1)).squeeze(-1), mask)
            t_logT = F.log_softmax(t_logp.float() / T, -1)
            s_logT = F.log_softmax(s_logp.float() / T, -1)
            t_p = t_logT.exp()   # 0 * (-inf) would be NaN: zero the terms where the teacher prob is 0
            kd_terms = torch.where(t_p > 0, t_p * (t_logT - s_logT), torch.zeros_like(t_p))
            kd_tok = masked_mean(kd_terms.sum(-1), mask) * T * T
            kd_dec = masked_mean(1.0 - F.cosine_similarity(out["dec_states"], t_h.float(), dim=-1), mask)
            kd_enc = enc_kd_loss(out["enc"], t_enc.float(), t_lens)

            loss = (args.ce_weight * ce + args.kd_token_weight * kd_tok
                    + args.kd_dec_weight * kd_dec + args.kd_enc_weight * kd_enc)

            # sequence-level KD on the teacher's beam-search output
            seq_kd = torch.zeros((), device=args.device)
            if seq_targets:
                tgt = [seq_targets.get(f) for f in b["audio_files"]]
                gold_seq = [[teacher.bos] + lab[:int(m.sum())].tolist()
                            for lab, m in zip(b["labels"], b["dec_mask"])]
                tgt = [t if t is not None else g for t, g in zip(tgt, gold_seq)]
                s_inp, s_lab, s_msk = build_targets(tgt, args.device)
                s_lp, _ = student.decode_step(out["enc"], out["enc_lens"], s_inp, s_msk)
                seq_kd = masked_mean(-s_lp.gather(-1, s_lab.unsqueeze(-1)).squeeze(-1), s_msk)
                loss = loss + args.seq_kd_weight * seq_kd

            # N-best minimum-risk (MWER) training on the student's own beam
            mwer = torch.zeros((), device=args.device)
            if args.mwer_weight > 0 and epoch >= args.mwer_start_epoch:
                student.eval()   # deterministic search (no dropout)
                with torch.no_grad():
                    from beam_search import beam_search_modules
                    from model_seq import length_mask
                    enc_d = out["enc"].detach()
                    nb = beam_search_modules(student.embedding, student.decoder, student.classifier,
                                             enc_d, length_mask(out["enc_lens"], enc_d.shape[1]),
                                             teacher.bos, teacher.tok.eos_id,
                                             beam_size=args.mwer_beam_size, max_len=args.max_decode_len,
                                             length_penalty=args.length_penalty, nbest=args.mwer_beam_size)
                student.train()
                hyps = [[ids for ids, _ in h] for h in nb]
                risk = torch.zeros(len(hyps), max(len(h) for h in hyps), device=args.device)
                for i, h in enumerate(hyps):
                    for n, ids in enumerate(h):
                        risk[i, n] = utt_risk(teacher.ids_to_text(ids), b["gold_intents"][i],
                                              b["gold_entities"][i])
                seq_lp, valid = student.nbest_logprobs(out["enc"], out["enc_lens"], hyps,
                                                       teacher.bos, teacher.tok.eos_id)
                seq_lp = seq_lp.masked_fill(valid == 0, float("-inf"))
                post = torch.softmax(seq_lp, dim=-1)                       # renormalised over N-best
                mean_r = (risk * valid).sum(-1, keepdim=True) / valid.sum(-1, keepdim=True)
                mwer = ((post * (risk - mean_r)) * valid).sum(-1).mean()
                loss = loss + args.mwer_weight * mwer

            if not torch.isfinite(loss):
                bad_steps += 1
                epoch_bad += 1
                optimizer.zero_grad(set_to_none=True)
                micro = 0
                print(f"\n[warn] non-finite loss at step {step}: "
                      + " ".join(f"{k}={float(v):.3g}" for k, v in (("ce", ce), ("kd_tok", kd_tok),
                                 ("kd_dec", kd_dec), ("kd_enc", kd_enc), ("seq_kd", seq_kd), ("mwer", mwer)))
                      + " -> batch skipped")
                if bad_steps >= args.max_bad_steps:
                    raise SystemExit(f"{bad_steps} consecutive non-finite steps; lower --lr / --bridge_lr")
                continue
            (loss / args.accum_steps).backward()
            micro += 1
            if micro < args.accum_steps:
                continue
            micro = 0
            gnorm = torch.nn.utils.clip_grad_norm_(
                [p for p in student.parameters() if p.requires_grad], args.grad_clip)
            if not torch.isfinite(gnorm):
                bad_steps += 1
                epoch_bad += 1
                optimizer.zero_grad(set_to_none=True)
                print(f"\n[warn] non-finite gradient norm at step {step} -> update skipped")
                if bad_steps >= args.max_bad_steps:
                    raise SystemExit(f"{bad_steps} consecutive non-finite steps; lower --lr / --bridge_lr")
                continue
            bad_steps = 0
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            scheduler.step()

            step += 1
            running["gnorm"] = 0.98 * running.get("gnorm", float(gnorm)) + 0.02 * float(gnorm)
            for k, v in (("loss", loss), ("ce", ce), ("kd_tok", kd_tok), ("kd_dec", kd_dec),
                         ("kd_enc", kd_enc), ("seq_kd", seq_kd), ("mwer", mwer)):
                running[k] = 0.98 * running.get(k, float(v)) + 0.02 * float(v)
            if step % args.log_every == 0:
                pbar.set_postfix({**{k: f"{v:.3f}" for k, v in running.items()},
                                  "lr": f"{scheduler.get_last_lr()[0]:.2e}"})

        nonfinite = [n for n, p_ in student.named_parameters() if not torch.isfinite(p_).all()]
        print(f"[epoch {epoch}] train: " + " ".join(f"{k}={v:.3f}" for k, v in running.items())
              + f" lr={scheduler.get_last_lr()[0]:.2e} skipped_steps={epoch_bad}")
        if nonfinite:
            raise SystemExit(f"[epoch {epoch}] non-finite weights in {nonfinite[:3]} ... -- restart with "
                             f"--init_student {out_dir / 'best_student.pt'} and a lower --lr")
        m = evaluate(student, teacher, dev_loader, args.device, args.max_decode_len, teacher_ref,
                     beam_size=args.beam_size, length_penalty=args.length_penalty)
        print(f"[epoch {epoch}] student dev noisy: {fmt_m(m)}")
        print(f"[epoch {epoch}] identical to teacher(clean): {m['same_as_teacher']:.4f}  "
              f"same intent: {m['same_intent_as_teacher']:.4f}")

        ckpt = {"state_dict": student.state_dict(), "prefix_parts": teacher.prefix_parts,
                "config": student_cfg}
        torch.save(ckpt, out_dir / "last_student.pt")
        if m["f1"] > best:
            best = m["f1"]
            torch.save(ckpt, out_dir / "best_student.pt")
            print(f"[epoch {epoch}] new best (noisy dev slu_f1={best:.4f}) -> best_student.pt")
        fw = student.log_layer_fusion_weights() if hasattr(student, "log_layer_fusion_weights") else None
        if fw:
            print(f"[epoch {epoch}] layer-fusion weights: "
                  + " ".join(f"{l}:{w:.3f}" for l, w in zip(fw.get("blocks", fw.get("layers", [])),
                                                            fw.get("weights", fw.get("intent", [])))))


if __name__ == "__main__":
    main()
