"""
students.py
Build the KD student (Efficient Conformer or WavLM/HuBERT) from a config dict -- the parsed
training args or the "config" saved in a checkpoint -- so training and inference agree.
"""
from model_seq import HubertSemanticSLU


def build_student(teacher_model, cfg, ec_checkpoint=None, verbose=True, **train_kw):
    """Build the student from a config dict (parsed args or a checkpoint's saved config)."""
    fusion = [int(x) for x in cfg["fusion_layers"].split(",")] if cfg.get("fusion_layers") else None
    if cfg.get("encoder", "wavlm") == "efficient_conformer":
        from model_seq_ec import EfficientConformerSemanticSLU
        return EfficientConformerSemanticSLU(
            teacher_model, ec_config=cfg["ec_params"], ec_checkpoint=ec_checkpoint,
            layer_fusion=cfg["layer_fusion"], semantic_layer=cfg["semantic_layer"],
            fusion_layers=fusion, adapter_layers=cfg["adapter_layers"],
            spec_augment=not cfg.get("no_spec_augment", False), verbose=verbose, **train_kw)
    train_kw.pop("freeze_subsampling", None)
    return HubertSemanticSLU(
        teacher_model, hubert_name=cfg["hubert_name"], layer_fusion=cfg["layer_fusion"],
        semantic_layer=cfg["semantic_layer"], fusion_layers=fusion,
        adapter_layers=cfg["adapter_layers"], **train_kw)
