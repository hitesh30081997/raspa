"""
efficient_conformer
Encoder-only copy of the official Efficient Conformer implementation
(https://github.com/burchim/EfficientConformer, commit 612ef0b, Apache-2.0, see LICENSE).

Only models/{encoders,blocks,modules,attentions,activations,layers}.py are vendored,
with `from models.X` rewritten to relative imports; the code is otherwise unchanged.
configs/ holds the three CTC configs from the repo (Small / Medium / Large).

    from efficient_conformer import build_encoder, load_encoder_params
    params = load_encoder_params("Medium")            # or a path to any repo config json
    enc = build_encoder(params, checkpoint="checkpoints_swa-equal-401-450.ckpt")
    x, x_len, attentions = enc(wav, wav_len)          # wav: (B, N) raw 16 kHz audio
"""
import json
from pathlib import Path

import torch

from .encoders import ConformerEncoder

CONFIG_DIR = Path(__file__).parent / "configs"
PRESETS = {
    "small": "EfficientConformerCTCSmall.json",
    "medium": "EfficientConformerCTCMedium.json",
    "large": "EfficientConformerCTCLarge.json",
}


def load_encoder_params(config):
    """config: 'small' | 'medium' | 'large' | path to a repo-style json | an encoder_params dict."""
    if isinstance(config, dict):
        return dict(config.get("encoder_params", config))
    path = CONFIG_DIR / PRESETS[config.lower()] if str(config).lower() in PRESETS else Path(config)
    cfg = json.loads(Path(path).read_text())
    return dict(cfg.get("encoder_params", cfg))


def load_pretrained_encoder(encoder, path, verbose=True):
    """Load encoder weights from an official Efficient Conformer checkpoint.

    Accepts the repo's training checkpoints ({'model_state_dict': {'encoder.*', 'fc.*', ...}},
    with or without DDP '.module.' prefixes) or a bare encoder state_dict. The CTC 'fc' head and
    InterCTC projections are ignored, since this model only uses the encoder."""
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    sd = ckpt.get("model_state_dict", ckpt) if isinstance(ckpt, dict) else ckpt
    sd = {k.replace(".module.", ".").removeprefix("module."): v for k, v in sd.items()}
    if any(k.startswith("encoder.") for k in sd):
        sd = {k[len("encoder."):]: v for k, v in sd.items() if k.startswith("encoder.")}
    sd = {k: v for k, v in sd.items() if not k.startswith(("linear_expand_", "linear_proj_"))}
    missing, unexpected = encoder.load_state_dict(sd, strict=False)
    if verbose:
        n = sum(1 for _ in encoder.state_dict())
        print(f"[efficient_conformer] loaded {n - len(missing)}/{n} encoder tensors from {path}")
        if missing:
            print(f"[efficient_conformer]   missing ({len(missing)}): {missing[:8]}{' ...' if len(missing) > 8 else ''}")
        if unexpected:
            print(f"[efficient_conformer]   unexpected ({len(unexpected)}): {unexpected[:8]}{' ...' if len(unexpected) > 8 else ''}")
    if len(missing) > 0.5 * len(encoder.state_dict()):
        raise RuntimeError(f"{path} does not match the encoder config: {len(missing)} tensors missing. "
                           "Check that --ec_config matches the checkpoint size (Small/Medium/Large).")
    return encoder


def build_encoder(params, checkpoint=None, verbose=True):
    enc = ConformerEncoder(params)
    if checkpoint:
        load_pretrained_encoder(enc, checkpoint, verbose=verbose)
    elif verbose:
        print("[efficient_conformer] no checkpoint given -> encoder is randomly initialised")
    return enc
