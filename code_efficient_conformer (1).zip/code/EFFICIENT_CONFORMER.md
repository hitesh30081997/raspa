# Efficient Conformer student (replaces WavLM)

The KD recipe in `train_seq_kd.py` is unchanged: same NeMo teacher, noisy student / clean
teacher, the same losses (ce, kd_tok, kd_dec, kd_enc, seq_kd, optional mwer), the same
3 optimiser groups + OneCycleLR, frozen-decoder warm-up, beam-32 dev eval and checkpointing.
Only the student encoder is swapped.

## New / changed files
| file | what |
|---|---|
| `efficient_conformer/` | encoder code vendored from github.com/burchim/EfficientConformer (commit 612ef0b, Apache-2.0); only imports changed. `configs/` = the repo's CTC Small/Medium/Large configs. |
| `model_seq_ec.py` | `EfficientConformerSemanticSLU`: EC encoder -> block read-out -> adapter (D_enc -> 512) -> teacher-identical decoder. Inherits all decoding/MWER helpers from `HubertSemanticSLU`. |
| `students.py` | `build_student()` used by both training and inference. |
| `train_seq_kd.py` | `--encoder efficient_conformer` (default) / `wavlm`, plus the EC options below. |
| `infer_seq.py` | rebuilds whichever student the checkpoint was trained with (old WavLM ckpts still load). |
| `model_seq.py` | added `backbone_parameters()` only. |

## Pretrained weights
Download an encoder checkpoint from the links in the repo README (Google Drive), for example
`EfficientConformerCTCMedium/checkpoints_swa-equal-401-450.ckpt` (Small 13.2M, Medium 31.5M, Large 125.6M).
The `--ec_config` size must match the checkpoint. The CTC `fc` head is ignored. Without
`--ec_checkpoint` the encoder starts from random init, which works but needs more epochs.

## Run
```
python train_seq_kd.py \
    --slurp_jsonl_dir /data/slurp/dataset/slurp --audio_root /data/slurp/audio \
    --noise_dir /data/musan/noise --snr_db 5 \
    --output_dir ./ckpt_seq_kd_ec --epochs 20 --batch_size 8 \
    --beam_size 32 --teacher_beam_size 32 \
    --encoder efficient_conformer --ec_config medium \
    --ec_checkpoint /path/to/EfficientConformerCTCMedium/checkpoints_swa-equal-401-450.ckpt

python infer_seq.py --ckpt ckpt_seq_kd_ec/best_student.pt audio.flac
```
To reuse an existing teacher beam cache, pass `--seq_kd_cache <old_dir>/teacher_beam32_train.json`.

## EC options
| flag | default | meaning |
|---|---|---|
| `--ec_config` | `medium` | `small` / `medium` / `large` or a repo config json |
| `--ec_checkpoint` | none | official `.ckpt` for the encoder |
| `--layer_fusion` | `weighted_sum` | learned softmax-weighted sum of block outputs (as with WavLM), or `single` |
| `--fusion_layers` | all last-stage blocks (Medium/Large: 10-15) | 0-based block indices. Earlier-stage blocks are avg-pooled to 80 ms and projected to the last-stage width |
| `--semantic_layer` | `-1` (last block) | block for `--layer_fusion single` |
| `--freeze_encoder_layers N` | 0 | freeze the first N Conformer blocks |
| `--ec_freeze_subsampling` | off | freeze conv subsampling + input projection |
| `--no_spec_augment` | off | the encoder applies its own SpecAugment while training (like WavLM's time masking). This disables it |
| `--lr` | 1e-4 with ckpt, 3e-4 without | encoder LR (bridge/decoder LRs unchanged) |
| `--accum_steps` | 1 | gradient accumulation (effective batch = batch_size x accum_steps) |
| `--warmup_pct` | 0.3 | fraction of training spent warming the LR up (OneCycle) |
| `--init_student` | none | start from a saved student, e.g. a previous `best_student.pt` |
| `--max_bad_steps` | 50 | stop after this many consecutive NaN/inf steps |

## Notes
* Stability: a batch with a NaN/inf loss or gradient is skipped and reported (`[warn] non-finite ...`)
  instead of corrupting the weights. Each epoch prints a `train:` line with the losses, the grad norm,
  the LR and `skipped_steps`.
* Frame rate: 10 ms mel -> 20 ms (subsampling) -> 40 ms -> **80 ms** encoder output. The teacher is at 40 ms.
  `enc_kd_loss` already interpolates the student onto the teacher's time axis, and the decoder
  cross-attends to any length.
* The EC front-end computes log-mel from raw 16 kHz waveforms itself, so the datasets are unchanged.
* Verified: the vendored encoder plus the block read-out loop gives bit-identical outputs to the upstream
  `ConformerEncoder.forward`. Forward, backward, greedy, beam search and N-best scoring were tested with a stand-in decoder.
